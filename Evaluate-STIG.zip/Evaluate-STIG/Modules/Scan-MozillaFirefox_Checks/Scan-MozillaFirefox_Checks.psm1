##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Mozilla Firefox
# Version:  V6R1
# Updated:  3/11/2022
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Get-V251545 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251545
        STIG ID    : FFOX-00-000001
        Rule ID    : SV-251545r807107_rule
        CCI ID     : CCI-002605
        Rule Name  : SRG-APP-000456
        Rule Title : The installed version of Firefox must be supported.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($IsLinux) {
        # Get Firefox install on Linux systems
        if ((Test-Path "/usr/lib64/firefox/") -or (Test-Path "/usr/lib/firefox/")) {
            $pkg_mgr = (Get-Content /etc/os-release | grep "ID_LIKE=").replace("ID_LIKE=", "").replace('"', "")
            switch ($pkg_mgr) {
                "debian" {
                    $FirefoxInstalls = @{
                        DisplayName     = $(apt -qq list firefox 2>/dev/null | grep installed)
                        DisplayVersion  = ""
                        InstallLocation = ""
                    }
                }
                "fedora" {
                    $FirefoxInstalls = @{
                        DisplayName     = $(rpm -qa | grep -i Firefox)
                        DisplayVersion  = ""
                        InstallLocation = ""
                    }
                }
            }
        }
        $FindingDetails += "Package entries for Firefox:" | Out-String
    }
    Else {
        $FirefoxInstalls = Get-InstalledSoftware | Where-Object DisplayName -Like "Mozilla Firefox*"
        $FindingDetails += "Apps and Features entries for Firefox:" | Out-String
    }

    $FindingDetails += "" | Out-String
    ForEach ($Item in $FirefoxInstalls) {
        $FindingDetails += "Name:`t$($Item.DisplayName)" | Out-String
        $FindingDetails += "Version:`t$($Item.DisplayVersion)" | Out-String
        $FindingDetails += "Path:`t`t$($Item.InstallLocation)" | Out-String
        $FindingDetails += "" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251546 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251546
        STIG ID    : FFOX-00-000002
        Rule ID    : SV-251546r807110_rule
        CCI ID     : CCI-001453
        Rule Name  : SRG-APP-000560
        Rule Title : Firefox must be configured to allow only TLS 1.2 or above.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "SSLVersionMin"  # Value name identified in STIG
    $RegistryValue = @("tls1.2")  # Value(s) expected in STIG
    $SettingName = "Minimum SSL version enabled"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.SSLVersionMin
        $RegistryResultValue = $Policies_JSON.SSLVersionMin
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_SZ"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251547 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251547
        STIG ID    : FFOX-00-000003
        Rule ID    : SV-251547r807113_rule
        CCI ID     : CCI-000187
        Rule Name  : SRG-APP-000177
        Rule Title : Firefox must be configured to ask which certificate to present to a website when a certificate is required.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Preferences"  # Value name identified in STIG
    $SettingName = "Preferences"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.Preferences | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.Preferences."security.default_personal_cert"
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_MULTI_SZ"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    # Built configuration item
    $Configuration = New-Object System.Collections.Generic.List[System.Object]
    $Configuration.Add([PSCustomObject]@{Name = "security.default_personal_cert"; Value = "Ask Every Time"; Status = "locked" })

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Type -ne $RegistryType) {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
        }
        Else {
            Try {
                $Json = $RegistryResult.Value | ConvertFrom-Json -ErrorAction Stop
                If (-Not($Json.($Configuration.Name))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but $($Configuration.Name) is not configured" | Out-String
                }
                ElseIf (-Not(($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value -and (($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    If ((($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value)) {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value) [Expected $($Configuration.Value)]" | Out-String
                    }
                    If ((($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status)) {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status) [Expected $($Configuration.Status)]" | Out-String
                    }
                }
                Else {
                    $Status = "NotAFinding"
                    $FindingDetails += "'$($SettingName)' is $($SettingState):" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                }
            }
            Catch {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
            }
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251548 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251548
        STIG ID    : FFOX-00-000004
        Rule ID    : SV-251548r807116_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to not automatically check for updated versions of installed search plugins.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Preferences"  # Value name identified in STIG
    $SettingName = "Preferences"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.Preferences | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.Preferences."browser.search.update"
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_MULTI_SZ"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    # Built configuration item
    $Configuration = New-Object System.Collections.Generic.List[System.Object]
    $Configuration.Add([PSCustomObject]@{Name = "browser.search.update"; Value = "false"; Status = "locked"})


    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Type -ne $RegistryType) {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
        }
        Else {
            Try {
                $Json = $RegistryResult.Value | ConvertFrom-Json -ErrorAction Stop
                If (-Not($Json.($Configuration.Name))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but $($Configuration.Name) is not configured" | Out-String
                }
                ElseIf (-Not(($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value -and (($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    If ((($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value)) {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value) [Expected $($Configuration.Value)]" | Out-String
                    }
                    If ((($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status)) {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status) [Expected $($Configuration.Status)]" | Out-String
                    }
                }
                Else {
                    $Status = "NotAFinding"
                    $FindingDetails += "'$($SettingName)' is $($SettingState):" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                }
            }
            Catch {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
            }
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251549 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251549
        STIG ID    : FFOX-00-000005
        Rule ID    : SV-251549r807119_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to not automatically update installed add-ons and plugins.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "ExtensionUpdate"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Extension Update"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.ExtensionUpdate
        $RegistryResultValue = $Policies_JSON.ExtensionUpdate
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251550 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251550
        STIG ID    : FFOX-00-000006
        Rule ID    : SV-251550r807122_rule
        CCI ID     : CCI-001242
        Rule Name  : SRG-APP-000278
        Rule Title : Firefox must be configured to not automatically execute or download MIME types that are not authorized for auto-download.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($IsLinux) {
        $Status = "Not_Reviewed"
    }
    Else {
        $ExtensionsToEval = @("HTA", "JSE", "JS", "MOCHA", "SHS", "VBE", "VBS", "SCT", "WSC")
        $Compliant = $true
        $ProfileFound = $false

        # Check if the UserToProcess has utilized Firefox
        $UserProfilePath = (Get-CimInstance Win32_UserProfile | Where-Object SID -EQ $UserSID).LocalPath
        If (Test-Path -Path "$UserProfilePath\AppData\Roaming\Mozilla\Firefox\Profiles") {
            $ProfileFound = $true
            $FindingDetails += "User Profile Evaluated: $($Username)" | Out-String
            $FindingDetails += "" | Out-String

            $HandlersJson = @(Get-ChildItem -Path "$UserProfilePath\AppData\Roaming\Mozilla\Firefox\Profiles" -Recurse | Where-Object Name -EQ "handlers.json")
        }
        Else {
            $ProfileList = Get-UsersToEval

            # Find a user that has utilized Firefox
            Foreach ($UserProfile in $ProfileList) {
                $UserProfilePath = $UserProfile.LocalPath
                If ((Test-Path -Path "$UserProfilePath\AppData\Roaming\Mozilla\Firefox\Profiles")) {
                    $ProfileFound = $true
                    $FindingDetails += "Evaluate-STIG intended to utilize $($Username), but the user has NOT utilized Firefox on this system." | Out-String
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "User Profile Evaluated: $($UserProfile.Username)" | Out-String
                    $FindingDetails += "" | Out-String

                    $HandlersJson = @(Get-ChildItem -Path "$UserProfilePath\AppData\Roaming\Mozilla\Firefox\Profiles" -Recurse | Where-Object Name -EQ "handlers.json")
                    break
                }
            }
        }
        If ($ProfileFound) {
            If ($HandlersJson) {
                $Config = New-Object System.Collections.Generic.List[System.Object]
                $Json = (Get-Content $HandlersJson.FullName | ConvertFrom-Json).mimeTypes
                ForEach ($Item in $Json.PSObject.Properties) {
                    If ($Item.Value.extensions -in $ExtensionsToEval) {
                        If ($Item.Value.ask -eq $true) {
                            $Action = "Always Ask"
                        }
                        ElseIf ($Item.Value.action -eq 0) {
                            $Action = "Save File"
                        }
                        Else {
                            $Compliant = $false
                            $Action = "NOT set to 'Save File' or 'Always Ask' [Finding]"
                        }
                        $Extensions
                        $Handlers = $Item.Value.handlers

                        $NewObj = [PSCustomObject]@{
                            Extension = $Item.Value.extensions
                            Action    = $Action
                            Handlers  = $Handlers
                        }
                        $Config.Add($NewObj)
                    }
                }
                If ($Config) {
                    $FindingDetails += "The following extensions in question are configured:" | Out-String
                    $FindingDetails += "" | Out-String
                    ForEach ($Item in $Config) {
                        $FindingDetails += "Extension:`t$($Item.Extension)" | Out-String
                        $FindingDetails += "Action:`t`t$($Item.Action)" | Out-String
                        $FindingDetails += "Handlers:`t`t$($Item.Handlers)" | Out-String
                        $FindingDetails += "" | Out-String
                    }
                }
                Else {
                    $FindingDetails += "None of the extensions in question are configured." | Out-String
                }
            }
            Else {
                $FindingDetails += "None of the extensions in question are configured." | Out-String
                $FindingDetails += "" | Out-String
            }
        }
        Else {
            $FindingDetails += "NO users have utilized Firefox on this system." | Out-String
            $FindingDetails += "" | Out-String
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251551 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251551
        STIG ID    : FFOX-00-000007
        Rule ID    : SV-251551r807125_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to disable form fill assistance.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "DisableFormHistory"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Disable Form History"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DisableFormHistory
        $RegistryResultValue = $Policies_JSON.DisableFormHistory
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251552 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251552
        STIG ID    : FFOX-00-000008
        Rule ID    : SV-251552r807128_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to not use a password store with or without a master password.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "PasswordManagerEnabled"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Password Manager"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.PasswordManagerEnabled
        $RegistryResultValue = $Policies_JSON.PasswordManagerEnabled
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG


        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251553 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251553
        STIG ID    : FFOX-00-000009
        Rule ID    : SV-251553r807131_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to block pop-up windows.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Default"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Block pop-ups from websites"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.PopupBlocking.Default | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.PopupBlocking
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\PopupBlocking"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251554 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251554
        STIG ID    : FFOX-00-000010
        Rule ID    : SV-251554r807134_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to prevent JavaScript from moving or resizing windows.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Preferences"  # Value name identified in STIG
    $SettingName = "Preferences"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.Preferences | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.Preferences."dom.disable_window_move_resize"
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_MULTI_SZ"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    # Built configuration item
    $Configuration = New-Object System.Collections.Generic.List[System.Object]
    $Configuration.Add([PSCustomObject]@{Name = "dom.disable_window_move_resize"; Value = "true"; Status = "locked"})

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Type -ne $RegistryType) {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
        }
        Else {
            Try {
                $Json = $RegistryResult.Value | ConvertFrom-Json -ErrorAction Stop
                If (-Not($Json.($Configuration.Name))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but $($Configuration.Name) is not configured" | Out-String
                }
                ElseIf (-Not(($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value -and (($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    If ((($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value)) {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value) [Expected $($Configuration.Value)]" | Out-String
                    }
                    If ((($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status)) {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status) [Expected $($Configuration.Status)]" | Out-String
                    }
                }
                Else {
                    $Status = "NotAFinding"
                    $FindingDetails += "'$($SettingName)' is $($SettingState):" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                }
            }
            Catch {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
            }
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251555 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251555
        STIG ID    : FFOX-00-000011
        Rule ID    : SV-251555r807137_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to prevent JavaScript from raising or lowering windows.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Preferences"  # Value name identified in STIG
    $SettingName = "Preferences"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.Preferences | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.Preferences."dom.disable_window_flip"
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_MULTI_SZ"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    # Built configuration item
    $Configuration = New-Object System.Collections.Generic.List[System.Object]
    $Configuration.Add([PSCustomObject]@{Name = "dom.disable_window_flip"; Value = "true"; Status = "locked"})

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Type -ne $RegistryType) {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
        }
        Else {
            Try {
                $Json = $RegistryResult.Value | ConvertFrom-Json -ErrorAction Stop
                If (-Not($Json.($Configuration.Name))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but $($Configuration.Name) is not configured" | Out-String
                }
                ElseIf (-Not(($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value -and (($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    If ((($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value)) {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value) [Expected $($Configuration.Value)]" | Out-String
                    }
                    If ((($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status)) {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status) [Expected $($Configuration.Status)]" | Out-String
                    }
                }
                Else {
                    $Status = "NotAFinding"
                    $FindingDetails += "'$($SettingName)' is $($SettingState):" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                }
            }
            Catch {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
            }
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251556 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251556
        STIG ID    : FFOX-00-000012
        Rule ID    : SV-251556r807140_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to prevent JavaScript from disabling or replacing context menus.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Preferences"  # Value name identified in STIG
    $SettingName = "Preferences"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.Preferences | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.Preferences."dom.event.contextmenu.enabled"
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_MULTI_SZ"  # Value type expected in STIG


        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    # Built configuration item
    $Configuration = New-Object System.Collections.Generic.List[System.Object]
    $Configuration.Add([PSCustomObject]@{Name = "dom.event.contextmenu.enabled"; Value = "false"; Status = "locked"})

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Type -ne $RegistryType) {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
        }
        Else {
            Try {
                $Json = $RegistryResult.Value | ConvertFrom-Json -ErrorAction Stop
                If (-Not($Json.($Configuration.Name))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but $($Configuration.Name) is not configured" | Out-String
                }
                ElseIf (-Not(($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value -and (($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    If ((($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value)) {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value) [Expected $($Configuration.Value)]" | Out-String
                    }
                    If ((($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status)) {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status) [Expected $($Configuration.Status)]" | Out-String
                    }
                }
                Else {
                    $Status = "NotAFinding"
                    $FindingDetails += "'$($SettingName)' is $($SettingState):" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                }
            }
            Catch {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
            }
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251557 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251557
        STIG ID    : FFOX-00-000013
        Rule ID    : SV-251557r807143_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured to disable the installation of extensions.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Default"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Allow add-on installs from websites"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.InstallAddonsPermission.Default | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.InstallAddonsPermission
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\InstallAddonsPermission"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251558 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251558
        STIG ID    : FFOX-00-000014
        Rule ID    : SV-251558r807146_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Background submission of information to Mozilla must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "DisableTelemetry"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Disable Telemetry"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DisableTelemetry
        $RegistryResultValue = $Policies_JSON.DisableTelemetry
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251559 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251559
        STIG ID    : FFOX-00-000015
        Rule ID    : SV-251559r807149_rule
        CCI ID     : CCI-001312
        Rule Name  : SRG-APP-000266
        Rule Title : Firefox development tools must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "DisableDeveloperTools"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Disable Developer Tools"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DisableDeveloperTools
        $RegistryResultValue = $Policies_JSON.DisableDeveloperTools
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251560 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251560
        STIG ID    : FFOX-00-000016
        Rule ID    : SV-251560r807152_rule
        CCI ID     : CCI-000185
        Rule Name  : SRG-APP-000175
        Rule Title : Firefox must have the DoD root certificates installed.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($IsLinux) {
        $Status = "Not_Reviewed"
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\Certificates"  # Registry path identified in STIG
        $RegistryValueName = "ImportEnterpriseRoots"  # Value name identified in STIG
        $RegistryValue = @("1", "true")  # Value(s) expected in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG
        $SettingName = "Import Enterprise Roots"  # GPO setting name identified in STIG
        $SettingState = "Enabled"  # GPO configured state identified in STIG.

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }

        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "" | Out-String

            # Build list of DoD Root CAs
            $CAs = New-Object System.Collections.Generic.List[System.Object]
            $CAs.Add([PSCustomObject]@{CA = "DoD Root CA 2"; Subject = "CN=DoD Root CA 2, OU=PKI, OU=DoD, O=U.S. Government, C=US"; Thumbprint = "8C941B34EA1EA6ED9AE2BC54CF687252B4C9B561"; NotAfter = "12/5/2029"})
            $CAs.Add([PSCustomObject]@{CA = "DoD Root CA 3"; Subject = "CN=DoD Root CA 3, OU=PKI, OU=DoD, O=U.S. Government, C=US"; Thumbprint = "D73CA91102A2204A36459ED32213B467D7CE97FB"; NotAfter = "12/30/2029"})
            $CAs.Add([PSCustomObject]@{CA = "DoD Root CA 4"; Subject = "CN=DoD Root CA 4, OU=PKI, OU=DoD, O=U.S. Government, C=US"; Thumbprint = "B8269F25DBD937ECAFD4C35A9838571723F2D026"; NotAfter = "7/25/2032"})
            $CAs.Add([PSCustomObject]@{CA = "DoD Root CA 5"; Subject = "CN=DoD Root CA 5, OU=PKI, OU=DoD, O=U.S. Government, C=US"; Thumbprint = "4ECB5CC3095670454DA1CBD410FC921F46B8564B"; NotAfter = "6/14/2041"})

            $InstalledCAs = Get-ChildItem -Path Cert:Localmachine\root | Where-Object Subject -Like "*DoD*" | Select-Object Subject, Thumbprint, NotAfter
            $Compliant = $true
            ForEach ($CA in $CAs) {
                $FindingDetails += "Subject:`t`t$($CA.Subject)" | Out-String
                $FindingDetails += "Thumbprint:`t$($CA.Thumbprint)" | Out-String
                $FindingDetails += "NotAfter:`t`t$($CA.NotAfter)" | Out-String
                If ($InstalledCAs | Where-Object { ($_.Subject -eq $CA.Subject) -and ($_.Thumbprint -eq $CA.Thumbprint) }) {
                    $FindingDetails += "Installed:`t`t$true" | Out-String
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "Installed:`t`t$false" | Out-String
                }
                $FindingDetails += "" | Out-String
            }

            If ($Compliant -eq $true) {
                $Status = "NotAFinding"
            }
            Else {
                $Status = "Open"
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251561 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251561
        STIG ID    : FFOX-00-000017
        Rule ID    : SV-251561r807155_rule
        CCI ID     : CCI-002355
        Rule Name  : SRG-APP-000326
        Rule Title : Firefox must be configured to not delete data upon shutdown.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Compliant = $true
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    # Build list of registry values to check
    $RegistryList = New-Object System.Collections.Generic.List[System.Object]
    $RegistryList.Add([PSCustomObject]@{ValueName = "Sessions"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Active Logins"; SettingState = "Disabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "History"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Browsing History"; SettingState = "Disabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "Cache"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Cache"; SettingState = "Disabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "Cookies"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Cookies"; SettingState = "Disabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "Downloads"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Download History"; SettingState = "Disabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "FormData"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Form & Search History"; SettingState = "Disabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "Locked"; Value = @("1", "true"); Type = @("REG_DWORD", "policies.json"); SettingName = "Locked"; SettingState = "Enabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "OfflineApps"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Offline Website Data"; SettingState = "Disabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "SiteSettings"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Site Preferences"; SettingState = "Disabled" })

    ForEach ($Item in $RegistryList) {
        If ($IsLinux) {
            $RegistryResult = [PSCustomObject]@{
                Key       = ""
                ValueName = ""
                Value     = ""
                type      = ""
            }

            if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
                $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
                $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            }
            elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
                $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
                $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            }
            else {
                $RegistryResult.Type = "(NotFound)"
            }

            $RegistryResult.Value = $Policies_JSON.SanitizeOnShutdown.$($Item.ValueName)

            if ($null -ne $RegistryResult.Value) {
                $RegistryResult.Type = "policies.json"
            }
            else {
                $RegistryResult.Type = "(NotFound)"
            }
            $RegistryResultValue = $Policies_JSON.SanitizeOnShutdown
        }
        else {
            $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\SanitizeOnShutdown"  # Registry path identified in STIG

            $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $Item.ValueName

            If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
                $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
                $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
            }
            Else {
                $RegistryResultValue = $RegistryResult.Value
            }
        }

        If ($RegistryResult.Type -eq "(NotFound)") {
            If ($SettingNotConfiguredAllowed -eq $true) {
                $FindingDetails += "'$($Item.SettingName)' is Not Configured in group policy which is acceptable per the STIG." | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$($Item.ValueName) (Not found)" | Out-String
            }
            Else {
                $Compliant = $false
                $FindingDetails += "'$($Item.SettingName)' is NOT $($Item.SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$($Item.ValueName) (Not found)" | Out-String
            }
        }
        Else {
            If ($RegistryResult.Value -in $($Item.Value) -and $RegistryResult.Type -in $($Item.Type)) {
                $FindingDetails += "'$($Item.SettingName)' is $($Item.SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$($Item.ValueName)" | Out-String
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $Compliant = $false
                $FindingDetails += "'$($Item.SettingName)' is NOT $($Item.SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$($Item.ValueName)" | Out-String
                If ($RegistryResult.Value -in $($Item.Value)) {
                    $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
                }
                Else {
                    $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($($Item.Value) -join " or ")]" | Out-String
                }
                If ($RegistryResult.Type -eq $($Item.Type)) {
                    $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
                }
                Else {
                    $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$($Item.Type)']" | Out-String
                }
            }
        }
        $FindingDetails += "-----------------------------------------------------------------------" | Out-String
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251562 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251562
        STIG ID    : FFOX-00-000018
        Rule ID    : SV-251562r807158_rule
        CCI ID     : CCI-002355
        Rule Name  : SRG-APP-000326
        Rule Title : Firefox must prevent the user from quickly deleting data.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "DisableForgetButton"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Disable Forget Button"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DisableForgetButton
        $RegistryResultValue = $Policies_JSON.DisableForgetButton
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251563 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251563
        STIG ID    : FFOX-00-000019
        Rule ID    : SV-251563r807161_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox private browsing must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "DisablePrivateBrowsing"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Disable Private Browsing"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DisablePrivateBrowsing
        $RegistryResultValue = $Policies_JSON.DisablePrivateBrowsing
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251564 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251564
        STIG ID    : FFOX-00-000020
        Rule ID    : SV-251564r807164_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox search suggestions must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "SearchSuggestEnabled"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Search Suggestions"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.SearchSuggestEnabled
        $RegistryResultValue = $Policies_JSON.SearchSuggestEnabled
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251565 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251565
        STIG ID    : FFOX-00-000021
        Rule ID    : SV-251565r807167_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox autoplay must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Default"  # Value name identified in STIG
    $RegistryValue = @("block-audio-video")  # Value(s) expected in STIG
    $SettingName = "Default autoplay level"  # GPO setting name identified in STIG
    $SettingState = "Enabled (Block Audio and Video)"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.Permissions.AutoPlay.Default
        $RegistryResultValue = $Policies_JSON.Permissions.Autoplay
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\Permissions\Autoplay"  # Registry path identified in STIG
        $RegistryType = "REG_SZ"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251566 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251566
        STIG ID    : FFOX-00-000022
        Rule ID    : SV-251566r807170_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox network prediction must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "NetworkPrediction"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Network Prediction"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.NetworkPrediction
        $RegistryResultValue = $Policies_JSON.NetworkPrediction
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251567 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251567
        STIG ID    : FFOX-00-000023
        Rule ID    : SV-251567r807173_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox fingerprinting protection must be enabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Fingerprinting"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Fingerprinting"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.EnableTrackingProtection.Fingerprinting
        $RegistryResultValue = $Policies_JSON.EnableTrackingProtection
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\EnableTrackingProtection"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251568 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251568
        STIG ID    : FFOX-00-000024
        Rule ID    : SV-251568r807176_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox cryptomining protection must be enabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Cryptomining"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Cryptomining"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.EnableTrackingProtection.Cryptomining
        $RegistryResultValue = $Policies_JSON.EnableTrackingProtection
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\EnableTrackingProtection"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251569 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251569
        STIG ID    : FFOX-00-000025
        Rule ID    : SV-251569r807179_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox Enhanced Tracking Protection must be enabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Preferences"  # Value name identified in STIG
    $SettingName = "Preferences"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.Preferences | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.Preferences."browser.contentblocking.category"
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_MULTI_SZ"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    # Built configuration item
    $Configuration = New-Object System.Collections.Generic.List[System.Object]
    $Configuration.Add([PSCustomObject]@{Name = "browser.contentblocking.category"; Value = "strict"; Status = "locked"})

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Type -ne $RegistryType) {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
        }
        Else {
            Try {
                $Json = $RegistryResult.Value | ConvertFrom-Json -ErrorAction Stop
                If (-Not($Json.($Configuration.Name))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but $($Configuration.Name) is not configured" | Out-String
                }
                ElseIf (-Not(($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value -and (($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    If ((($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value)) {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value) [Expected $($Configuration.Value)]" | Out-String
                    }
                    If ((($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status)) {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status) [Expected $($Configuration.Status)]" | Out-String
                    }
                }
                Else {
                    $Status = "NotAFinding"
                    $FindingDetails += "'$($SettingName)' is $($SettingState):" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                }
            }
            Catch {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
            }
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251570 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251570
        STIG ID    : FFOX-00-000026
        Rule ID    : SV-251570r807182_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox extension recommendations must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Preferences"  # Value name identified in STIG
    $SettingName = "Preferences"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.Preferences | ConvertTo-Json
        $RegistryResultValue = $Policies_JSON.Preferences."extensions.htmlaboutaddons.recommendations.enabled"
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_MULTI_SZ"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    # Built configuration item
    $Configuration = New-Object System.Collections.Generic.List[System.Object]
    $Configuration.Add([PSCustomObject]@{Name = "extensions.htmlaboutaddons.recommendations.enabled"; Value = "false"; Status = "locked" })

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Type -ne $RegistryType) {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
        }
        Else {
            Try {
                $Json = $RegistryResult.Value | ConvertFrom-Json -ErrorAction Stop
                If (-Not($Json.($Configuration.Name))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but $($Configuration.Name) is not configured" | Out-String
                }
                ElseIf (-Not(($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value -and (($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status))) {
                    $Status = "Open"
                    $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    If ((($Json.($Configuration.Name).Value).ToString() -eq $Configuration.Value)) {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value) [Expected $($Configuration.Value)]" | Out-String
                    }
                    If ((($Json.($Configuration.Name).Status).ToString() -eq $Configuration.Status)) {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                    }
                    Else {
                        $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status) [Expected $($Configuration.Status)]" | Out-String
                    }
                }
                Else {
                    $Status = "NotAFinding"
                    $FindingDetails += "'$($SettingName)' is $($SettingState):" | Out-String
                    $FindingDetails += $Configuration.Name | Out-String
                    $FindingDetails += "Value:`t$($Json.($Configuration.Name).Value)" | Out-String
                    $FindingDetails += "Status:`t$($Json.($Configuration.Name).Status)" | Out-String
                }
            }
            Catch {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState) but not correct:" | Out-String
            }
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251571 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251571
        STIG ID    : FFOX-00-000027
        Rule ID    : SV-251571r807185_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox deprecated ciphers must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "TLS_RSA_WITH_3DES_EDE_CBC_SHA"  # Value name identified in STIG
    $RegistryValue = @("1", "false")  # Value(s) expected in STIG
    $SettingName = "TLS_RSA_WITH_3DES_EDE_CBC_SHA"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DisabledCiphers.TLS_RSA_WITH_3DES_EDE_CBC_SHA
        $RegistryResultValue = $Policies_JSON.DisabledCiphers
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\DisabledCiphers"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251572 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251572
        STIG ID    : FFOX-00-000028
        Rule ID    : SV-251572r807188_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must not recommend extensions as the user is using the browser.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "ExtensionRecommendations"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Extension Recommendations"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.UserMessaging.ExtensionRecommendations
        $RegistryResultValue = $Policies_JSON.UserMessaging
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\UserMessaging"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251573 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251573
        STIG ID    : FFOX-00-000029
        Rule ID    : SV-251573r807191_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : The Firefox New Tab page must not show top sites.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "TopSites"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Customize Firefox Home"  # GPO setting name identified in STIG
    $SettingState = "Enabled (Top Sites unchecked)"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.FirefoxHome.TopSites
        $RegistryResultValue = $Policies_JSON.FirefoxHome
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\FirefoxHome"  # Registry path identified in STIG

        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251574 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251574
        STIG ID    : FFOX-00-000030
        Rule ID    : SV-251574r807194_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : The Firefox New Tab page must not show recommended stories.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Pocket"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Customize Firefox Home"  # GPO setting name identified in STIG
    $SettingState = "Enabled (Recommended by Pocket)"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.FirefoxHome.Pocket
        $RegistryResultValue = $Policies_JSON.FirefoxHome
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\FirefoxHome"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251575 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251575
        STIG ID    : FFOX-00-000031
        Rule ID    : SV-251575r807197_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : The Firefox New Tab page must not show highlights.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Highlights"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Customize Firefox Home"  # GPO setting name identified in STIG
    $SettingState = "Enabled (Download History unchecked)"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.FirefoxHome.Highlights
        $RegistryResultValue = $Policies_JSON.FirefoxHome
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\FirefoxHome"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251576 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251576
        STIG ID    : FFOX-00-000032
        Rule ID    : SV-251576r807200_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : The Firefox New Tab page must not show snippets.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Snippets"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Customize Firefox Home"  # GPO setting name identified in STIG
    $SettingState = "Enabled (Snippets unchecked)"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.FirefoxHome.Snippets
        $RegistryResultValue = $Policies_JSON.FirefoxHome
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\FirefoxHome"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251577 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251577
        STIG ID    : FFOX-00-000033
        Rule ID    : SV-251577r807203_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox must be configured so that DNS over HTTPS is disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "Enabled"  # Value name identified in STIG
    $RegistryValue = @("0", "false")  # Value(s) expected in STIG
    $SettingName = "Enabled"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DNSOverHTTPS.Enabled
        $RegistryResultValue = $Policies_JSON.DNSOverHTTPS
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\DNSOverHTTPS"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251578 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251578
        STIG ID    : FFOX-00-000034
        Rule ID    : SV-251578r807206_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox accounts must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "DisableFirefoxAccounts"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Disable Firefox Accounts"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DisableFirefoxAccounts
        $RegistryResultValue = $Policies_JSON.DisableFirefoxAccounts
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251579 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251579
        STIG ID    : FFOX-00-000035
        Rule ID    : SV-251579r807209_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox updates must not run in the background.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($IsLinux) {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a not a Windows system so this requirement is NA."
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryValueName = "BackgroundAppUpdate"  # Value name identified in STIG
        $RegistryValue = @("0", "false")  # Value(s) expected in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG
        $SettingName = "Background Updater"  # GPO setting name identified in STIG
        $SettingState = "Disabled"  # GPO configured state identified in STIG.
        $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }

        If ($RegistryResult.Type -eq "(NotFound)") {
            If ($SettingNotConfiguredAllowed -eq $true) {
                $Status = "NotAFinding"
                $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
            }
            Else {
                $Status = "Open"
                $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
            }
        }
        Else {
            If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$RegistryValueName" | Out-String
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $Status = "Open"
                $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$RegistryValueName" | Out-String
                If ($RegistryResult.Value -in $RegistryValue) {
                    $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
                }
                Else {
                    $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
                }
                If ($RegistryResult.Type -eq $RegistryType) {
                    $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
                }
                Else {
                    $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
                }
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251580 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251580
        STIG ID    : FFOX-00-000036
        Rule ID    : SV-251580r809561_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox feedback reporting must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryValueName = "DisableFeedbackCommands"  # Value name identified in STIG
    $RegistryValue = @("1", "true")  # Value(s) expected in STIG
    $SettingName = "Disable Feedback Commands"  # GPO setting name identified in STIG
    $SettingState = "Enabled"  # GPO configured state identified in STIG.
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    If ($IsLinux) {
        $RegistryResult = [PSCustomObject]@{
            Key       = ""
            ValueName = ""
            Value     = ""
            type      = ""
        }
        $SettingNotConfiguredAllowed = $false
        $RegistryType = "policies.json"

        if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
            $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
            $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            $RegistryResult.Type = "policies.json"
        }
        else {
            $RegistryResult.Type = "(NotFound)"
        }

        $RegistryResult.Value = $Policies_JSON.DisableFeedbackCommands
        $RegistryResultValue = $Policies_JSON.DisableFeedbackCommands
    }
    Else {
        $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox"  # Registry path identified in STIG
        $RegistryType = "REG_DWORD"  # Value type expected in STIG

        $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $RegistryValueName

        If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
            $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
            $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
        }
        Else {
            $RegistryResultValue = $RegistryResult.Value
        }
    }

    If ($RegistryResult.Type -eq "(NotFound)") {
        If ($SettingNotConfiguredAllowed -eq $true) {
            $Status = "NotAFinding"
            $FindingDetails += "'$SettingName' is Not Configured in group policy which is acceptable per the STIG." | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName (Not found)" | Out-String
        }
    }
    Else {
        If ($RegistryResult.Value -in $RegistryValue -and $RegistryResult.Type -eq $RegistryType) {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
        }
        Else {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
            $FindingDetails += "Name:`t$RegistryValueName" | Out-String
            If ($RegistryResult.Value -in $RegistryValue) {
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
            }
            Else {
                $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($RegistryValue -join " or ")]" | Out-String
            }
            If ($RegistryResult.Type -eq $RegistryType) {
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$RegistryType']" | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251581 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251581
        STIG ID    : FFOX-00-000037
        Rule ID    : SV-251581r807215_rule
        CCI ID     : CCI-000381
        Rule Name  : SRG-APP-000141
        Rule Title : Firefox encrypted media extensions must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Compliant = $true
    $RegistryPath = "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\EncryptedMediaExtensions"  # Registry path identified in STIG
    $SettingNotConfiguredAllowed = $false  # Set to true if STIG allows for setting to be Not Configured.

    # Build list of registry values to check
    $RegistryList = New-Object System.Collections.Generic.List[System.Object]
    $RegistryList.Add([PSCustomObject]@{ValueName = "Enabled"; Value = @("0", "false"); Type = @("REG_DWORD", "policies.json"); SettingName = "Enable Encrypted Media Extensions"; SettingState = "Disabled" })
    $RegistryList.Add([PSCustomObject]@{ValueName = "Locked"; Value = @("1", "true"); Type = @("REG_DWORD", "policies.json"); SettingName = "Lock Encrypted Media Extensions"; SettingState = "Enabled" })

    ForEach ($Item in $RegistryList) {
        If ($IsLinux) {
            $RegistryResult = [PSCustomObject]@{
                Key       = ""
                ValueName = ""
                Value     = ""
                type      = ""
            }

            if (Test-Path "/usr/lib64/firefox/distribution/policies.json") {
                $RegistryPath = "/usr/lib64/firefox/distribution/policies.json"
                $Policies_JSON = (Get-Content /usr/lib64/firefox/distribution/policies.json | ConvertFrom-Json).policies
            }
            elseif (Test-Path "/usr/lib/firefox/distribution/policies.json") {
                $RegistryPath = "/usr/lib/firefox/distribution/policies.json"
                $Policies_JSON = (Get-Content /usr/lib/firefox/distribution/policies.json | ConvertFrom-Json).policies
            }
            else {
                $RegistryResult.Type = "(NotFound)"
            }

            $RegistryResult.Value = $Policies_JSON.EncryptedMediaExtensions.$($Item.ValueName)

            if ($null -ne $RegistryResult.Value) {
                $RegistryResult.Type = "policies.json"
            }
            else {
                $RegistryResult.Type = "(NotFound)"
            }
            $RegistryResultValue = $Policies_JSON.EncryptedMediaExtensions
        }
        else {
            $RegistryResult = Get-RegistryResult -Path $RegistryPath -ValueName $Item.ValueName

            If ($RegistryResult.Type -in @("REG_DWORD", "REG_QWORD")) {
                $RegistryResultValue = "0x{0:x8}" -f $RegistryResult.Value + " ($($RegistryResult.Value))" # Convert to hex and fomat to 0x00000000
                $RegistryResult.Value = "{0:x}" -f $RegistryResult.Value # Convert to hex
            }
            Else {
                $RegistryResultValue = $RegistryResult.Value
            }
        }

        If ($RegistryResult.Type -eq "(NotFound)") {
            If ($SettingNotConfiguredAllowed -eq $true) {
                $FindingDetails += "'$($Item.SettingName)' is Not Configured in group policy which is acceptable per the STIG." | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$($Item.ValueName) (Not found)" | Out-String
            }
            Else {
                $Compliant = $false
                $FindingDetails += "'$($Item.SettingName)' is NOT $($Item.SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$($Item.ValueName) (Not found)" | Out-String
            }
        }
        Else {
            If ($RegistryResult.Value -in $($Item.Value) -and $RegistryResult.Type -in $($Item.Type)) {
                $FindingDetails += "'$($Item.SettingName)' is $($Item.SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$($Item.ValueName)" | Out-String
                $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
                $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
            }
            Else {
                $Compliant = $false
                $FindingDetails += "'$($Item.SettingName)' is NOT $($Item.SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path:`t`t$RegistryPath" | Out-String
                $FindingDetails += "Name:`t$($Item.ValueName)" | Out-String
                If ($RegistryResult.Value -in $($Item.Value)) {
                    $FindingDetails += "Value:`t$($RegistryResultValue)" | Out-String
                }
                Else {
                    $FindingDetails += "Value:`t$($RegistryResultValue) [Expected $($($Item.Value) -join " or ")]" | Out-String
                }
                If ($RegistryResult.Type -eq $($Item.Type)) {
                    $FindingDetails += "Type:`t$($RegistryResult.Type)" | Out-String
                }
                Else {
                    $FindingDetails += "Type:`t$($RegistryResult.Type) [Expected '$($Item.Type)']" | Out-String
                }
            }
        }
        $FindingDetails += "-----------------------------------------------------------------------" | Out-String
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}


# SIG # Begin signature block
# MIIL1AYJKoZIhvcNAQcCoIILxTCCC8ECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU14lFEFSkVdE/PZr07B5dy+0m
# +lygggk7MIIEejCCA2KgAwIBAgIEAwIE1zANBgkqhkiG9w0BAQsFADBaMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MB4XDTIwMDcxNTAw
# MDAwMFoXDTI1MDQwMjEzMzgzMlowaTELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxDDAKBgNV
# BAsTA1VTTjEWMBQGA1UEAxMNQ1MuTlNXQ0NELjAwMTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANv2fdTmx2dNPQ47F8kmvU+g20/sFoF+DS3k2GcMduuI
# XxYFJyMMPAvTJuobeJlX6P6sr5jAKhXXsoV4lT2boWw583Snl6cuSfqMbVowIJ1s
# CffN7N0VXsLVdOt1u5GCKs4/jXH7MeEOE0oJsgEjjE1IZc5tEqj++s1N1EUY+jf/
# zc8QHDjy5X88XBTzKVhwvczZVbRahrcmYv0k4we3ndwTl5nXYizSwi96CZuqzrIn
# WbLSsRLNyNZZVo7J5bZ+30dv/hZvq6FqxfAeM3pEDrvbfFkWXzaISqF1bVbsMlAC
# UBf/JFbSGtmMsU1ABfXKPalTWYJKP58dICHcUocZhL0CAwEAAaOCATcwggEzMB8G
# A1UdIwQYMBaAFHUJphUTroc8+nOUAPLw9Xm5snIUMEEGA1UdHwQ6MDgwNqA0oDKG
# MGh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNTlfTkNPREVTSUdOLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyowHQYDVR0O
# BBYEFFbrF3OpzfdsZkN1zTfv++oaLCRRMGUGCCsGAQUFBwEBBFkwVzAzBggrBgEF
# BQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNTkuY2VyMCAG
# CCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAWBgorBgEE
# AYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAQknaIAXDnyqshmyh
# uOZS4nBtSydnZrdB8Je0JCq2TTRA4dkNvrswe0kZgA7UjlY1X/9PtQeIwaMrcvdF
# i+dqzD1bbW/LX5tH/1oMOp4s+VkGfl4xUUxUGjO6QTVOeLyN2x+DBQU11DhKEq9B
# RCxUGgclFn1iqxi5xKmLaQ3XuRWRGCkb+rXejWR+5uSTognxCuoLp95bqu3JL8ec
# yF46+VSoafktAGot2Uf3qmwWdMHFBdwzmJalbC4j09I1qJqcJH0p8Wt34zRw/hSr
# 3f+xDEDP8GNL2ciDm7aN0GKy67ugjgMmPXAv7A4/keCuN/dsNS1naNyqzc5AhTAF
# +o/21jCCBLkwggOhoAMCAQICAgMFMA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTE5MDQwMjEzMzgz
# MloXDTI1MDQwMjEzMzgzMlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4g
# R292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMT
# DERPRCBJRCBDQS01OTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMwX
# hJ8twQpXrRFNNVc/JEcvHA9jlr27cDE8rpxWkobvpCJOoOVUbJ724Stx6OtTAZpR
# iXNaS0jjRgYaW6cq9pdnjjQM5ovHPPde1ewaZyWb2I+uqhkZmOBV1+lGUOhnQCyi
# nnSSqzEH1PC5nASfyxnCdBeOt+UKHBrPVKBUuYS4Fcn5Q0wv+sfBD24vyV5Ojeoq
# HeSSAMTaeqlv+WQb4YrjKNfaGF+S7lMvQelu3ANHEcoL2HMCimCvnCHQaMQI9+Ms
# NhySPEULePdEDxgpWYc9FmBbjUp1CYEx7HYdlTRJ9gBHts2ITxTZQrt4Epjkqeb8
# aWVmzCEPHE7+KUVhuO8CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyKlKJ3sYBy
# HYF6Fqry3M5m7kXAMB0GA1UdDgQWBBR1CaYVE66HPPpzlADy8PV5ubJyFDAOBgNV
# HQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsn
# MAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgB
# ZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQE
# BTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3Js
# L0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0
# cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3YzAgBggr
# BgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQELBQADggEB
# ADkFG9IOpz71qHNXCeYJIcUshgN20CrvB5ym4Pr7zKTBRMKNqd9EXWBxrwP9xhra
# 5YcQagHDqnmBeU3F2ePhWvQmyhPwIJaArk4xGLdv9Imkr3cO8vVapO48k/R9ZRSA
# EBxzd0xMDdZ6+xxFlZJIONRlxcVNNVB30e74Kk08/t82S9ogqgA1Q7KZ2tFuaRes
# jJWuoJ+LtE5lrtknqgaXLb3XH0hV5M0AWRk9Wg/1thb9NCsKEIAdpdnolZOephIz
# fzHiOSqeJ+e5qURLB7rT+F5y0NNWTdqoJ/vOOCUa8z0NKWsz2IkpeD3iNhVCLRKw
# Ojm/wzxdG2tst5OHRZFEwKcxggIDMIIB/wIBATBiMFoxCzAJBgNVBAYTAlVTMRgw
# FgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMD
# UEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNTkCBAMCBNcwCQYFKw4DAhoFAKB4MBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYE
# FE3HP2Zmd3K5HBZOxzNCpyTTYGv6MA0GCSqGSIb3DQEBAQUABIIBAF0rWaGTv8aB
# 1gfCK9ssXFGyvRSqhsyso4D0d8iSdXCOhDCOu12AHrllYtcLOeV+Cn7yXME7wX8S
# YquWcYZ1CnfHofngQQticU7hx+wTEH8ELq0jzliVxSkEN3RVviZe4waovFEgLSMZ
# lf/DPbsO7TcuST+i5B6fQw+YmPho25MIARXvqglP14CtGoZeJdUIA/zj5YY2oIOB
# H0ynxizbz0VRDYvpVUN2HnPUKvKRzWcgiVYD3LwhE43ZvrHTg+IudwqRH/r48apk
# X7tIKjmX1AHnj5PrzDqZTrSUELODS5Spc6rjJ7yxOAyRD/rnf3PVGQlOdTezuJER
# +WQiNydKqrA=
# SIG # End signature block
