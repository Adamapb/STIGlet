##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Active Directory Domain
# Version:  V3R1
# Updated:  3/11/2022
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Get-TrustAttributes {
    $TrustAttributes = @{
        1  = "Non-Transitive";
        2  = "Uplevel clients only (Windows 2000 or newer)";
        4  = "Quarantined Domain";
        8  = "Forest Trust";
        16 = "Cross-Organizational Trust (Selective Authorization)";
        32 = "Intra-Forest Trust";
        64 = "SID History Enabled"
    }
    Return $TrustAttributes
}

Function Get-V243466 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243466
        STIG ID    : AD.0001
        Rule ID    : SV-243466r723433_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Membership to the Enterprise Admins group must be restricted to accounts used only to manage the Active Directory Forest.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Groups = @("Enterprise Admins")

    ForEach ($Group in $Groups) {
        $ReturnedUsers = Get-ADGroupMember -identity $Group -Recursive | Select-Object Name, distinguishedName | Sort-Object Name -Unique
        If (($ReturnedUsers | Measure-Object).Count -eq 0) {
            $Status = "NotAFinding"
            $FindingDetails += "No Users are in the '$($Group)' Group" | Out-String
        }
        Else {
            $FindingDetails += "Members of '$($Group)'" | Out-String
            $FindingDetails += "=========================" | Out-String
            ForEach ($User in $ReturnedUsers) {
                $FindingDetails += "Name:`t`t`t`t$($User.name)" | Out-String
                $FindingDetails += "SamAccountName:`t`t$($User.SamAccountName)" | Out-String
                $FindingDetails += "DistinguishedName:`t$($User.distinguishedName)" | Out-String
                $FindingDetails += "" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243467 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243467
        STIG ID    : AD.0002
        Rule ID    : SV-243467r723436_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Membership to the Domain Admins group must be restricted to accounts used only to manage the Active Directory domain and domain controllers.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Groups = @("Domain Admins")

    ForEach ($Group in $Groups) {
        $ReturnedUsers = Get-ADGroupMember -identity $Group -Recursive | Select-Object name, SamAccountName, distinguishedName | Sort-Object Name -Unique
        If (($ReturnedUsers | Measure-Object).Count -eq 0) {
            $Status = "NotAFinding"
            $FindingDetails += "No Users are in the '$($Group)' Group" | Out-String
        }
        Else {
            $FindingDetails += "Members of '$($Group)'" | Out-String
            $FindingDetails += "=========================" | Out-String
            ForEach ($User in $ReturnedUsers) {
                $FindingDetails += "Name:`t`t`t`t$($User.name)" | Out-String
                $FindingDetails += "SamAccountName:`t`t$($User.SamAccountName)" | Out-String
                $FindingDetails += "DistinguishedName:`t$($User.distinguishedName)" | Out-String
                $FindingDetails += "" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243471 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243471
        STIG ID    : AD.0008
        Rule ID    : SV-243471r804653_rule
        CCI ID     : CCI-001941
        Rule Name  : SRG-OS-000112
        Rule Title : Local administrator accounts on domain systems must not share the same password.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $SchemaPath = (Get-ADRootDSE).schemaNamingContext
    If (-Not(Get-ADObject -SearchBase $SchemaPath -Filter 'name -eq "ms-Mcs-AdmPwd"')) {
        $FindingDetails += "It appears that the schema has not been extended for Local Administrator Password Solution (LAPS) as 'ms-Mcs-AdmPwd' is not a registered attribute." | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Ensure unique passwords are set for all local administrator accounts on domain systems." | Out-String
    }
    Else {
        $NoAdmPwd = Get-ADComputer -Filter * -Properties OperatingSystem, ms-Mcs-AdmPwd | Where-Object {($_.Enabled -eq $true -and $_.Operatingsystem -like "*Windows*" -and $_.DistinguishedName -notlike "*OU=Domain Controllers*" -and $null -eq $_.'ms-Mcs-AdmPwd')} | Select-Object Name, DistinguishedName, OperatingSystem
        If (-Not($NoAdmPwd)) {
            $Status = "NotAFinding"
            $FindingDetails += "All enabled Windows computer objects have LAPS passwords recorded." | Out-String
        }
        Else {
            $FindingDetails += "$(($NoAdmPwd | Measure-Object).Count) computer objects found with no LAPS password recorded:" | Out-String
            $FindingDetails += "=============================================" | Out-String
            ForEach ($Item in $NoAdmPwd) {
                $FindingDetails += $Item.Name | Out-String
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243473 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243473
        STIG ID    : AD.0013
        Rule ID    : SV-243473r723565_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Separate domain accounts must be used to manage public facing servers from any domain accounts used to manage internal servers.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Members = ([ADSI]"WinNT://./Administrators").psbase.Invoke('Members') | ForEach-Object { ([ADSI]$_).InvokeGet('AdsPath') } | Sort-Object
    $FindingDetails += "The following are members of the local Administrators group:" | Out-String
    $FindingDetails += "-------------------------------------------------------------" | Out-String
    ForEach ($Member in $Members) {
        If ($Member -match "WinNT://$env:COMPUTERNAME/") {
            $FindingDetails += $Member -replace "WinNT://$env:COMPUTERNAME/", "" | Out-String
        }
        Else {
            $FindingDetails += $Member -replace "WinNT://", "" -replace "/", "\" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243476 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243476
        STIG ID    : AD.0016
        Rule ID    : SV-243476r723463_rule
        CCI ID     : CCI-000199
        Rule Name  : SRG-OS-000076
        Rule Title : All accounts, privileged and unprivileged, that require smart cards must have the underlying NT hash rotated at least every 60 days.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainLevel = (Get-ADDomain).DomainMode
    $RollingNTLMSecrets = (Get-ADDomain).PublicKeyRequiredPasswordRolling

    $FindingDetails += "Domain Level:`t$($DomainLevel)" | Out-String
    $FindingDetails += "" | Out-String
    If ($DomainLevel -eq "Windows2016Domain" -or $DomainLevel -eq "Windows2019Domain") {
        $FindingDetails += "Rolling of expiring NTLM Secrets:`t$($RollingNTLMSecrets)" | Out-String
        If ($RollingNTLMSecrets -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    Else {
        $FindingDetails += "Domain functional level does not support rolling of expiring NTLM secrets.  Verify the organization rotates the NT hash for smart card-enforced accounts every 60 days." | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243477 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243477
        STIG ID    : AD.0017
        Rule ID    : SV-243477r723466_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : User accounts with domain level administrative privileges must be members of the Protected Users group in domains with a domain functional level of Windows 2012 R2 or higher.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainLevel = (Get-ADDomain).DomainMode
    $AcceptedDomainLevels = @("Windows2012R2Domain", "Windows2016Domain", "Windows2019Domain")
    $Groups = @("Enterprise Admins", "Domain Admins", "Schema Admins", "Administrators", "Account Operators", "Backup Operators")
    $Compliant = $True

    If ($DomainLevel -in $AcceptedDomainLevels) {
        $ProtectedUsers = Get-ADGroupMember -Identity "Protected Users" -Recursive | Sort-Object Name -Unique

        ForEach ($Group in $Groups) {
            $GroupMembers += Get-ADGroupMember -Identity $Group -Recursive | Sort-Object Name -Unique
        }
        $GroupMembers = $GroupMembers | Sort-Object Name -Unique
        $MissingUsers = New-Object System.Collections.Generic.List[System.Object]

        ForEach ($Member in $GroupMembers) {
            If ($Member -notin $ProtectedUsers) {
                $Obj = [PSCustomObject]@{
                    Name              = $Member.name
                    SamAccountName    = $Member.SamAccountName
                    DistinguishedName = $Member.distinguishedName
                }
                $MissingUsers.Add($Obj)
            }
        }

        If (($MissingUsers | Measure-Object).Count -ge 1) {
            If (($MissingUsers | Measure-Object).Count -eq 1) {
                $FindingDetails += "Only one account is not in 'Protected Users'.  This is acceptable by STIG for availability." | Out-String
                $FindingDetails += "" | Out-String
            }
            Else {
                $Compliant = $False
                $FindingDetails += "Multiple accounts are not in 'Protected Users'.  STIG only allows for one accout to be excluded for availability." | Out-String
                $FindingDetails += "" | Out-String
            }

            $FindingDetails += "Users Missing From 'Protected Users' Group" | Out-String
            $FindingDetails += "============================================" | Out-String
            ForEach ($User in $MissingUsers) {
                $FindingDetails += "Name:`t`t`t`t$($User.Name)" | Out-String
                $FindingDetails += "SamAccountName:`t`t$($User.SamAccountName)" | Out-String
                $FindingDetails += "DistinguishedName:`t$($User.DistinguishedName)" | Out-String
                $FindingDetails += "" | Out-String
            }
        }
        Else {
            $FindingDetails += "No users were missing from the 'Protected Users' group" | Out-String
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    Else {
        $Status = "Not_Applicable"
        $FindingDetails += "Domain Level: $($DomainLevel)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "The domain functional level is not Windows 2012 R2 or higher, so this check is Not Applicable" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243478 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243478
        STIG ID    : AD.0018
        Rule ID    : SV-243478r723469_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Domain-joined systems (excluding domain controllers) must not be configured for unconstrained delegation.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Computers = Get-ADComputer -Filter {(TrustedForDelegation -eq $True) -and (PrimaryGroupID -eq 515)} -Properties Name, DistinguishedName, Enabled, TrustedForDelegation, TrustedToAuthForDelegation, ServicePrincipalName, Description, PrimaryGroupID

    If (($Computers | Measure-Object).Count -gt 0) {
        $Status = "Open"
        ForEach ($Computer in $Computers) {
            $FindingDetails += "Name:`t`t`t`t`t`t$($Computer.Name)" | Out-String
            $FindingDetails += "Enabled:`t`t`t`t`t`t$($Computer.Enabled)" | Out-String
            $FindingDetails += "Trusted For Delegation:`t`t`t$($Computer.TrustedForDelegation)" | Out-String
            $FindingDetails += "Trusted To Auth For Delegation:`t$($Computer.TrustedToAuthForDelegation)" | Out-String
            ForEach ($SPN in $Computer.ServicePrincipalName) {
                $FindingDetails += "Service Principal Name:`t`t`t$($SPN)" | Out-String
            }
            $FindingDetails += "Description:`t`t`t`t`t$($Computer.Description)" | Out-String
            $FindingDetails += "PrimaryGroupID:`t`t`t`t$($Computer.PrimaryGroupID)" | Out-String
            $FindingDetails += "" | Out-String
        }
    }
    Else {
        $Status = "NotAFinding"
        $FindingDetails += "No computers are Trusted for Delegation and have a Primary Group ID of '515'" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243480 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243480
        STIG ID    : AD.0160
        Rule ID    : SV-243480r723563_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : The domain functional level must be at a Windows Server version still supported by Microsoft.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Regex = "(?:Windows)(\d{4})"
    $DomainFunctionalLevel = (Get-ADDomain).DomainMode
    If ($DomainFunctionalLevel -match $Regex) {
        If ($Matches[1] -lt 2008) {
            $Status = "Open"
            $FindingDetails += "The domain function level is NOT 2008 or newer" | Out-String
            $FindingDetails += "" | Out-String
        }
        Else {
            $Status = "NotAFinding"
            $FindingDetails += "The domain function level is 2008 or newer" | Out-String
            $FindingDetails += "" | Out-String
        }
        $FindingDetails += "Domain Level: $($DomainFunctionalLevel)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243481 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243481
        STIG ID    : AD.0170
        Rule ID    : SV-243481r723478_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Access to need-to-know information must be restricted to an authorized community of interest.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainTrusts = Get-ADTrust -Filter *

    If (($DomainTrusts | Measure-Object).Count -eq 0) {
        $Status = "Not_Applicable"
        $FindingDetails += "No trusts are configured so this requirement is NA."
    }
    Else {
        $FindingDetails += "Domain Trusts" | Out-String
        $FindingDetails += "========================" | Out-String
        ForEach ($Trust in $DomainTrusts) {

            $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
            If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
            }
            $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
            $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
            $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
            $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
            $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
            $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
            $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
            $FindingDetails += "Trust Attributes: "
            If (($Attributes | Measure-Object).Count -gt 1) {
                For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                    If ($i -eq 0) {
                        $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                    }
                    Else {
                        $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                    }
                }
            }
            Else {
                $FindingDetails += "`t`t`t$($Attributes)" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243482 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243482
        STIG ID    : AD.0180
        Rule ID    : SV-243482r723481_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Interconnections between DoD directory services of different classification levels must use a cross-domain solution that is approved for use with inter-classification trusts.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainTrusts = Get-ADTrust -Filter *

    If (($DomainTrusts | Measure-Object).Count -eq 0) {
        $Status = "Not_Applicable"
        $FindingDetails += "No trusts are configured so this requirement is NA."
    }
    Else {
        $FindingDetails += "Domain Trusts" | Out-String
        $FindingDetails += "========================" | Out-String
        ForEach ($Trust in $DomainTrusts) {
            $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
            If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
            }
            $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
            $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
            $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
            $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
            $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
            $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
            $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
            $FindingDetails += "Trust Attributes: "
            If (($Attributes | Measure-Object).Count -gt 1) {
                For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                    If ($i -eq 0) {
                        $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                    }
                    Else {
                        $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                    }
                }
            }
            Else {
                $FindingDetails += "`t`t`t$($Attributes)" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243483 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243483
        STIG ID    : AD.0181
        Rule ID    : SV-243483r723559_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : A controlled interface must have interconnections among DoD information systems operating between DoD and non-DoD systems or networks.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainTrusts = Get-ADTrust -Filter *

    If (($DomainTrusts | Measure-Object).Count -eq 0) {
        $Status = "Not_Applicable"
        $FindingDetails += "No trusts are configured so this requirement is NA."
    }
    Else {
        $FindingDetails += "Domain Trusts" | Out-String
        $FindingDetails += "========================" | Out-String
        ForEach ($Trust in $DomainTrusts) {
            $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
            If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
            }
            $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
            $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
            $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
            $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
            $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
            $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
            $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
            $FindingDetails += "Trust Attributes: "
            If (($Attributes | Measure-Object).Count -gt 1) {
                For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                    If ($i -eq 0) {
                        $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                    }
                    Else {
                        $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                    }
                }
            }
            Else {
                $FindingDetails += "`t`t`t$($Attributes)" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243484 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243484
        STIG ID    : AD.0190
        Rule ID    : SV-243484r723487_rule
        CCI ID     : CCI-000764
        Rule Name  : SRG-OS-000104
        Rule Title : Security identifiers (SIDs) must be configured to use only authentication data of directly trusted external or forest trust.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainTrusts = Get-ADTrust -Filter *

    If (($DomainTrusts | Measure-Object).Count -eq 0) {
        $Status = "Not_Applicable"
        $FindingDetails += "No trusts are configured so this requirement is NA."
    }
    Else {
        $Compliant = $true
        $BadTrust = @()
        $GoodTrust = @()
        ForEach ($Trust in $DomainTrusts) {
            $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
            If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                If ($Trust.SIDFIlteringForestAware -eq $false) {
                    $Compliant = $False
                    $BadTrust += $Trust
                }
                Else {
                    $GoodTrust += $Trust
                }
            }
            Else {
                If ($Trust.SIDFilterQuarantined -eq $false) {
                    $Compliant = $false
                    $BadTrust += $Trust
                }
                Else {
                    $GoodTrust += $Trust
                }
            }
        }

        If (($BadTrust | Measure-Object).Count -gt 0) {
            $FindingDetails += "Non-Compliant Domain Trusts" | Out-String
            $FindingDetails += "========================" | Out-String
            ForEach ($Trust in $BadTrust) {
                $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
                If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                    $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
                }
                Else {
                    $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
                }
                $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
                $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
                $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
                $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
                $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
                $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
                $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
                $FindingDetails += "Trust Attributes: "
                If (($Attributes | Measure-Object).Count -gt 1) {
                    For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                        If ($i -eq 0) {
                            $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                        }
                        Else {
                            $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                        }
                    }
                }
                Else {
                    $FindingDetails += "`t`t`t$($Attributes)" | Out-String
                }
                $FindingDetails += "" | Out-String
            }
        }
        If (($GoodTrust | Measure-Object).Count -gt 0) {
            $FindingDetails += "Compliant Domain Trusts" | Out-String
            $FindingDetails += "========================" | Out-String
            ForEach ($Trust in $GoodTrust) {
                $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
                If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                    $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
                }
                Else {
                    $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
                }
                $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
                $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
                $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
                $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
                $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
                $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
                $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
                $FindingDetails += "Trust Attributes: "
                If (($Attributes | Measure-Object).Count -gt 1) {
                    For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                        If ($i -eq 0) {
                            $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                        }
                        Else {
                            $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                        }
                    }
                }
                Else {
                    $FindingDetails += "`t`t`t$($Attributes)" | Out-String
                }
                $FindingDetails += "" | Out-String
            }
        }
        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243485 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243485
        STIG ID    : AD.0200
        Rule ID    : SV-243485r723490_rule
        CCI ID     : CCI-000213
        Rule Name  : SRG-OS-000080
        Rule Title : Selective Authentication must be enabled on outgoing forest trusts.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Trusts = Get-ADTrust -Filter *
    If (($Trusts | Measure-Object).Count -eq 0) {
        $Status = "Not_Applicable"
        $FindingDetails += "No trusts are configured so this requirement is NA."
    }
    Else {
        $Compliant = $true
        $ForestTrusts = @()
        $BadTrust = @()
        $GoodTrust = @()
        ForEach ($Trust in $Trusts) {
            $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
            If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                $ForestTrusts += $Trust
            }
        }

        If (($ForestTrusts | Measure-Object).Count -eq 0) {
            $Status = "NotAFinding"
            $FindingDetails += "No forest trusts are configured." | Out-String
        }
        ElseIf (-Not($ForestTrusts.Direction -eq "Outbound")) {
            $Status = "NotAFinding"
            $FindingDetails += "No outbound forest trusts are configured." | Out-String
        }
        Else {
            ForEach ($Trust in $ForestTrusts) {
                If ($Trust.SelectiveAuthentication -eq $false) {
                    $Compliant = $False
                    $BadTrust += $Trust
                }
                Else {
                    $GoodTrust += $Trust
                }
            }

            If (($BadTrust | Measure-Object).Count -gt 0) {
                $FindingDetails += "Non-Compliant Domain Trusts" | Out-String
                $FindingDetails += "========================" | Out-String

                ForEach ($Trust in $BadTrust) {
                    $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
                    If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                        $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
                    }
                    Else {
                        $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
                    }
                    $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
                    $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
                    $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
                    $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
                    $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
                    $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
                    $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
                    $FindingDetails += "Trust Attributes: "
                    If (($Attributes | Measure-Object).Count -gt 1) {
                        For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                            If ($i -eq 0) {
                                $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                            }
                            Else {
                                $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                            }
                        }
                    }
                    Else {
                        $FindingDetails += "`t`t`t$($Attributes)" | Out-String
                    }
                    $FindingDetails += "" | Out-String
                }
            }

            If (($GoodTrust | Measure-Object).Count -gt 0) {
                $FindingDetails += "Compliant Domain Trusts" | Out-String
                $FindingDetails += "========================" | Out-String
                ForEach ($Trust in $GoodTrust) {
                    $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
                    If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                        $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
                    }
                    Else {
                        $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
                    }
                    $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
                    $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
                    $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
                    $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
                    $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
                    $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
                    $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
                    $FindingDetails += "Trust Attributes: "
                    If (($Attributes | Measure-Object).Count -gt 1) {
                        For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                            If ($i -eq 0) {
                                $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                            }
                            Else {
                                $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                            }
                        }
                    }
                    Else {
                        $FindingDetails += "`t`t`t$($Attributes)" | Out-String
                    }
                    $FindingDetails += "" | Out-String
                }
            }
            If ($Compliant -eq $true) {
                $Status = "NotAFinding"
            }
            Else {
                $Status = "Open"
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243486 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243486
        STIG ID    : AD.0220
        Rule ID    : SV-243486r723493_rule
        CCI ID     : CCI-000804
        Rule Name  : SRG-OS-000121
        Rule Title : The Anonymous Logon and Everyone groups must not be members of the Pre-Windows 2000 Compatible Access group.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $MemberGroup = "Pre-Windows 2000 Compatible Access"
    $Users = Get-ADGroupMember -identity $MemberGroup -Recursive | Where-Object {$_.Name -eq "Everyone" -or $_.Name -eq "Anonymous Logon"}

    If (($Users | Measure-Object).Count -gt 0) {
        $Status = "Open"
        If ($Users -contains "Anonymous Logon") {
            $FindingDetails += "'Anonymous Logon' is a member of '$($MemberGroup)'" | Out-String
        }
        Else {
            $FindingDetails += "'Everyone' is a member of '$($MemberGroup)'" | Out-String
        }
    }
    Else {
        $Status = "NotAFinding"
        $FindingDetails += "Both 'Anonymous Logon' and 'Everyone' are not members of '$MemberGroup'."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243487 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243487
        STIG ID    : AD.0240
        Rule ID    : SV-243487r723496_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Membership in the Group Policy Creator Owners and Incoming Forest Trust Builders groups must be limited.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Compliant = $true
    $Groups = @("Incoming Forest Trust Builders", "Group Policy Creator Owners")

    ForEach ($Group in $Groups) {
        $ReturnedUsers = Get-ADGroupMember -Identity $Group -Recursive | Select-Object name, SamAccountName, distinguishedName | Sort-Object SamAccountName -Unique
        If (($ReturnedUsers | Measure-Object).Count -eq 0) {
            $FindingDetails += "No Users are in the '$($Group)' Group" | Out-String
        }
        Else {
            $Compliant = $false
            $FindingDetails += "Members of '$($Group)'" | Out-String
            $FindingDetails += "=========================" | Out-String
            ForEach ($User in $ReturnedUsers) {
                $FindingDetails += $User.Name | Out-String
            }
        }
        $FindingDetails += "" | Out-String
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243489 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243489
        STIG ID    : AD.0270
        Rule ID    : SV-243489r723564_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Read-only Domain Controller (RODC) architecture and configuration must comply with directory services requirements.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainName = (Get-ADDomain).DNSRoot
    $AllDCs = Get-ADDomainController -Filter * -Server $DomainName | Select-Object HostName, OperatingSystem, IPv4Address, IPv6Address, Forest, Site, IsGlobalCatalog, IsReadOnly

    If ($AllDCs.IsReadOnly -eq $true) {
        $FindingDetails += "Read-only domain controllers (RODC):"
        $FindingDetails += "====================================" | Out-String
        ForEach ($DC in ($AllDCs | Where-Object IsReadOnly -EQ $true)) {
            $FindingDetails += "Hostname:`t`t$($DC.HostName)" | Out-String
            $FindingDetails += "OperatingSystem:`t$($DC.OperatingSystem)" | Out-String
            $FindingDetails += "IPv4Address:`t`t$($DC.IPv4Address)" | Out-String
            $FindingDetails += "IPv6Address:`t`t$($DC.IPv6Address)" | Out-String
            $FindingDetails += "Forest:`t`t`t$($DC.Forest)" | Out-String
            $FindingDetails += "Site:`t`t`t`t$($DC.Site)" | Out-String
            $FindingDetails += "IsGlobalCatalog:`t$($DC.IsGlobalCatalog)" | Out-String
            $FindingDetails += "IsReadOnly:`t`t$($DC.IsReadOnly)" | Out-String
            $FindingDetails += "" | Out-String
        }
    }
    Else {
        $Status = "NotAFinding"
        $FindingDetails += "No read-only domain controllers (RODC) exist in the domain." | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243490 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243490
        STIG ID    : AD.AU.0001
        Rule ID    : SV-243490r723505_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Usage of administrative accounts must be monitored for suspicious and anomalous activity.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $AuditCategorys = @("Logon", "User Account Management", "Account Lockout", "Security Group Management") #As specified in the STIG
    #$SettingState = "Success" #As specified in the STIG
    ForEach ($AuditCategory in $AuditCategorys) {
        Try {

            $Policy = (auditpol /get /subcategory:$AuditCategory | Where-Object { $_ -Match "\s$($AuditCategory)" }).Trim() #Returns a string
            If ( $Policy -Match "  [SNF].*$") {
                #Regex to essentially grab the last phrase in the string. Either "Success", "Failure", "Success or Failure", or "No Auditing"
                $Policy = $Matches[0].Trim() #Trim the two spaces before what was matched. '$Policy -Match' returns true/false, '$Matches' is the system variable -Match places anything it finds.
            }
            $Status = "NotAFinding"
            $FindingDetails += "Category:`t`t$($AuditCategory)" | Out-String
            $FindingDetails += "Audit On:`t`t$($Policy)" | Out-String
            $FindingDetails += "" | Out-String

        }
        Catch {
            #If the policy isn't configured as we want, it won't be found and will throw an error.
            $Status = "Open"
            $FindingDetails += "'$($AuditCategory)' is NOT configured to audit." | Out-String
        }
    }

    $FindingDetails += "" | Out-String
    $FindingDetails += "Queries of Events" | Out-String
    $FindingDetails += "=====================" | Out-String

    $EventIDs = @("4740", "4728", "4732", "4756", "4624", "4625", "4648")

    ForEach ($EventID in $EventIDs) {
        $ReturnedEvent = Get-WinEvent -ErrorAction SilentlyContinue @{logname = 'system', 'application', 'security'; ID = $EventID} -MaxEvents 1 | Select-Object ContainerLog, ID, LevelDisplayName, Message, TimeCreated
        If ($Null -eq $ReturnedEvent) {
            $FindingDetails += "No event was found for EventID: $($EventID)" | Out-String
            $FindingDetails += "" | Out-String
        }
        Else {
            $ReturnedEvent.Message -match "^.*?\." | Out-Null
            $Message = $matches[0]
            $FindingDetails += "Event ID:`t`t`t$($ReturnedEvent.ID)" | Out-String
            $FindingDetails += "Message:`t`t`t$($Message)" | Out-String
            $FindingDetails += "Level:`t`t`t$($ReturnedEvent.LevelDisplayName)" | Out-String
            $FindingDetails += "Container Log:`t`t$($ReturnedEvent.ContainerLog)" | Out-String
            $FindingDetails += "Time Created:`t`t$($ReturnedEvent.TimeCreated)" | Out-String
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243491 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243491
        STIG ID    : AD.AU.0002
        Rule ID    : SV-243491r723508_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Systems must be monitored for attempts to use local accounts to log on remotely from other systems.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $AuditCategorys = @("Logon", "Account Lockout") #As specified in the STIG
    #$SettingState = "Success" #As specified in the STIG
    ForEach ($AuditCategory in $AuditCategorys) {
        Try {

            $Policy = (auditpol /get /subcategory:$AuditCategory | Where-Object { $_ -Match "\s$($AuditCategory)" }).Trim() #Returns a string
            If ( $Policy -Match "  [SNF].*$") {
                #Regex to essentially grab the last phrase in the string. Either "Success", "Failure", "Success or Failure", or "No Auditing"
                $Policy = $Matches[0].Trim() #Trim the two spaces before what was matched. '$Policy -Match' returns true/false, '$Matches' is the system variable -Match places anything it finds.
            }
            $Status = "NotAFinding"
            $FindingDetails += "Category:`t`t$($AuditCategory)" | Out-String
            $FindingDetails += "Audit On:`t`t$($Policy)" | Out-String
            $FindingDetails += "" | Out-String

        }
        Catch {
            #If the policy isn't configured as we want, it won't be found and will throw an error.
            $Status = "Open"
            $FindingDetails += "'$($AuditCategory)' is NOT configured to audit." | Out-String
        }
    }

    $FindingDetails += "" | Out-String
    $FindingDetails += "Queries of Events" | Out-String
    $FindingDetails += "=====================" | Out-String

    $EventIDs = @("4624", "4625")

    ForEach ($EventID in $EventIDs) {
        $params = @{
            logname                   = 'system', 'security'
            ID                        = $EventID
            LogonType                 = '3'
            AuthenticationPackageName = 'NTLM'
        }
        $ReturnedEvent = Get-WinEvent -ErrorAction SilentlyContinue $params | Select-Object ContainerLog, ID, LevelDisplayName, Message, TimeCreated, Properties | Where-Object {$_.Properties[5].Value -ne "ANONYMOUS LOGON" -and $_.Properties[6].Value -notin $(Get-CimInstance Win32_NTDomain).DomainName | Select-Object -First 1}

        If ($Null -eq $ReturnedEvent) {
            $FindingDetails += "No event was found for EventID: $($EventID)" | Out-String
            $FindingDetails += "" | Out-String
        }
        Else {
            $ReturnedEvents[0].Message -match "^.*?\." | Out-Null
            $Message = $matches[0]
            $FindingDetails += "Event ID:`t`t`t$($ReturnedEvent.ID)" | Out-String
            $FindingDetails += "Message:`t`t`t$($Message)" | Out-String
            $FindingDetails += "User:`t`t`t$($ReturnedEvent.Properties[5].Value)" | Out-String
            $FindingDetails += "Domain:`t`t`t$($ReturnedEvent.Properties[6].Value)" | Out-String
            $FindingDetails += "Level:`t`t`t$($ReturnedEvent.LevelDisplayName)" | Out-String
            $FindingDetails += "Container Log:`t`t$($ReturnedEvent.ContainerLog)" | Out-String
            $FindingDetails += "Time Created:`t`t$($ReturnedEvent.TimeCreated)" | Out-String
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243492 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243492
        STIG ID    : AD.AU.0003
        Rule ID    : SV-243492r723511_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Systems must be monitored for remote desktop logons.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $AuditCategorys = @("Logon") #As specified in the STIG
    #$SettingState = "Success" #As specified in the STIG
    ForEach ($AuditCategory in $AuditCategorys) {
        Try {

            $Policy = (auditpol /get /subcategory:$AuditCategory | Where-Object { $_ -Match "\s$($AuditCategory)" }).Trim() #Returns a string
            If ( $Policy -Match "  [SNF].*$") {
                #Regex to essentially grab the last phrase in the string. Either "Success", "Failure", "Success or Failure", or "No Auditing"
                $Policy = $Matches[0].Trim() #Trim the two spaces before what was matched. '$Policy -Match' returns true/false, '$Matches' is the system variable -Match places anything it finds.
            }
            $Status = "NotAFinding"
            $FindingDetails += "Category:`t`t$($AuditCategory)" | Out-String
            $FindingDetails += "Audit On:`t`t$($Policy)" | Out-String
            $FindingDetails += "" | Out-String

        }
        Catch {
            #If the policy isn't configured as we want, it won't be found and will throw an error.
            $Status = "Open"
            $FindingDetails += "'$($AuditCategory)' is NOT configured to audit." | Out-String
        }
    }

    $FindingDetails += "" | Out-String
    $FindingDetails += "Queries of Events" | Out-String
    $FindingDetails += "=====================" | Out-String

    $EventIDs = @("4624")

    ForEach ($EventID in $EventIDs) {

        $ReturnedEvent = Get-WinEvent -ErrorAction SilentlyContinue @{logname = 'system', 'application', 'security'; ID = $EventID; LogonType = '10'; AuthenticationPackageName = 'Negotiate'} | Select-Object -First 1 ContainerLog, ID, LevelDisplayName, Message, TimeCreated, Properties
        If ($Null -eq $ReturnedEvent) {
            $FindingDetails += "No event was found for EventID: $($EventID)" | Out-String
            $FindingDetails += "" | Out-String
        }
        Else {
            $ReturnedEvent.Message -match "^.*?\." | Out-Null
            $Message = $matches[0]
            $FindingDetails += "Event ID:`t`t`t$($ReturnedEvent.ID)" | Out-String
            $FindingDetails += "Message:`t`t`t$($Message)" | Out-String
            $FindingDetails += "Logon Type:`t`t`t$($ReturnedEvent.Properties[8].Value)" | Out-String
            $FindingDetails += "Authentication Package Name:`t$($ReturnedEvent.Properties[10].Value)" | Out-String
            $FindingDetails += "Level:`t`t`t`t$($ReturnedEvent.LevelDisplayName)" | Out-String
            $FindingDetails += "Container Log:`t`t`t$($ReturnedEvent.ContainerLog)" | Out-String
            $FindingDetails += "Time Created:`t`t`t$($ReturnedEvent.TimeCreated)" | Out-String
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243494 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243494
        STIG ID    : DS00.1120_AD
        Rule ID    : SV-243494r723517_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Each cross-directory authentication configuration must be documented.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainTrusts = Get-ADTrust -Filter *

    If (($DomainTrusts | Measure-Object).Count -eq 0) {
        $Status = "Not_Applicable"
        $FindingDetails += "No trusts are configured so this requirement is NA."
    }
    Else {
        $FindingDetails += "Domain Trusts" | Out-String
        $FindingDetails += "========================" | Out-String
        ForEach ($Trust in $DomainTrusts) {

            $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
            If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
            }
            $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
            $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
            $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
            $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
            $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
            $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
            $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
            $FindingDetails += "Trust Attributes: "
            If (($Attributes | Measure-Object).Count -gt 1) {
                For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                    If ($i -eq 0) {
                        $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                    }
                    Else {
                        $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                    }
                }
            }
            Else {
                $FindingDetails += "`t`t`t$($Attributes)" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243495 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243495
        STIG ID    : DS00.1140_AD
        Rule ID    : SV-243495r723520_rule
        CCI ID     : CCI-002418
        Rule Name  : SRG-OS-000423
        Rule Title : A VPN must be used to protect directory network traffic for directory service implementation spanning enclave boundaries.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainName = (Get-ADDomain).DNSRoot
    $AllDCs = Get-ADDomainController -Filter * -Server $DomainName | Select-Object HostName, OperatingSystem, IPv4Address, IPv6Address, Forest, Site, IsGlobalCatalog, IsReadOnly

    ForEach ($DC in $AllDCs) {
        $FindingDetails += "Hostname:`t`t$($DC.HostName)" | Out-String
        $FindingDetails += "OperatingSystem:`t$($DC.OperatingSystem)" | Out-String
        $FindingDetails += "IPv4Address:`t`t$($DC.IPv4Address)" | Out-String
        $FindingDetails += "IPv6Address:`t`t$($DC.IPv6Address)" | Out-String
        $FindingDetails += "Forest:`t`t`t$($DC.Forest)" | Out-String
        $FindingDetails += "Site:`t`t`t`t$($DC.Site)" | Out-String
        $FindingDetails += "IsGlobalCatalog:`t$($DC.IsGlobalCatalog)" | Out-String
        $FindingDetails += "IsReadOnly:`t`t$($DC.IsReadOnly)" | Out-String
        $FindingDetails += "" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243496 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243496
        STIG ID    : DS00.3200_AD
        Rule ID    : SV-243496r804648_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Accounts from outside directories that are not part of the same organization or are not subject to the same security policies must be removed from all highly privileged groups.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $Compliant = $true
    $Groups = @("Incoming Forest Trust Builders", "Group Policy Creator Owners", "Domain Admins", "Enterprise Admins", "Schema Admins")
    ForEach ($dc in ((Get-CimInstance Win32_ComputerSystem).Domain).ToString().Split(".")) {
        $LdapDomain += ",dc=$($dc)"
    }
    ForEach ($Group in $Groups) {
        $ReturnedUsers = Get-ADGroupMember -Identity $Group -Recursive | Select-Object name, SamAccountName, distinguishedName | Sort-Object Name -Unique
        If (($ReturnedUsers | Measure-Object).Count -eq 0) {
            $FindingDetails += "No Users are in the '$($Group)' Group" | Out-String
        }
        Else {
            If ($ReturnedUsers.DistingishedName -like "*$($LdapDomain)") {
                $Domain = (Get-CimInstance Win32_ComputerSystem).Domain
                $FindingDetails += "Accounts from outside '$($Domain)' exist"
                $Compliant = $false
            }
            $FindingDetails += "Members of '$($Group)'" | Out-String
            $FindingDetails += "=========================" | Out-String
            ForEach ($User in $ReturnedUsers) {
                $FindingDetails += "Name:`t`t`t`t$($User.name)" | Out-String
                $FindingDetails += "SamAccountName:`t`t$($User.SamAccountName)" | Out-String
                $FindingDetails += "DistinguishedName:`t$($User.distinguishedName)" | Out-String
                $FindingDetails += "" | Out-String
            }
        }
        $FindingDetails += "" | Out-String
    }

    If ($compliant -eq $true) {
        $Status = "NotAFinding"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243497 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243497
        STIG ID    : DS00.3230_AD
        Rule ID    : SV-243497r723526_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Inter-site replication must be enabled and configured to occur at least daily.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $ADSites = Get-ADReplicationSite -Filter * -Properties *
    If (($ADSites | Measure-Object).Count -eq 1) {
        $Status = "Not_Applicable"
        $FindingDetails += "Only one site exists so this requirement is NA." | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Site: $($ADSites.Name)" | Out-String
    }
    Else {
        $Compliant = $true
        $FindingDetails += "Replication Frequency of Sites" | Out-String
        $FindingDetails += "===============================" | Out-String
        $FindingDetails += "" | Out-String
        ForEach ($Site in $ADSites) {
            $SiteLink = Get-ADReplicationSiteLink -Identity "$($Site.Name)" -Properties *
            $FindingDetails += "Name:`t`t`t$($Site.Name)" | Out-String
            If ($SiteLink.ReplicationFrequencyInMinutes -gt 1440) {
                $Compliant = $false
                $FindingDetails += "Replication Interval is NOT Configured" | Out-String
                $FindingDetails += "Replication Frequency:`t$($SiteLink.ReplicationFrequencyInMinutes) [Expected: 1440 or less]" | Out-String
            }
            Else {
                $FindingDetails += "Replication Frequency:`t$($SiteLink.ReplicationFrequencyInMinutes)" | Out-String
            }

            $TimeSlotsWithoutReplication = 0
            For ($i = 20; $i -lt (($SiteLink.Schedule) | Measure-Object).Count; $i++) {
                #Run through the replication schedule. There are 288 bytes in total, with the first 20 being a header.
                If ($SiteLink.Schedule[$i] -eq 240) {
                    #If the value equals 255, replication is set to happen; if 240, replication will not happen.
                    $TimeSlotsWithoutReplication += 1
                    If ($TimeSlotsWithoutReplication -eq 24) {
                        $Compliant = $false
                        $FindingDetails += "There are 24 hours with no replication" | Out-String
                    }
                }
                Else {
                    $TimeSlotsWithoutReplication = 0
                }
            }
            $FindingDetails += "" | Out-String
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243498 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243498
        STIG ID    : DS00.4140_AD
        Rule ID    : SV-243498r723529_rule
        CCI ID     : CCI-000067
        Rule Name  : SRG-OS-000032
        Rule Title : If a VPN is used in the AD implementation, the traffic must be inspected by the network Intrusion detection system (IDS).
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainName = (Get-ADDomain).DNSRoot
    $AllDCs = Get-ADDomainController -Filter * -Server $DomainName | Select-Object HostName, OperatingSystem, IPv4Address, IPv6Address, Forest, Site, IsGlobalCatalog, IsReadOnly

    ForEach ($DC in $AllDCs) {
        $FindingDetails += "Hostname:`t`t$($DC.HostName)" | Out-String
        $FindingDetails += "OperatingSystem:`t$($DC.OperatingSystem)" | Out-String
        $FindingDetails += "IPv4Address:`t`t$($DC.IPv4Address)" | Out-String
        $FindingDetails += "IPv6Address:`t`t$($DC.IPv6Address)" | Out-String
        $FindingDetails += "Forest:`t`t`t$($DC.Forest)" | Out-String
        $FindingDetails += "Site:`t`t`t`t$($DC.Site)" | Out-String
        $FindingDetails += "IsGlobalCatalog:`t$($DC.IsGlobalCatalog)" | Out-String
        $FindingDetails += "IsReadOnly:`t`t$($DC.IsReadOnly)" | Out-String
        $FindingDetails += "" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243500 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243500
        STIG ID    : DS00.6140_AD
        Rule ID    : SV-243500r723535_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Active Directory must be supported by multiple domain controllers where the Risk Management Framework categorization for Availability is moderate or high.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainName = (Get-ADDomain).DNSRoot
    $AllDCs = Get-ADDomainController -Filter * -Server $DomainName | Select-Object HostName, OperatingSystem, IPv4Address, IPv6Address, Forest, Site, IsGlobalCatalog, IsReadOnly

    If (($AllDCs | Measure-Object).Count -eq 1) {
        $FindingDetails += "Only one domain controller exists in the domain.  If Availability categorization is low, mark as NA.  Otherwise, mark as Open." | Out-String
        $FindingDetails += "" | Out-String
    }
    Else {
        $Status = "NotAFinding"
        $FindingDetails += "Multiple domain controllers exist in the domain." | Out-String
        $FindingDetails += "" | Out-String
    }

    ForEach ($DC in $AllDCs) {
        $FindingDetails += "Hostname:`t`t$($DC.HostName)" | Out-String
        $FindingDetails += "OperatingSystem:`t$($DC.OperatingSystem)" | Out-String
        $FindingDetails += "IPv4Address:`t`t$($DC.IPv4Address)" | Out-String
        $FindingDetails += "IPv6Address:`t`t$($DC.IPv6Address)" | Out-String
        $FindingDetails += "Forest:`t`t`t$($DC.Forest)" | Out-String
        $FindingDetails += "Site:`t`t`t`t$($DC.Site)" | Out-String
        $FindingDetails += "IsGlobalCatalog:`t$($DC.IsGlobalCatalog)" | Out-String
        $FindingDetails += "IsReadOnly:`t`t$($DC.IsReadOnly)" | Out-String
        $FindingDetails += "" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V243501 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243501
        STIG ID    : DS00.7100_AD
        Rule ID    : SV-243501r723557_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : The impact of INFOCON changes on the cross-directory authentication configuration must be considered and procedures documented.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainTrusts = Get-ADTrust -Filter *

    If (($DomainTrusts | Measure-Object).Count -eq 0) {
        $Status = "Not_Applicable"
        $FindingDetails += "No trusts are configured so this requirement is NA."
    }
    Else {
        $FindingDetails += "Domain Trusts" | Out-String
        $FindingDetails += "========================" | Out-String
        ForEach ($Trust in $DomainTrusts) {

            $Attributes = (Get-TrustAttributes).Keys | Where-Object {$_ -band $Trust.TrustAttributes} | ForEach-Object {(Get-TrustAttributes).Get_Item($_)}
            If ($Attributes -contains (Get-TrustAttributes).Get_Item(8)) {
                $FindingDetails += "Type:`t`t`t`t`tForest Trust" | Out-String
            }
            Else {
                $FindingDetails += "Type:`t`t`t`t`tExternal Trust" | Out-String
            }
            $FindingDetails += "Domain:`t`t`t`t`t$($Trust.Target)" | Out-String
            $FindingDetails += "Direction:`t`t`t`t`t$($Trust.Direction)" | Out-String
            $FindingDetails += "Disallow Transitivity:`t`t$($Trust.DisallowTransivity)" | Out-String
            $FindingDetails += "Forest Transitive:`t`t`t$($Trust.ForestTransitive)" | Out-String
            $FindingDetails += "Selective Authentication:`t`t$($Trust.SelectiveAuthentication)" | Out-String
            $FindingDetails += "SID Filtering Forest Aware:`t$($Trust.SIDFilteringForestAware)" | Out-String
            $FindingDetails += "SID Filtering Quarantined:`t$($Trust.SIDFilteringQuarantined)" | Out-String
            $FindingDetails += "Trust Attributes: "
            If (($Attributes | Measure-Object).Count -gt 1) {
                For ($i = 0; $i -lt ($Attributes | Measure-Object).Count; $i++) {
                    If ($i -eq 0) {
                        $FindingDetails += "`t`t`t$($Attributes[$i])" | Out-String
                    }
                    Else {
                        $FindingDetails += "`t`t`t`t`t`t$($Attributes[$i])" | Out-String
                    }
                }
            }
            Else {
                $FindingDetails += "`t`t`t$($Attributes)" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}


# SIG # Begin signature block
# MIIL1AYJKoZIhvcNAQcCoIILxTCCC8ECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUDr7Ttxjo4pzp4jS+Cl3/ytAo
# OgKgggk7MIIEejCCA2KgAwIBAgIEAwIE1zANBgkqhkiG9w0BAQsFADBaMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MB4XDTIwMDcxNTAw
# MDAwMFoXDTI1MDQwMjEzMzgzMlowaTELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxDDAKBgNV
# BAsTA1VTTjEWMBQGA1UEAxMNQ1MuTlNXQ0NELjAwMTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANv2fdTmx2dNPQ47F8kmvU+g20/sFoF+DS3k2GcMduuI
# XxYFJyMMPAvTJuobeJlX6P6sr5jAKhXXsoV4lT2boWw583Snl6cuSfqMbVowIJ1s
# CffN7N0VXsLVdOt1u5GCKs4/jXH7MeEOE0oJsgEjjE1IZc5tEqj++s1N1EUY+jf/
# zc8QHDjy5X88XBTzKVhwvczZVbRahrcmYv0k4we3ndwTl5nXYizSwi96CZuqzrIn
# WbLSsRLNyNZZVo7J5bZ+30dv/hZvq6FqxfAeM3pEDrvbfFkWXzaISqF1bVbsMlAC
# UBf/JFbSGtmMsU1ABfXKPalTWYJKP58dICHcUocZhL0CAwEAAaOCATcwggEzMB8G
# A1UdIwQYMBaAFHUJphUTroc8+nOUAPLw9Xm5snIUMEEGA1UdHwQ6MDgwNqA0oDKG
# MGh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNTlfTkNPREVTSUdOLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyowHQYDVR0O
# BBYEFFbrF3OpzfdsZkN1zTfv++oaLCRRMGUGCCsGAQUFBwEBBFkwVzAzBggrBgEF
# BQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNTkuY2VyMCAG
# CCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAWBgorBgEE
# AYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAQknaIAXDnyqshmyh
# uOZS4nBtSydnZrdB8Je0JCq2TTRA4dkNvrswe0kZgA7UjlY1X/9PtQeIwaMrcvdF
# i+dqzD1bbW/LX5tH/1oMOp4s+VkGfl4xUUxUGjO6QTVOeLyN2x+DBQU11DhKEq9B
# RCxUGgclFn1iqxi5xKmLaQ3XuRWRGCkb+rXejWR+5uSTognxCuoLp95bqu3JL8ec
# yF46+VSoafktAGot2Uf3qmwWdMHFBdwzmJalbC4j09I1qJqcJH0p8Wt34zRw/hSr
# 3f+xDEDP8GNL2ciDm7aN0GKy67ugjgMmPXAv7A4/keCuN/dsNS1naNyqzc5AhTAF
# +o/21jCCBLkwggOhoAMCAQICAgMFMA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTE5MDQwMjEzMzgz
# MloXDTI1MDQwMjEzMzgzMlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4g
# R292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMT
# DERPRCBJRCBDQS01OTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMwX
# hJ8twQpXrRFNNVc/JEcvHA9jlr27cDE8rpxWkobvpCJOoOVUbJ724Stx6OtTAZpR
# iXNaS0jjRgYaW6cq9pdnjjQM5ovHPPde1ewaZyWb2I+uqhkZmOBV1+lGUOhnQCyi
# nnSSqzEH1PC5nASfyxnCdBeOt+UKHBrPVKBUuYS4Fcn5Q0wv+sfBD24vyV5Ojeoq
# HeSSAMTaeqlv+WQb4YrjKNfaGF+S7lMvQelu3ANHEcoL2HMCimCvnCHQaMQI9+Ms
# NhySPEULePdEDxgpWYc9FmBbjUp1CYEx7HYdlTRJ9gBHts2ITxTZQrt4Epjkqeb8
# aWVmzCEPHE7+KUVhuO8CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyKlKJ3sYBy
# HYF6Fqry3M5m7kXAMB0GA1UdDgQWBBR1CaYVE66HPPpzlADy8PV5ubJyFDAOBgNV
# HQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsn
# MAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgB
# ZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQE
# BTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3Js
# L0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0
# cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3YzAgBggr
# BgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQELBQADggEB
# ADkFG9IOpz71qHNXCeYJIcUshgN20CrvB5ym4Pr7zKTBRMKNqd9EXWBxrwP9xhra
# 5YcQagHDqnmBeU3F2ePhWvQmyhPwIJaArk4xGLdv9Imkr3cO8vVapO48k/R9ZRSA
# EBxzd0xMDdZ6+xxFlZJIONRlxcVNNVB30e74Kk08/t82S9ogqgA1Q7KZ2tFuaRes
# jJWuoJ+LtE5lrtknqgaXLb3XH0hV5M0AWRk9Wg/1thb9NCsKEIAdpdnolZOephIz
# fzHiOSqeJ+e5qURLB7rT+F5y0NNWTdqoJ/vOOCUa8z0NKWsz2IkpeD3iNhVCLRKw
# Ojm/wzxdG2tst5OHRZFEwKcxggIDMIIB/wIBATBiMFoxCzAJBgNVBAYTAlVTMRgw
# FgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMD
# UEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNTkCBAMCBNcwCQYFKw4DAhoFAKB4MBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYE
# FM0ozx8wBt5hxq/wZkcVccgs2brbMA0GCSqGSIb3DQEBAQUABIIBAMbmfmit40HY
# n8gRaT9rnpxVpz4SVrhevwYm2RZ8YXQ2bPvVoISqqE1wIF5WEOBs/BfnE80p9Jtc
# DEwSea5XJDkysVnih/h1eS8FCCptPbJW3mouKBq5//JFQa8NpRg668EaAqAoqXKt
# nxtlH1ETn3yBCY/pWXFLmVBhQsMIvuLkPbclvHAazQqZCUH6tTxKLcbS3F5H919I
# I4sh1Tjx6Me0JH1eckYPD+6xoTEExB80Xjdr3YP34WUJ3sPx+xm0A5xFsEFMqAMM
# 5K5vA/o3O9nSCgOxAzrIrl7567+aG9Z7Yeg5HxV5/GYuPJrEigEtBC4ObQ5EaGML
# 6K7+Wp4J1yU=
# SIG # End signature block
