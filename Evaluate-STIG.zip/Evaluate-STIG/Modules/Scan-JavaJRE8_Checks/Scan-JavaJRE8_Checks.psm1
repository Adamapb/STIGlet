##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Oracle Java Runtime Environment (JRE) Version 8 for Windows
# Version:  V2R1
# Updated:  3/11/2022
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Get-JreInstallPath {
    $JrePath = @()
    If (Test-Path 'HKLM:\SOFTWARE\JavaSoft\Java Runtime Environment\1.8') {
        $JrePath += Get-ChildItem HKLM:\SOFTWARE\JavaSoft -Recurse | Where-Object { ($_.Name -match "1.8") -and ($_.Property -match "INSTALLDIR") } | ForEach-Object { Get-ItemPropertyValue -Path $_.PsPath -Name "INSTALLDIR" }
    }
    If (Test-Path 'HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Runtime Environment\1.8') {
        $JrePath += Get-ChildItem HKLM:\SOFTWARE\WOW6432Node\JavaSoft -Recurse | Where-Object { ($_.Name -match "1.8") -and ($_.Property -match "INSTALLDIR") } | ForEach-Object { Get-ItemPropertyValue -Path $_.PsPath -Name "INSTALLDIR" }
    }

    Return $JrePath
}

Function Get-PropertyFilePath {
    param($String)

    # https://docs.oracle.com/javase/8/docs/technotes/guides/deploy/properties.html
    # Extract the path to the deployment.properties file from deployment.config
    # Currently version does not support UNC paths.
    If ($String -like 'file:*') {
        $Java_DriveLetter = (($String -split ("file"))[1] | Select-String -Pattern [a-zA-Z]).Matches[0].Value
    }
    ElseIf ($String -like 'file\:*') {
        $Java_DriveLetter = (($String -split ("file\\"))[1] | Select-String -Pattern [a-zA-Z]).Matches[0].Value
    }
    Else {
        $Java_DriveLetter = ($String | Select-String -Pattern [a-zA-Z]).Matches[0].Value
    }

    $Java_DrivePath = (($String.replace("/", "\\") | Select-String -Pattern '(\\\\?([^\/]*[\\/])*)([^\\/]+)$').Matches[0].Value) -replace ("^.*:", "")
    $Result = $Java_DriveLetter + ':' + $Java_DrivePath
    Return $Result
}

Function Get-V234683 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234683
        STIG ID    : JRE8-WN-000010
        Rule ID    : SV-234683r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must have a deployment.config file present.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in $PathsToEval) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $Compliant = $true
    If ($ConfigFiles.Count -eq 0) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found" | Out-String
    }
    Else {
        $FindingDetails += "The following config files were found:" | Out-String
        $FindingDetails += "" | Out-String
        $i = 0
        ForEach ($File in $ConfigFiles) {
            If (($ConfigFiles | Measure-Object).Count -gt 1) {
                If ($i -eq 0) {
                    $FindingDetails += "$($File.Fullname) (Will be used for further checks)" | Out-String
                }
                Else {
                    $FindingDetails += $File.Fullname | Out-String
                }
                $i++
            }
            Else {
                $FindingDetails += $File.Fullname | Out-String
            }
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234684 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234684
        STIG ID    : JRE8-WN-000020
        Rule ID    : SV-234684r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 deployment.config file must contain proper keys and values.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in $PathsToEval) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $KeysToEval = "deployment.system.config=file", `
        "deployment.system.config.mandatory=true"

    $Compliant = $true

    If (-Not($ConfigFiles)) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found" | Out-String
    }
    Else {
        $Option1Set = $false
        $Option2Set = $false
        $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
        $FindingDetails += "" | Out-String
        $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
            $Compliant = $false
            $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
        }
        Else {
            $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
            ForEach ($Line in $ConfigFileContent) {
                If (($Line -Replace "\s", "") -like "$($KeysToEval[0])*") {
                    $Option1Set = $true
                    If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                    }
                    If ($PropsPath) {
                        $PropsFile = Get-PropertyFilePath -String $PropsPath
                        If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                            $Compliant = $false
                            $FindingDetails += "$Line" | Out-String
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                        }
                        Else {
                            $FindingDetails += "$Line is present" | Out-String
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "$Line" | Out-String
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                    }
                }
                ElseIf (($Line -Replace "\s", "") -eq $KeysToEval[1]) {
                    $Option2Set = $true
                    $FindingDetails += "$Line is present" | Out-String
                }
            }

            If ($Option1Set -eq $false) {
                $Compliant = $false
                $FindingDetails += "Path to 'deployment.properties' is NOT present" | Out-String
            }
            ElseIf ($Option2Set -eq $false) {
                $Compliant = $false
                $FindingDetails += "deployment.system.config.mandatory=true is NOT present" | Out-String
            }
            $FindingDetails += "" | Out-String
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234685 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234685
        STIG ID    : JRE8-WN-000030
        Rule ID    : SV-234685r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must have a deployment.properties file present.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in $PathsToEval) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $Compliant = $true
    If ($ConfigFiles.Count -eq 0) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found" | Out-String
    }
    Else {
        $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
        $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
            $Compliant = $false
            $FindingDetails += "" | Out-String
            $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
        }
        Else {
            # Get path to deployment.properties from .config file
            $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
            ForEach ($Line in $ConfigFileContent) {
                If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                    $PropsPath = ($Line.Split("=")[1]).Trim()
                    Break
                }
            }
            If ($PropsPath) {
                $PropsFile = Get-PropertyFilePath -String $PropsPath
                $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                $FindingDetails += "" | Out-String
                If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                    $Compliant = $false
                    $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                }
                Else {
                    If (Test-Path $PropsFile) {
                        $FindingDetails += "Properties file exists in the path defined." | Out-String
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "Properties file not found in the path defined." | Out-String
                    }
                }
            }
            Else {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
            }
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234686 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234686
        STIG ID    : JRE8-WN-000060
        Rule ID    : SV-234686r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must default to the most secure built-in setting.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.security.level=VERY_HIGH", `
        "deployment.security.level.locked"

    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in $PathsToEval) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $Compliant = $true
    If ($ConfigFiles.Count -eq 0) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found" | Out-String
    }
    Else {
        $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
        $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
            $Compliant = $false
            $FindingDetails += "" | Out-String
            $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
        }
        Else {
            # Get path to deployment.properties from .config file
            $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
            ForEach ($Line in $ConfigFileContent) {
                If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                    $PropsPath = ($Line.Split("=")[1]).Trim()
                    Break
                }
            }
            If ($PropsPath) {
                $PropsFile = Get-PropertyFilePath -String $PropsPath
                $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                $FindingDetails += "" | Out-String
                If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                    $Compliant = $false
                    $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                }
                Else {
                    If (Test-Path $PropsFile) {
                        $Encoding = Get-FileEncoding -Path $PropsFile
                        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                            $Compliant = $false
                            $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                        }
                        Else {
                            $DeployFileContent = Get-Content -Path $PropsFile
                            ForEach ($Key in $KeysToEval) {
                                If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                    $FindingDetails += "$Key is present" | Out-String
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "$Key is NOT present" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "Properties file not found in the path defined." | Out-String
                    }
                }
            }
            Else {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
            }
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234687 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234687
        STIG ID    : JRE8-WN-000070
        Rule ID    : SV-234687r617446_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must be set to allow Java Web Start (JWS) applications.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.webjava.enabled=true", `
        "deployment.webjava.enabled.locked"

    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in $PathsToEval) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $Compliant = $true
    If ($ConfigFiles.Count -eq 0) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found" | Out-String
    }
    Else {
        $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
        $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
            $Compliant = $false
            $FindingDetails += "" | Out-String
            $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
        }
        Else {
            # Get path to deployment.properties from .config file
            $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
            ForEach ($Line in $ConfigFileContent) {
                If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                    $PropsPath = ($Line.Split("=")[1]).Trim()
                    Break
                }
            }
            If ($PropsPath) {
                $PropsFile = Get-PropertyFilePath -String $PropsPath
                $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                $FindingDetails += "" | Out-String
                If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                    $Compliant = $false
                    $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                }
                Else {
                    If (Test-Path $PropsFile) {
                        $Encoding = Get-FileEncoding -Path $PropsFile
                        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                            $Compliant = $false
                            $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                        }
                        Else {
                            $DeployFileContent = Get-Content -Path $PropsFile
                            ForEach ($Key in $KeysToEval) {
                                If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                    $FindingDetails += "$Key is present" | Out-String
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "$Key is NOT present" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "Properties file not found in the path defined." | Out-String
                    }
                }
            }
            Else {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
            }
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234688 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234688
        STIG ID    : JRE8-WN-000080
        Rule ID    : SV-234688r617446_rule
        CCI ID     : CCI-001695
        Rule Name  : SRG-APP-000112
        Rule Title : Oracle JRE 8 must disable the dialog enabling users to grant permissions to execute signed content from an untrusted authority.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.askgrantdialog.notinca=false", `
            "deployment.security.askgrantdialog.notinca.locked"

        $PathsToEval = @("$env:windir\Sun\Java\Deployment")
        $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
        $ConfigFiles = @()
        ForEach ($Path in $PathsToEval) {
            If (Test-Path $Path) {
                $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
            }
        }

        $Compliant = $true
        If ($ConfigFiles.Count -eq 0) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found" | Out-String
        }
        Else {
            $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Get-PropertyFilePath -String $PropsPath
                    $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                    $FindingDetails += "" | Out-String
                    If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                        $Compliant = $false
                        $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                    }
                    Else {
                        If (Test-Path $PropsFile) {
                            $Encoding = Get-FileEncoding -Path $PropsFile
                            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                $Compliant = $false
                                $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                            }
                            Else {
                                $DeployFileContent = Get-Content -Path $PropsFile
                                ForEach ($Key in $KeysToEval) {
                                    If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                        $FindingDetails += "$Key is present" | Out-String
                                    }
                                    Else {
                                        $Compliant = $false
                                        $FindingDetails += "$Key is NOT present" | Out-String
                                    }
                                }
                            }
                        }
                        Else {
                            $Compliant = $false
                            $FindingDetails += "Properties file not found in the path defined." | Out-String
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234689 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234689
        STIG ID    : JRE8-WN-000090
        Rule ID    : SV-234689r617446_rule
        CCI ID     : CCI-001695
        Rule Name  : SRG-APP-000112
        Rule Title : Oracle JRE 8 must lock the dialog enabling users to grant permissions to execute signed content from an untrusted authority.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.askgrantdialog.show=false", `
            "deployment.security.askgrantdialog.show.locked"

        $PathsToEval = @("$env:windir\Sun\Java\Deployment")
        $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
        $ConfigFiles = @()
        ForEach ($Path in $PathsToEval) {
            If (Test-Path $Path) {
                $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
            }
        }

        $Compliant = $true
        If ($ConfigFiles.Count -eq 0) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found" | Out-String
        }
        Else {
            $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Get-PropertyFilePath -String $PropsPath
                    $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                    $FindingDetails += "" | Out-String
                    If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                        $Compliant = $false
                        $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                    }
                    Else {
                        If (Test-Path $PropsFile) {
                            $Encoding = Get-FileEncoding -Path $PropsFile
                            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                $Compliant = $false
                                $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                            }
                            Else {
                                $DeployFileContent = Get-Content -Path $PropsFile
                                ForEach ($Key in $KeysToEval) {
                                    If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                        $FindingDetails += "$Key is present" | Out-String
                                    }
                                    Else {
                                        $Compliant = $false
                                        $FindingDetails += "$Key is NOT present" | Out-String
                                    }
                                }
                            }
                        }
                        Else {
                            $Compliant = $false
                            $FindingDetails += "Properties file not found in the path defined." | Out-String
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234690 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234690
        STIG ID    : JRE8-WN-000100
        Rule ID    : SV-234690r617446_rule
        CCI ID     : CCI-000185
        Rule Name  : SRG-APP-000175
        Rule Title : Oracle JRE 8 must set the option to enable online certificate validation.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.validation.ocsp=true", `
            "deployment.security.validation.ocsp.locked"

        $PathsToEval = @("$env:windir\Sun\Java\Deployment")
        $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
        $ConfigFiles = @()
        ForEach ($Path in $PathsToEval) {
            If (Test-Path $Path) {
                $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
            }
        }

        $Compliant = $true
        If ($ConfigFiles.Count -eq 0) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found" | Out-String
        }
        Else {
            $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Get-PropertyFilePath -String $PropsPath
                    $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                    $FindingDetails += "" | Out-String
                    If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                        $Compliant = $false
                        $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                    }
                    Else {
                        If (Test-Path $PropsFile) {
                            $Encoding = Get-FileEncoding -Path $PropsFile
                            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                $Compliant = $false
                                $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                            }
                            Else {
                                $DeployFileContent = Get-Content -Path $PropsFile
                                ForEach ($Key in $KeysToEval) {
                                    If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                        $FindingDetails += "$Key is present" | Out-String
                                    }
                                    Else {
                                        $Compliant = $false
                                        $FindingDetails += "$Key is NOT present" | Out-String
                                    }
                                }
                            }
                        }
                        Else {
                            $Compliant = $false
                            $FindingDetails += "Properties file not found in the path defined." | Out-String
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234691 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234691
        STIG ID    : JRE8-WN-000110
        Rule ID    : SV-234691r617446_rule
        CCI ID     : CCI-001169
        Rule Name  : SRG-APP-000209
        Rule Title : Oracle JRE 8 must prevent the download of prohibited mobile code.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.security.blacklist.check=true", `
        "deployment.security.blacklist.check.locked"

    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in $PathsToEval) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $Compliant = $true
    If ($ConfigFiles.Count -eq 0) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found" | Out-String
    }
    Else {
        $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
        $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
            $Compliant = $false
            $FindingDetails += "" | Out-String
            $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
        }
        Else {
            # Get path to deployment.properties from .config file
            $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
            ForEach ($Line in $ConfigFileContent) {
                If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                    $PropsPath = ($Line.Split("=")[1]).Trim()
                    Break
                }
            }
            If ($PropsPath) {
                $PropsFile = Get-PropertyFilePath -String $PropsPath
                $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                $FindingDetails += "" | Out-String
                If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                    $Compliant = $false
                    $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                }
                Else {
                    If (Test-Path $PropsFile) {
                        $Encoding = Get-FileEncoding -Path $PropsFile
                        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                            $Compliant = $false
                            $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                        }
                        Else {
                            $DeployFileContent = Get-Content -Path $PropsFile
                            ForEach ($Key in $KeysToEval) {
                                If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                    $FindingDetails += "$Key is present" | Out-String
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "$Key is NOT present" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "Properties file not found in the path defined." | Out-String
                    }
                }
            }
            Else {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
            }
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234692 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234692
        STIG ID    : JRE8-WN-000120
        Rule ID    : SV-234692r617446_rule
        CCI ID     : CCI-001774
        Rule Name  : SRG-APP-000386
        Rule Title : Oracle JRE 8 must enable the option to use an accepted sites list.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.user.security.exception.sites"

    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in $PathsToEval) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $Compliant = $true
    If ($ConfigFiles.Count -eq 0) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found" | Out-String
    }
    Else {
        $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
        $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
            $Compliant = $false
            $FindingDetails += "" | Out-String
            $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
        }
        Else {
            # Get path to deployment.properties from .config file
            $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
            ForEach ($Line in $ConfigFileContent) {
                If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                    $PropsPath = ($Line.Split("=")[1]).Trim()
                    Break
                }
            }
            If ($PropsPath) {
                $PropsFile = Get-PropertyFilePath -String $PropsPath
                $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                $FindingDetails += "" | Out-String
                If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                    $Compliant = $false
                    $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                }
                Else {
                    If (Test-Path $PropsFile) {
                        $Encoding = Get-FileEncoding -Path $PropsFile
                        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                            $Compliant = $false
                            $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                        }
                        Else {
                            $DeployFileContent = Get-Content -Path $PropsFile
                            ForEach ($Key in $KeysToEval) {
                                If ($DeployFileContent -match $Key) {
                                    ForEach ($Line in $DeployFileContent) {
                                        If ($Line -like "$($KeysToEval)*") {
                                            $ExceptionPath = $Line.Split("=")[1]
                                            Break
                                        }
                                    }
                                    If ($ExceptionPath) {
                                        $ExceptionFile = Get-PropertyFilePath -String $ExceptionPath
                                        If ($ExceptionFile.Split("\")[0, -1][1] -ne "exception.sites") {
                                            $Compliant = $false
                                            $FindingDetails += "$Line" | Out-String
                                            $FindingDetails += "" | Out-String
                                            $FindingDetails += "$Key does not point to an 'exception.sites' file." | Out-String
                                        }
                                        Else {
                                            $FindingDetails += "$Line is present" | Out-String
                                        }
                                    }
                                    Else {
                                        $Compliant = $false
                                        $FindingDetails += "$Line" | Out-String
                                        $FindingDetails += "" | Out-String
                                        $FindingDetails += "Path to 'exception.sites' file is not defined in properties file." | Out-String
                                    }
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "$Key is NOT present" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "Properties file not found in the path defined." | Out-String
                    }
                }
            }
            Else {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
            }
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234693 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234693
        STIG ID    : JRE8-WN-000130
        Rule ID    : SV-234693r617446_rule
        CCI ID     : CCI-001774
        Rule Name  : SRG-APP-000386
        Rule Title : Oracle JRE 8 must have an exception.sites file present.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.user.security.exception.sites"

        $PathsToEval = @("$env:windir\Sun\Java\Deployment")
        $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
        $ConfigFiles = @()
        ForEach ($Path in $PathsToEval) {
            If (Test-Path $Path) {
                $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
            }
        }

        $Compliant = $true
        If ($ConfigFiles.Count -eq 0) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found" | Out-String
        }
        Else {
            $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Get-PropertyFilePath -String $PropsPath
                    $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                    If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                        $Compliant = $false
                        $FindingDetails += "" | Out-String
                        $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                    }
                    Else {
                        If (Test-Path $PropsFile) {
                            $Encoding = Get-FileEncoding -Path $PropsFile
                            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                $Compliant = $false
                                $FindingDetails += "" | Out-String
                                $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                            }
                            Else {
                                $DeployFileContent = Get-Content -Path $PropsFile
                                ForEach ($Key in $KeysToEval) {
                                    If ($DeployFileContent -match $Key) {
                                        ForEach ($Line in $DeployFileContent) {
                                            If ($Line -like "$($KeysToEval)*") {
                                                $ExceptionPath = ($Line.Split("=")[1] -Replace '\$SYSTEM_HOME', "$env:SystemRoot")
                                                Break
                                            }
                                        }
                                        If ($ExceptionPath) {
                                            $ExceptionFile = Get-PropertyFilePath -String $ExceptionPath
                                            $FindingDetails += "Exception File:`t`t$($ExceptionFile)" | Out-String
                                            $FindingDetails += "" | Out-String
                                            If ($ExceptionFile.Split("\")[0, -1][1] -ne "exception.sites") {
                                                $Compliant = $false
                                                $FindingDetails += "$Key does not point to an 'exception.sites' file." | Out-String
                                            }
                                            Else {
                                                If (Test-Path $ExceptionFile) {
                                                    $FindingDetails += "Exception file exists in the path defined." | Out-String
                                                }
                                                Else {
                                                    $Compliant = $false
                                                    $FindingDetails += "Exception file not found in the path defined." | Out-String
                                                }
                                            }
                                        }
                                        Else {
                                            $Compliant = $false
                                            $FindingDetails += "" | Out-String
                                            $FindingDetails += "Path to 'exception.sites' file is not defined in properties file." | Out-String
                                        }
                                    }
                                    Else {
                                        $Compliant = $false
                                        $FindingDetails += "" | Out-String
                                        $FindingDetails += "$Key is NOT present" | Out-String
                                    }
                                }
                            }
                        }
                        Else {
                            $Compliant = $false
                            $FindingDetails += "" | Out-String
                            $FindingDetails += "Properties file not found in the path defined." | Out-String
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234694 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234694
        STIG ID    : JRE8-WN-000150
        Rule ID    : SV-234694r617446_rule
        CCI ID     : CCI-001991
        Rule Name  : SRG-APP-000401
        Rule Title : Oracle JRE 8 must enable the dialog to enable users to check publisher certificates for revocation.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.validation.crl=true", `
            "deployment.security.validation.crl.locked"

        $PathsToEval = @("$env:windir\Sun\Java\Deployment")
        $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
        $ConfigFiles = @()
        ForEach ($Path in $PathsToEval) {
            If (Test-Path $Path) {
                $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
            }
        }

        $Compliant = $true
        If ($ConfigFiles.Count -eq 0) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found" | Out-String
        }
        Else {
            $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Get-PropertyFilePath -String $PropsPath
                    $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                    $FindingDetails += "" | Out-String
                    If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                        $Compliant = $false
                        $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                    }
                    Else {
                        If (Test-Path $PropsFile) {
                            $Encoding = Get-FileEncoding -Path $PropsFile
                            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                $Compliant = $false
                                $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                            }
                            Else {
                                $DeployFileContent = Get-Content -Path $PropsFile
                                ForEach ($Key in $KeysToEval) {
                                    If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                        $FindingDetails += "$Key is present" | Out-String
                                    }
                                    Else {
                                        $Compliant = $false
                                        $FindingDetails += "$Key is NOT present" | Out-String
                                    }
                                }
                            }
                        }
                        Else {
                            $Compliant = $false
                            $FindingDetails += "Properties file not found in the path defined." | Out-String
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234695 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234695
        STIG ID    : JRE8-WN-000160
        Rule ID    : SV-234695r617446_rule
        CCI ID     : CCI-001991
        Rule Name  : SRG-APP-000516
        Rule Title : Oracle JRE 8 must lock the option to enable users to check publisher certificates for revocation.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($ScanType -in "Classified") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is a classified system so this requirement is NA."
    }
    Else {
        $KeysToEval = "deployment.security.revocation.check=ALL_CERTIFICATES", `
            "deployment.security.revocation.check.locked"

        $PathsToEval = @("$env:windir\Sun\Java\Deployment")
        $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
        $ConfigFiles = @()
        ForEach ($Path in $PathsToEval) {
            If (Test-Path $Path) {
                $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
            }
        }

        $Compliant = $true
        If ($ConfigFiles.Count -eq 0) {
            $Compliant = $false
            $FindingDetails += "No deployment.config file found" | Out-String
        }
        Else {
            $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
            $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
            }
            Else {
                # Get path to deployment.properties from .config file
                $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
                ForEach ($Line in $ConfigFileContent) {
                    If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                        $PropsPath = ($Line.Split("=")[1]).Trim()
                        Break
                    }
                }
                If ($PropsPath) {
                    $PropsFile = Get-PropertyFilePath -String $PropsPath
                    $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                    $FindingDetails += "" | Out-String
                    If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                        $Compliant = $false
                        $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                    }
                    Else {
                        If (Test-Path $PropsFile) {
                            $Encoding = Get-FileEncoding -Path $PropsFile
                            If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                                $Compliant = $false
                                $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                            }
                            Else {
                                $DeployFileContent = Get-Content -Path $PropsFile
                                ForEach ($Key in $KeysToEval) {
                                    If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                        $FindingDetails += "$Key is present" | Out-String
                                    }
                                    Else {
                                        $Compliant = $false
                                        $FindingDetails += "$Key is NOT present" | Out-String
                                    }
                                }
                            }
                        }
                        Else {
                            $Compliant = $false
                            $FindingDetails += "Properties file not found in the path defined." | Out-String
                        }
                    }
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "" | Out-String
                    $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
                }
            }
        }

        If ($Compliant -eq $true) {
            $Status = "NotAFinding"
        }
        Else {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234696 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234696
        STIG ID    : JRE8-WN-000170
        Rule ID    : SV-234696r617446_rule
        CCI ID     : CCI-002460
        Rule Name  : SRG-APP-000488
        Rule Title : Oracle JRE 8 must prompt the user for action prior to executing mobile code.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $KeysToEval = "deployment.insecure.jres=PROMPT", `
        "deployment.insecure.jres.locked"

    $PathsToEval = @("$env:windir\Sun\Java\Deployment")
    $PathsToEval += Get-JreInstallPath | Select-Object -Unique | ForEach-Object {Return $_ + "Lib\"}
    $ConfigFiles = @()
    ForEach ($Path in $PathsToEval) {
        If (Test-Path $Path) {
            $ConfigFiles += Get-ChildItem -Path $Path | Where-Object Name -EQ "deployment.config"
        }
    }

    $Compliant = $true
    If ($ConfigFiles.Count -eq 0) {
        $Compliant = $false
        $FindingDetails += "No deployment.config file found" | Out-String
    }
    Else {
        $FindingDetails += "Config File:`t`t$($ConfigFiles[0].FullName)" | Out-String
        $Encoding = Get-FileEncoding -Path $ConfigFiles[0].FullName
        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
            $Compliant = $false
            $FindingDetails += "" | Out-String
            $FindingDetails += "Config file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
        }
        Else {
            # Get path to deployment.properties from .config file
            $ConfigFileContent = Get-Content -Path $ConfigFiles[0].FullName
            ForEach ($Line in $ConfigFileContent) {
                If (($Line -Replace "\s", "") -like "deployment.system.config=file*") {
                    $PropsPath = ($Line.Split("=")[1]).Trim()
                    Break
                }
            }
            If ($PropsPath) {
                $PropsFile = Get-PropertyFilePath -String $PropsPath
                $FindingDetails += "Properties File:`t`t$($PropsFile)" | Out-String
                $FindingDetails += "" | Out-String
                If ($PropsFile.Split("\")[0, -1][1] -ne "deployment.properties") {
                    $Compliant = $false
                    $FindingDetails += "deployment.system.config does not point to a 'deployment.properties' file." | Out-String
                }
                Else {
                    If (Test-Path $PropsFile) {
                        $Encoding = Get-FileEncoding -Path $PropsFile
                        If ($Encoding -notin @("ASCII (no BOM)", "UTF-8 with BOM")) {
                            $Compliant = $false
                            $FindingDetails += "Properties file is encoded as '$Encoding' which is not supported by Java JRE8 for Windows.  Please resave as 'ANSI', 'UTF-8', or 'UTF-8 with BOM' encoding." | Out-String
                        }
                        Else {
                            $DeployFileContent = Get-Content -Path $PropsFile
                            ForEach ($Key in $KeysToEval) {
                                If ($Key -in ($DeployFileContent -Replace "\s", "")) {
                                    $FindingDetails += "$Key is present" | Out-String
                                }
                                Else {
                                    $Compliant = $false
                                    $FindingDetails += "$Key is NOT present" | Out-String
                                }
                            }
                        }
                    }
                    Else {
                        $Compliant = $false
                        $FindingDetails += "Properties file not found in the path defined." | Out-String
                    }
                }
            }
            Else {
                $Compliant = $false
                $FindingDetails += "" | Out-String
                $FindingDetails += "Path to 'deployment.Properties' file is not defined in deployment.config." | Out-String
            }
        }
    }

    If ($Compliant -eq $true) {
        $Status = "NotAFinding"
    }
    Else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234697 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234697
        STIG ID    : JRE8-WN-000180
        Rule ID    : SV-234697r617446_rule
        CCI ID     : CCI-002605
        Rule Name  : SRG-APP-000456
        Rule Title : The version of Oracle JRE 8 running on the system must be the most current available.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $ProcessInfo = New-Object System.Diagnostics.ProcessStartInfo
    $ProcessInfo.FileName = "cmd.exe"
    $ProcessInfo.Arguments = "/c java -version"
    $ProcessInfo.RedirectStandardError = $true
    $ProcessInfo.RedirectStandardOutput = $true
    $ProcessInfo.UseShellExecute = $false
    $Process = New-Object System.Diagnostics.Process
    $Process.StartInfo = $ProcessInfo
    $Process.Start() | Out-Null
    $Process.WaitForExit()
    $Output = $Process.StandardError.ReadToEnd()

    $FindingDetails += "Java version information:`r`n" | Out-String
    $FindingDetails += $Output.Trim()
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V234698 {
    <#
    .DESCRIPTION
        Vuln ID    : V-234698
        STIG ID    : JRE8-WN-000190
        Rule ID    : SV-234698r617446_rule
        CCI ID     : CCI-002617
        Rule Name  : SRG-APP-000454
        Rule Title : Oracle JRE 8 must remove previous versions when the latest version is installed.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $InstalledSoftwareVersions = Get-InstalledSoftware | Where-Object DisplayName -Match "Java 8" | Select-Object DisplayName, DisplayVersion

    If (($InstalledSoftwareVersions.DisplayVersion | Select-Object -Unique).Count -gt 1) {
        $Status = "Open"
        $FindingDetails += "Multiple versions of Java JRE are installed:" | Out-String
        ForEach ($Version in $InstalledSoftwareVersions) {
            $FindingDetails += $Version.Displayname + " ($($Version.DisplayVersion))" | Out-String
        }
    }
    Else {
        $Status = "NotAFinding"
        $FindingDetails += "Java JRE version information:`r`n" | Out-String
        ForEach ($Version in $InstalledSoftwareVersions) {
            $FindingDetails += $Version.Displayname + " ($($Version.DisplayVersion))" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}


# SIG # Begin signature block
# MIIL1AYJKoZIhvcNAQcCoIILxTCCC8ECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUuQfiTl4rb8x5Dw6UNru4GSaK
# uRKgggk7MIIEejCCA2KgAwIBAgIEAwIE1zANBgkqhkiG9w0BAQsFADBaMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MB4XDTIwMDcxNTAw
# MDAwMFoXDTI1MDQwMjEzMzgzMlowaTELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxDDAKBgNV
# BAsTA1VTTjEWMBQGA1UEAxMNQ1MuTlNXQ0NELjAwMTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANv2fdTmx2dNPQ47F8kmvU+g20/sFoF+DS3k2GcMduuI
# XxYFJyMMPAvTJuobeJlX6P6sr5jAKhXXsoV4lT2boWw583Snl6cuSfqMbVowIJ1s
# CffN7N0VXsLVdOt1u5GCKs4/jXH7MeEOE0oJsgEjjE1IZc5tEqj++s1N1EUY+jf/
# zc8QHDjy5X88XBTzKVhwvczZVbRahrcmYv0k4we3ndwTl5nXYizSwi96CZuqzrIn
# WbLSsRLNyNZZVo7J5bZ+30dv/hZvq6FqxfAeM3pEDrvbfFkWXzaISqF1bVbsMlAC
# UBf/JFbSGtmMsU1ABfXKPalTWYJKP58dICHcUocZhL0CAwEAAaOCATcwggEzMB8G
# A1UdIwQYMBaAFHUJphUTroc8+nOUAPLw9Xm5snIUMEEGA1UdHwQ6MDgwNqA0oDKG
# MGh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNTlfTkNPREVTSUdOLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyowHQYDVR0O
# BBYEFFbrF3OpzfdsZkN1zTfv++oaLCRRMGUGCCsGAQUFBwEBBFkwVzAzBggrBgEF
# BQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNTkuY2VyMCAG
# CCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAWBgorBgEE
# AYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAQknaIAXDnyqshmyh
# uOZS4nBtSydnZrdB8Je0JCq2TTRA4dkNvrswe0kZgA7UjlY1X/9PtQeIwaMrcvdF
# i+dqzD1bbW/LX5tH/1oMOp4s+VkGfl4xUUxUGjO6QTVOeLyN2x+DBQU11DhKEq9B
# RCxUGgclFn1iqxi5xKmLaQ3XuRWRGCkb+rXejWR+5uSTognxCuoLp95bqu3JL8ec
# yF46+VSoafktAGot2Uf3qmwWdMHFBdwzmJalbC4j09I1qJqcJH0p8Wt34zRw/hSr
# 3f+xDEDP8GNL2ciDm7aN0GKy67ugjgMmPXAv7A4/keCuN/dsNS1naNyqzc5AhTAF
# +o/21jCCBLkwggOhoAMCAQICAgMFMA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTE5MDQwMjEzMzgz
# MloXDTI1MDQwMjEzMzgzMlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4g
# R292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMT
# DERPRCBJRCBDQS01OTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMwX
# hJ8twQpXrRFNNVc/JEcvHA9jlr27cDE8rpxWkobvpCJOoOVUbJ724Stx6OtTAZpR
# iXNaS0jjRgYaW6cq9pdnjjQM5ovHPPde1ewaZyWb2I+uqhkZmOBV1+lGUOhnQCyi
# nnSSqzEH1PC5nASfyxnCdBeOt+UKHBrPVKBUuYS4Fcn5Q0wv+sfBD24vyV5Ojeoq
# HeSSAMTaeqlv+WQb4YrjKNfaGF+S7lMvQelu3ANHEcoL2HMCimCvnCHQaMQI9+Ms
# NhySPEULePdEDxgpWYc9FmBbjUp1CYEx7HYdlTRJ9gBHts2ITxTZQrt4Epjkqeb8
# aWVmzCEPHE7+KUVhuO8CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyKlKJ3sYBy
# HYF6Fqry3M5m7kXAMB0GA1UdDgQWBBR1CaYVE66HPPpzlADy8PV5ubJyFDAOBgNV
# HQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsn
# MAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgB
# ZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQE
# BTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3Js
# L0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0
# cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3YzAgBggr
# BgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQELBQADggEB
# ADkFG9IOpz71qHNXCeYJIcUshgN20CrvB5ym4Pr7zKTBRMKNqd9EXWBxrwP9xhra
# 5YcQagHDqnmBeU3F2ePhWvQmyhPwIJaArk4xGLdv9Imkr3cO8vVapO48k/R9ZRSA
# EBxzd0xMDdZ6+xxFlZJIONRlxcVNNVB30e74Kk08/t82S9ogqgA1Q7KZ2tFuaRes
# jJWuoJ+LtE5lrtknqgaXLb3XH0hV5M0AWRk9Wg/1thb9NCsKEIAdpdnolZOephIz
# fzHiOSqeJ+e5qURLB7rT+F5y0NNWTdqoJ/vOOCUa8z0NKWsz2IkpeD3iNhVCLRKw
# Ojm/wzxdG2tst5OHRZFEwKcxggIDMIIB/wIBATBiMFoxCzAJBgNVBAYTAlVTMRgw
# FgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMD
# UEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNTkCBAMCBNcwCQYFKw4DAhoFAKB4MBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYE
# FKGddqvPJMERDGsLurUq3k8BCJhiMA0GCSqGSIb3DQEBAQUABIIBABSgpRYNMpBE
# V7N9aaDrAPKnKKlHCc8NnkncHfTMe58e+DwJQ/hlZyzlEAOT5aAbP3C3gs/k2xzk
# rCzadbgLj+LKjDs0HlOU0ahuZIdBe4Ub82vL1J5hLODwxu9f6OQvYBWxNw0ptq2b
# ImlxO+1p+2Mf3zr2kQBoLgCkDWDy9etTiWtcc77mfdi5Q45TES16s2ttvHMEQgGt
# tWJ9CdNe5IGvGjjZPMbaHImlMdV9AyNucelaj/TpnU1+wFwfjqcrosLfYuU/AU9w
# qOWxXyycTK6YWf9hr+Kw66xWISyIleZgJ4YQeOrm07I+Z/8PR0jJq6v/B6oLYu33
# 1PECn6b1Scs=
# SIG # End signature block
