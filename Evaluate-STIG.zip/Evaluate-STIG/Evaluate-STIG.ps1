# ###############################################################
# # Title:        Evaluate-STIG
# # Version:      1.2201.2
# # Description:  Automates STIG checklist (CKL) creation
# # Date:         03/07/2022
# ###############################################################

#requires -version 5.1

<#
    .Synopsis
        Automatically creates STIG checklists (CKL).
    .DESCRIPTION
        Automates the documentation of STIG compliance into STIG Viewer compatible checklist (.ckl) files.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1

        Runs Evaluate-STIG with default settings ("Unclassified" ScanType, "DEFAULT" Answer Key, and output to C:\Users\Public\Public Documents)
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -ScanType Classified -AnswerKey TestNetwork

        Runs Evaluate-STIG for a classified system and instructs it to use the user defined "TestNetwork" Answer Key.  Refer to documentation on answer keys.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -OutputPath E:\STIGResults

        Runs Evaluate-STIG for an unclassified asset using the DEFAULT answer key and outputs to E:\STIGResults
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -ScanType Classified -ComputerName Workstation1

        Executes Classified scan on remote computer Workstation1.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -ComputerName Workstation1,Workstation2,C:\Computers.txt -AltCredential -ThrottleLimit 7

        Executes Unclassifed scan on multiple computer names and a list of computers using an alternate credential and limiting concurrent scans to 7.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -SelectSTIG MSEdge,JavaJRE8,Win10

        Selects Microsoft Edge, Java JRE8, and Windows 10 (by shortname) to be scanned.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -ExcludeSTIG DotNET4,WinServer2019

        Excludes .NET 4 Framework and Windows Server 2019 from scan.  All other STIGs will be scanned if applicable.
    .INPUTS
        -ScanType <"Unclassified"/"Classified">
        Use to instruct Evaluate-STIG the classification of the asset.  Valid ScanTypes are "Unclassified" and "Classified".  If not specified, default will be "Unclassified".

        -AnswerKey <String>
        Use to instruct Evaluate-STIG which Answer Key to use for determining if a comment from an answer file should be applied.  Answer Keys are per Vuln ID and user-defined within the answer file.  If not specified, default Answer Key will be "DEFAULT".  Refer to documentation for more information.

        -AFPath <string>
        Path to Answer Files.  If not specified, defaults to $PsScriptRoot\AnswerFiles.

        -OutputPath <String>
        Sets the directory path for Evaluate-STIG to save its results.  May be a local or UNC path.  If not specified, default path will be C:\Users\Public\Public Documents or \opt\.  If using -OutputPath with -ComputerName, ensure the host computer's account has write access to the path in -OutputPath.

        -SelectSTIG <String>
        Specify which STIG(s) to scan.  Use Tab or CTRL+SPACE to properly select STIG(s) by its short name.  For multiple STIGs, separate with commas.  Cannot be specified with -ExcludeSTIG.

        -ExcludeSTIG <String>
        Specify which STIG(s) to exclude from the scan.  Use Tab or CTRL+SPACE to properly exclude STIG(s) by its short name.  For multiple STIGs, separate with commas.  Cannot be specified with -SelectSTIG.

        -ComputerName <String>
        Execute scan on remote computer.  Supports multiple computers through comma separation. Can be a computer name, a file with a list of computers, or a combination.  By default, results will be copied back to source computer.  Requires admin rights on remote computer.

        -ThrottleLimit <int>
        Number of concurrent Evaluate-STIG jobs to run when using -ComputerName.  Default is 10

        -AltCredential
        Prompts for an alternate credential to use for remote scans.  If connection to the remote machine fails with the alternate credential, Evaluate-STIG will fallback to the launching user and attempt the connection - essentially allowing for two credentials to be used for remote scan (e.g. workstation/server credentials).  Requires -ComputerName input.  Windows only.

        -GenerateOQE
        Creates Objective Quality Evidence (OQE) files in output path.

        -ApplyTattoo
        Applies Evaluate-STIG tattooing on system.  Mainly for providing a detection method to configuration management tools.

        -ListSupportedProducts
        Lists all products that Evaluate-STIG currently supports.

        -Update
        Downloads updates to Evaluate-STIG from the Evaluate-STIG repo on SPORK.

        -Proxy <String>
        Configure proxy for use with -Update.
    .LINK
        Evaluate-STIG
        https://spork.navsea.navy.mil/nswc-crane-division/evaluate-stig

        Windows Remote Management (WinRM)
        https://docs.microsoft.com/en-us/windows/win32/winrm

        CMTrace (for viewing EValuate-STIG.log)
        https://docs.microsoft/en-us/configmgr/core/support/cmtrace
    #>

Param (
    [Parameter(Mandatory = $false)]
    [String[]]$ComputerName,

    [Parameter(Mandatory = $false)]
    [ValidateSet("Unclassified", "Classified")]
    [String]$ScanType = "Unclassified",

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String]$AFPath,

    [Parameter(Mandatory = $false)]
    [String]$AnswerKey = "DEFAULT",

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String]$OutputPath,

    [Parameter(Mandatory = $false)]
    [Switch]$GenerateOQE,

    [Parameter(Mandatory = $false)]
    [Switch]$ApplyTattoo,

    [Parameter(Mandatory = $false)]
    [Switch]$ListSupportedProducts,

    [Parameter(Mandatory = $false)]
    [Switch]$Update,

    # Code for -SelectSTIG Option
    # https://powershell.one/powershell-internals/attributes/autocompletion
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [ArgumentCompleter({
        # Recieve information about current state to assit in auto-completing user typed value
        Param($CommandName, $ParameterName, $WordToComplete, $CommandAst, $FakeBoundParameters)

        # Get STIG ShortNames from STIGList.xml
        $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "STIGList.xml"
        If (Test-Path $STIGListXML) {
            $STIGs = ([XML](Get-Content $STIGListXML)).List.ChildNodes | Select-Object Name,ShortName -Unique | Sort-Object ShortName

            # Compose CompletionResult Entries
            $STIGs | Where-Object {$_.Shortname} | Where-Object {$_.ShortName -like "$WordToComplete*"} | ForEach-Object {
                $STIGSN = $_.Shortname
                If ($STIGSN -like '* *') {
                    $STIGSN = "'$STIGSN'"
                }
                [Management.Automation.CompletionResult]::New($STIGSN,$STIGSN,"ParameterValue",$_.Name)
            }
        }
    })]
    [ValidateScript({
            $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "STIGList.xml"
        If (Test-Path $STIGListXML) {
            $ValidSTIGs = (([XML](Get-Content $STIGListXML)).List.ChildNodes).ShortName
                If ($_ -Match ",") {
                    $_ -Split "," | ForEach-Object {
                        If ($_ -in $ValidSTIGs) {
                            $true
                        }
                        Else {
                            Throw "`r`n `r`n'$_' is not a product supported by Evaluate-STIG.`r`n `r`nPlease use CTRL+SPACE to list valid products.`r`n"
                        }
                    }
                }
            ElseIf ($_ -in $ValidSTIGs) {
                $true
            }
            Else {
                Throw "`r`n `r`n'$_' is not a product supported by Evaluate-STIG.`r`n `r`nPlease use CTRL+SPACE to list valid products.`r`n"
            }
        }
        Else {
            Throw "`r`n `r`n'$STIGListXML' does not exist.  Cannot continue.`r`n `r`n"
        }
    })]
    [Array]$SelectSTIG,

    # Code for -ExcludeSTIG Option
    # https://powershell.one/powershell-internals/attributes/autocompletion
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [ArgumentCompleter({
        # Recieve information about current state to assit in auto-completing user typed value
        Param($CommandName, $ParameterName, $WordToComplete, $CommandAst, $FakeBoundParameters)

        # Get STIG ShortNames from STIGList.xml
            $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "STIGList.xml"
        If (Test-Path $STIGListXML) {
            $STIGs = ([XML](Get-Content $STIGListXML)).List.ChildNodes | Select-Object Name, ShortName -Unique | Sort-Object ShortName

            # Compose CompletionResult Entries
            $STIGs | Where-Object {$_.Shortname} | Where-Object {$_.ShortName -like "$WordToComplete*"} | ForEach-Object {
                $STIGSN = $_.Shortname
                If ($STIGSN -like '* *') {
                    $STIGSN = "'$STIGSN'"
                }
                [Management.Automation.CompletionResult]::New($STIGSN,$STIGSN,"ParameterValue",$_.Name)
            }
        }
    })]
    [ValidateScript( {
            $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "STIGList.xml"
        If (Test-Path $STIGListXML) {
            $ValidSTIGs = (([XML](Get-Content $STIGListXML)).List.ChildNodes).ShortName
            If ($_ -Match ",") {
                $_ -Split "," | ForEach-Object {
                    If ($_ -in $ValidSTIGs) {
                        $true
                    }
                    Else {
                        Throw "`r`n `r`n'$_' is not a product supported by Evaluate-STIG.`r`n `r`nPlease use CTRL+SPACE to list valid products.`r`n"
                    }
                }
            }
            ElseIf ($_ -in $ValidSTIGs) {
                $true
            }
            Else {
                Throw "`r`n `r`n'$_' is not a product supported by Evaluate-STIG.`r`n `r`nPlease use CTRL+SPACE to list valid products.`r`n"
            }
        }
        Else {
            Throw "`r`n `r`n'$STIGListXML' does not exist.  Cannot continue.`r`n `r`n"
        }
    })]
    [Array]$ExcludeSTIG
    )

# Expose addtional dynamic parameters
DynamicParam {
    If ($ComputerName -or $Update) {
        $ParamDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary

        If ($ComputerName) {
            # Expose -AltCredential and -ThrottleLimit options if -ComputerName is specified
            $Attributes = New-Object System.Management.Automation.ParameterAttribute
            $Attributes.Mandatory = $false
            $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
            $AttributeCollection.Add($Attributes)
            $CredParam = New-Object System.Management.Automation.RuntimeDefinedParameter("AltCredential", [Switch], $AttributeCollection)
            $ParamDictionary.Add("AltCredential", $CredParam)

            # Expose -ThrottleLimit
            $Attributes = New-Object System.Management.Automation.ParameterAttribute
            $Attributes.Mandatory = $false
            $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
            $AttributeCollection.Add($Attributes)
            $ThrottleParam = New-Object System.Management.Automation.RuntimeDefinedParameter("ThrottleLimit", [int], $AttributeCollection)
            $ParamDictionary.Add("ThrottleLimit", $ThrottleParam)
        }

        If ($Update) {
            # Expose -Proxy
            $ParamDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary
            $Attributes = New-Object System.Management.Automation.ParameterAttribute
            $Attributes.Mandatory = $false
            $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
            $AttributeCollection.Add($Attributes)
            $ProxyParam = New-Object System.Management.Automation.RuntimeDefinedParameter("Proxy", [String], $AttributeCollection)
            $ParamDictionary.Add("Proxy", $ProxyParam)
        }

        Return $ParamDictionary
    }
}

Process {
    # -Update and external scripts reference the below $EvaluateStigVersion line as written.  Do not modify.
    $EvaluateStigVersion = "1.2201.2"
    # Scan process uses the below global variable for retaining the version variable across scripts and functions.
    $Global:ESVersion = $EvaluateStigVersion

    # If both -SelectSTIG and -ExcludeSTIG both specified, error out.  Only one may be specified.
    Try {
        If (($SelectSTIG) -and ($ExcludeSTIG)) {
            Throw "-SelectSTIG and -ExcludeSTIG cannot both be specified."
        }
    }
    Catch {
        Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
        Return
    }

    # Create $AltCredential variable if specified in command line
    If ($PsBoundParameters.AltCredential) {
        $AltCredential = "{0}" -f $PsBoundParameters.AltCredential
    }


    # Get PowerShell Version
    $PowerShellVersion = $PsVersionTable.PSVersion

    # Get PowerShell version and OS platform (Linux or Windows).  If unsupported detected, fail out.
    Try {
        If ($PowerShellVersion -ge [Version]"7.0") {
            If ($PowerShellVersion -ge [Version]"7.2") {
                $PSStyle.Progress.View = "Classic"
                $PSStyle.OutputRendering = [System.Management.Automation.OutputRendering]::PlainText;
            }
            If ($IsLinux -eq $true) {
                $OSPlatform = "Linux"
            }
            If ($IsWindows -eq $true) {
                $OSPlatform = "Windows"
                [Version]$WMFVersion = (PowerShell.exe -Command {$PsVersionTable}).PsVersion
                If ($WMFVersion -lt [Version]"5.1") {
                    Throw "Windows Management Framework (WMF) $($WMFVersion -join '.') detected.  WMF 5.1 or greater is required."
                }
            }
        }
        ElseIf ($PowerShellVersion -lt [Version]"5.1" -or ($PowerShellVersion -join ".") -like "6.*") {
            Throw "PowerShell $($PowerShellVersion -join '.') detected.  Evaluate-STIG only supports PowerShell 5.1 or PowerShell 7.x and greater.  PowerShell 6.x is not supported."
        }
        Else {
            $OSPlatform = "Windows"
        }
    }
    Catch {
        Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
        Return
    }

    # Validate AFPath
    If ($AFPath) {
        Try {
            If (-Not($AFPath | Test-Path)) {
                Throw "-AFPath either does not exist or is not accessible."
            }
            ElseIf (($AFPath | Test-Path) -and (-Not($AFPath | Test-Path -PathType 'Container' -ErrorAction SilentlyContinue))) {
                Throw "-AFPath must point to a directory."
            }
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Return
        }
    }

    # Validate OutputPath
    If ($OutputPath) {
        Try {
            If (-Not($OutputPath | Test-Path)) {
            Throw "-OutputPath either does not exist or is not accessible."
            }
            ElseIf (($OutputPath | Test-Path) -and (-Not($OutputPath | Test-Path -PathType 'Container' -ErrorAction SilentlyContinue))) {
                Throw "-OutputPath must point to a directory."
            }
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Return
        }
    }

    # Import required modules
    If ($PowerShellVersion -lt [Version]"7.0") {
        Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules\Master_Functions")
    }
    Else {
        Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules\Master_Functions") -SkipEditionCheck
    }

    # If -ListSupportedSTIGs specified, display list and exit.
    If ($ListSupportedProducts) {
        Try {
            $STIGList_xsd = Join-Path -Path $PsScriptRoot -ChildPath "XmlSchema" | Join-Path -ChildPath "Schema_STIGList.xsd"
            $XmlFile = Join-Path $PsScriptRoot -ChildPath "STIGList.xml"
            If (-Not(Test-Path $XmlFile)) {
                Throw "'$Xmlfile' file not found.  Please update with -Update option."
            }
            ElseIf (-Not(Test-Path $STIGList_xsd)) {
                Throw "'$STIGList_xsd' file not found.  Please update with -Update option."
            }
            ElseIf ((Test-XmlValidation -XmlFile $XmlFile -SchemaFile $STIGList_xsd) -ne $true) {
                Throw "'$Xmlfile' failed schema validation.  Please update with -Update option."
            }

            Get-SupportedProducts -ES_Path $PsScriptRoot
            Exit
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Exit 1
        }
    }

    # If -Update specified, download the latest updates.
    If ($Update) {
        Try {
            If ($PSBoundParameters.Proxy) {
                $Proxy = $PSBoundParameters.Proxy
            }
            Switch -Wildcard (Get-FileUpdatesFromRepo -PS_Path $PsScriptRoot -Proxy $Proxy) {
                "Successfully updated*" {
                    Write-Host $_ -ForegroundColor Green
                }
                "*requires no updating." {
                    Write-Host $_ -ForegroundColor Cyan
                }
                default {
                    Throw $_
                }
            }
            Break
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Break
        }
    }

    # OS dependent prerequiste checks
    Switch ($OSPlatform) {
        "Windows" {
            Try {
                # Confirm we have an elevated session.
                If (-NOT([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
                    Throw "You must run this from an elevated PowerShell session."
                }

                # Check Windows version.  Windows 10 / Windows Server 2012 R2 or greater required.
                If ([Version](Get-CimInstance Win32_OperatingSystem).Version -lt "6.3") {
                    Throw "$((Get-CimInstance Win32_OperatingSystem).Version) is not supported.  Must be version 6.3 or greater.  Cannot continue."
                }

                # Confirm native PowerShell session
                $OSArch = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment' -Name PROCESSOR_ARCHITECTURE).PROCESSOR_ARCHITECTURE
                If ($OSArch -eq "AMD64") {
                    If ([IntPtr]::Size -ne "8") {
                        Throw "32-Bit PowerShell session detected.  Evaluate-STIG must be ran in 64-Bit PowerShell on 64-Bit systems."
                    }
                }

                # Confirm only one instance of Evaluate-STIG is running
                If ((Get-CimInstance Win32_Process -Filter "Name='powershell.exe' AND CommandLine LIKE '%Evaluate-STIG.ps1%'").Count -gt 1) {
                    Throw "Evaluate-STIG is already running."
                }
            }
            Catch {
                Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
                Return
            }
        }
        "Linux" {
            Try {
                # Confirm we have an elevated session.
                If ((id -u) -ne 0) {
                    Throw "You must run this from an elevated PowerShell session."
                }
            }
            Catch {
                Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
                Return
            }

            #Check for prerequisites
            Try {
                $null = lshw -version 2>&1 /dev/null
            }
            Catch {
                Write-Host "'lshw' is required to be installed." -ForegroundColor Red -BackgroundColor Black
                Return
            }

            if ($ComputerName) {
                Write-Host "Remote computer option supports Windows only." -ForegroundColor Red
                Return
            }
        }
    }

    # Set initial variables
    $MachineName = ([Environment]::MachineName).ToUpper()
    If (-Not($AFPath)) {
        $AFPath = (Join-Path -Path $PsScriptRoot -ChildPath "AnswerFiles")
    }

    Switch ($OSPlatform) {
        "Windows" {
            If (-not($OutputPath)) {
                $OutputPath = "$env:PUBLIC\Documents\STIG_Compliance"
                if (!(Test-Path $OutputPath)) {
                    New-Item -Path $(Split-Path -Path $OutputPath -Parent) -Name $(Split-Path -Path $OutputPath -Leaf) -ItemType Directory | Out-Null
                }
            }
            $Global:WorkingDir = "$env:windir\Temp\Evaluate-STIG"
            $DomainRole = (Get-CimInstance Win32_ComputerSystem).DomainRole
        }
        "Linux" {
            If (-not($OutputPath)) {
                $OutputPath = "/opt/STIG_Compliance"
                if (!(Test-Path $OutputPath)) {
                    sudo mkdir $OutputPath
                }
            }
            $Global:WorkingDir = "/tmp/Evaluate-STIG"
            $Release = Get-Content /etc/os-release
            If ($release | Select-String "Workstation") {
                $DomainRole = 1
            }
            ElseIf ($release | Select-String "Server") {
                $DomainRole = 3
            }
            Else {
                $DomainRole = 1
            }
        }
    }
    $Global:ResultsPath = Join-Path -Path $OutputPath -ChildPath $MachineName
    $StartTime = Get-Date
    $Date = Get-Date -Format yyyyMMdd
    $Global:STIGLog = Join-Path -Path $WorkingDir -ChildPath "Evaluate-STIG.log"
    $Global:STIGLog_Remote = Join-Path -Path $WorkingDir -ChildPath "Evaluate-STIG_Remote.log"
    $Global:LogComponent = "Evaluate-STIG"
    [int]$Global:TotalMainSteps = 2
    [int]$Global:CurrentMainStep = 1
    [int]$Global:ProgressId = 1
    $Global:ProgressActivity = "Evaluate-STIG (Version: $ESVersion | Scan Type: $ScanType | Answer Key: $AnswerKey)"

    if ($host.privatedata){
        Try {
            #Set Progress Bar Colors
            $host.privatedata.ProgressForegroundColor = "White"

            switch ($ScanType) {
                "Unclassified" { $host.privatedata.ProgressBackgroundColor = "DarkGreen" }
                "Classified" { $host.privatedata.ProgressBackgroundColor = "DarkRed" }
            }
        }
        Catch {
            # Do nothing
        }
    }

    If (-Not(Test-Path $WorkingDir)) {
        $null = New-Item $WorkingDir -ItemType Directory
    }

    if (!(Test-Path $OutputPath)) {
        Write-Host "$OutputPath is not accessible by $([Environment]::Username) on $MachineName." -ForegroundColor Red
        return
    }

    # Run against remote computer if specified.  Running against a remote computer will copy the Evaluate-STIG content to temp and execute the scan local to that computer.
    If ($ComputerName) {
        Try {
            # Set working dir for remote scans
            $RemoteWorkingDir = Join-Path -Path $WorkingDir -ChildPath "RemoteScanTemp"
            If (-Not(Test-Path $RemoteWorkingDir)) {
                $null = New-Item -Path $RemoteWorkingDir -ItemType Directory -ErrorAction Stop
            }

            If (Test-Path $STIGLog_Remote) {
                Remove-Item $STIGLog_Remote -Force
            }

            Write-Log $STIGLog_Remote "Executing: $($MyInvocation.Line)" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Log $STIGLog_Remote "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform

            If ($AltCredential) {
                $Credentialcreds = Get-Creds
            }

            # For remote scans, archive Evaluate-STIG files and, if necessary, answer files for faster transport to remote machines
            # Clean up orphaned archives
            If (Test-Path $(Join-Path -Path $RemoteWorkingDir -ChildPath "ESCONTENT.ZIP")) {
                Write-Log $STIGLog_Remote "Removing orphaned file: $(Join-Path -Path $RemoteWorkingDir -ChildPath 'ESCONTENT.ZIP')" $LogComponent "Info" -OSPlatform $OSPlatform
                Remove-Item -Path $(Join-Path -Path $RemoteWorkingDir -ChildPath "ESCONTENT.ZIP") -Force
            }
            If (Test-Path $(Join-Path -Path $RemoteWorkingDir -ChildPath "AFILES.ZIP")) {
                Write-Log $STIGLog_Remote "Removing orphaned file: $(Join-Path -Path $RemoteWorkingDir -ChildPath 'AFILES.ZIP')" $LogComponent "Info" -OSPlatform $OSPlatform
                Remove-Item -Path $(Join-Path -Path $RemoteWorkingDir -ChildPath "AFILES.ZIP") -Force
            }

            # Create archive of Evaluate-STIG core files
            If (-Not(Test-Path $(Join-Path -Path $RemoteWorkingDir -ChildPath "ESCONTENT.ZIP"))) {
                Write-Host "Prepping files for remote scan..."
                Write-Host " - Compressing Evaluate-STIG files"
                Write-Log $STIGLog_Remote "Prepping files for remote scan..." $LogComponent "Info" -OSPlatform $OSPlatform
                Write-Log $STIGLog_Remote "Compressing Evaluate-STIG files" $LogComponent "Info" -OSPlatform $OSPlatform
                $Result = Initialize-Archiving -Action Compress -Path $("'" + (Join-Path -Path $PSScriptRoot -ChildPath "*") + "'") -Destination $(Join-Path -Path $RemoteWorkingDir -ChildPath "ESCONTENT.ZIP") -CompressionLevel Optimal
                If ($Result -ne "Success") {
                    Throw $Result
                }
            }

            # Create archive of Answer Files if not in default path (Evaluate-STIG\AnswerFiles)
            If (($AFPath.TrimEnd('\')).TrimEnd('/') -ne (Join-Path -Path $PsScriptRoot -ChildPath "AnswerFiles")) {
                If (-Not(Test-Path $(Join-Path -Path $RemoteWorkingDir -ChildPath "AFILES.ZIP"))) {
                    Write-Host " - Compressing answer files from $AFPath"
                    Write-Log $STIGLog_Remote "Compressing answer files from $AFPath" $LogComponent "Info" -OSPlatform $OSPlatform
                    $Result = Get-ChildItem -Path $AFPath | Where-Object Extension -EQ ".xml" | ForEach-Object {Initialize-Archiving -Action Compress -Path $("'" + $_.FullName + "'") -DestinationPath $(Join-Path -Path $RemoteWorkingDir -ChildPath "AFILES.ZIP") -Update -CompressionLevel Optimal}
                    If ($Result -ne "Success") {
                        Throw $Result
                    }
                }
            }

            #Build the list of computers, if necessary.
            $LocalHost = New-Object System.Collections.Generic.List[System.Object]
            $ComputerTempList = New-Object System.Collections.Generic.List[System.Object]
            $ComputerList = New-Object System.Collections.Generic.List[System.Object]
            $WindowsList = New-Object System.Collections.Generic.List[System.Object]
            $LinuxList = New-Object System.Collections.Generic.List[System.Object]
            $OfflineList = New-Object System.Collections.Generic.List[System.Object]
            $RemoteUnresolveCount = 0

            # Get local host data
            $NewObj = [PSCustomObject]@{
                HostName = ([Environment]::MachineName).ToUpper()
                IPv4Address = (Get-NetIPAddress).IPv4Address
            }
            $LocalHost.Add($NewObj)

            # Put all ComputerName items into a temp list for resolving
            ForEach ($Item in $ComputerName) {
                If ($Item -is [array]) {
                    $Item | ForEach-Object {
                        $ComputerTempList.Add($_)
                    }
                }
                ElseIf (Test-Path $Item) {
                    Get-Content $Item | ForEach-Object {
                        If ($_ -eq $null) {
                            Continue
                        }
                        Else {
                            $ComputerTempList.Add($_)
                        }
                    }
                }
                Else {
                    $ComputerTempList.Add($Item)
                }
            }

            # Get NETBIOS and FQDN of each computer
            Foreach ($Computer in ($ComputerTempList)) {
                If (($Computer -eq "127.0.0.1") -or ($Computer -eq "::1") -or ($Computer -eq "localhost") -or ($Computer.Split('.')[0] -eq $LocalHost.HostName) -or ($Computer -in $LocalHost.IPv4Address)) {
                    $NewObj = [PSCustomObject]@{
                        NETBIOS = $LocalHost.HostName
                        FQDN = "LOCALHOST"
                    }
                    $ComputerList.Add($NewObj)
                }
                Else {
                    # Resolve Computer
                    Try {
                        $FQDN = ([Net.DNS]::GetHostEntry($Computer).Hostname).ToUpper()
                        $NewObj = [PSCustomObject]@{
                            NETBIOS = $FQDN.Split('.')[0]
                            FQDN    = $FQDN
                        }
                        $ComputerList.Add($NewObj)
                    }
                    Catch {
                        Write-Host "Unable to resolve $Computer" -ForegroundColor Red
                        $RemoteUnresolveCount++
                        Write-Log $STIGLog_Remote "Unable to resolve $Computer" $LogComponent "Error" -OSPlatform $OSPlatform
                    }
                }
            }
            Remove-Variable ComputerTempList
            [System.GC]::Collect()
            $ComputerList = $ComputerList | Sort-Object NETBIOS -Unique

            $ConnectionScriptBlock = {
                Param (
                    [String]$NETBIOS,
                    [String]$FQDN
                )
                $tcp = New-Object Net.Sockets.TcpClient
                Try { $tcp.Connect($FQDN, 5986) } catch {}

                if ($tcp.Connected) {
                    $Connection = "5986"
                }
                else {
                    Try { $tcp.Connect($FQDN, 5985) } catch {}

                    if ($tcp.Connected) {
                        $Connection = "5985"
                    }
                    else {
                        Try { $tcp.Connect($FQDN, 22) } catch {}

                        if ($tcp.Connected) {
                            $Connection = "22"
                        }
                    }
                }

                $tcp.close()

                [PSCustomObject]@{
                    NETBIOS   = $NETBIOS
                    FQDN      = $FQDN
                    Connected = $Connection
                }
            }

            $ConnectionRunspacePool = [RunspaceFactory]::CreateRunspacePool(1, 10)
            $ConnectionRunspacePool.Open()

            $ProgressSpinner = @("|", "/", "-", "\")
            $ProgressSpinnerPos = 0
            $ConnectionJobs = New-Object System.Collections.ArrayList

            $ComputerList | ForEach-Object {
                $ParamList = @{
                    NETBIOS = $_.NETBIOS
                    FQDN = $_.FQDN
                }
                $ConnectionJob = [powershell]::Create().AddScript($ConnectionScriptBlock).AddParameters($ParamList)
                $ConnectionJob.RunspacePool = $ConnectionRunspacePool

                $null = $ConnectionJobs.Add([PSCustomObject]@{
                    Pipe   = $ConnectionJob
                    Result = $ConnectionJob.BeginInvoke()
                })
            }
            Write-Host ""

            Write-Log $STIGLog_Remote "Generating list of scannable hosts..." $LogComponent "Info" -OSPlatform $OSPlatform
            Do {
                Write-Host "`rGenerating list of scannable hosts.  Attempting connection to $(($ConnectionJobs.Result.IsCompleted).Count) hosts. $($ProgressSpinner[$ProgressSpinnerPos])" -NoNewline
                $ProgressSpinnerPos++
                Start-Sleep -Seconds 1
                if ($ProgressSpinnerPos -ge $ProgressSpinner.Length){$ProgressSpinnerPos = 0}
            } While ( $ConnectionJobs.Result.IsCompleted -contains $false)

            $ConnectionResults = $(ForEach ($ConnectionJob in $ConnectionJobs)
                { $ConnectionJob.Pipe.EndInvoke($ConnectionJob.Result) })

            $ConnectionRunspacePool.Close()
            $ConnectionRunspacePool.Dispose()

            $ConnectionResults | ForEach-Object {
                if ($_.Connected -eq "5986") {
                    $WindowsList.Add($_)
                }
                elseif ($_.Connected -eq "5985") {
                    $WindowsList.Add($_)
                }
                elseif ($_.Connected -eq "22") {
                    $LinuxList.Add($_)
                }
                else {
                    $OfflineList.Add($_)
                }
            }
            if (($WindowsList.count + $LinuxList.count) -eq 0) {
                Write-Log $STIGLog_Remote "No valid remote hosts found." $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Host " - No valid remote hosts found." -ForegroundColor Red
                Return
            }
            else{
                Write-Host "`rGenerating list of scannable machines.  Connected to $($WindowsList.count + $LinuxList.count) hosts.                 " -NoNewline
                Write-Log $STIGLog_Remote "Connected to $($WindowsList.count + $LinuxList.count) hosts." $LogComponent "Info" -OSPlatform $OSPlatform
                Write-Host ""
            }

            $RemoteScriptBlock = {
                Param(
                    $ConnectionResult,
                    $STIGLog_Remote,
                    $LogComponent,
                    $OSPlatform,
                    $RemoteWorkingDir,
                    $ScanType,
                    $AnswerKey,
                    $OutputPath,
                    $AltCredential,
                    $Credentialcreds,
                    $SelectSTIG,
                    $ExcludeSTIG,
                    $GenerateOQE,
                    $ApplyTattoo,
                    $AFPath,
                    $ScriptRoot
                )
                $RemoteStartTime = Get-Date

                $Remote_Log = Join-Path -Path $RemoteWorkingDir -ChildPath "Remote_Evaluate-STIG_$($ConnectionResult.NETBIOS).log"

                Write-Log $Remote_Log "==========[Begin Remote Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform

                #Write-Output ''
                #Write-Output "Processing : $($ConnectionResult.Hostname)..."

                Switch ($ConnectionResult.Connected) {
                    "5986" {
                        Write-Log $Remote_Log "Connection successful on port 5986. Determined Windows OS." $LogComponent "Info" -OSPlatform $OSPlatform
                        #Write-Output " - Connection successful on port 5986. Determined Windows OS."
                    }
                    "5985" {
                        Write-Log $Remote_Log "Connection successful on port 5985. Determined Windows OS." $LogComponent "Info" -OSPlatform $OSPlatform
                        #Write-Output " - Connection successful on port 5985. Determined Windows OS."
                    }
                    default {
                        Write-Log $Remote_Log "Connection unsuccessful on standard ports (Windows ports 5986/5985)." $LogComponent "Error" -OSPlatform $OSPlatform
                        #Write-Output " - Connection unsuccessful on standard ports (Windows ports 5986/5985)."
                    }
                }

                Write-Log $Remote_Log "Scanning : $($ConnectionResult.FQDN)" $LogComponent "Info" -OSPlatform $OSPlatform

                Try {
                    #Write-Output " - Remote Scan log stored on $env:WINDIR\Temp\Evaluate-STIG on $env:COMPUTERNAME"
                    Write-Log $Remote_Log "Creating Windows PS Session via HTTPS" $LogComponent "Info" -OSPlatform $OSPlatform
                    #Write-Output " - Creating Windows PS Session via HTTPS"

                    if ($AltCredential) {
                        $SSLOptions = New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck
                        $Session = New-PSSession -ComputerName $($ConnectionResult.FQDN) -Credential $Credentialcreds -UseSSL -SessionOption $SSLOptions -ErrorVariable remoteerror -ErrorAction SilentlyContinue
                        if ($remoteerror) {
                            #Write-Output "    HTTPS connection failed.  Attempting HTTP connection."
                            Write-Log $Remote_Log "HTTPS connection failed.  Attempting HTTP connection." $LogComponent "Warning" -OSPlatform $OSPlatform
                            #Write-Output " - Creating Windows PS Session via HTTP"
                            Write-Log $Remote_Log "Creating Windows PS Session via HTTP" $LogComponent "Info" -OSPlatform $OSPlatform

                            $Session = New-PSSession -ComputerName $($ConnectionResult.FQDN) -Credential $Credentialcreds -ErrorVariable remoteerror -ErrorAction SilentlyContinue
                            if ($remoteerror) {
                                #Write-Output "    Alternate Credentials failed to create a remote session.  Falling back to $([Environment]::Username)."
                                Write-Log $Remote_Log "Alternate Credentials failed to create a session.  Falling back to $([Environment]::Username)." $LogComponent "Warning" -OSPlatform $OSPlatform
                                $Session = New-PSSession -ComputerName $($ConnectionResult.FQDN) -ErrorVariable remoteerror -ErrorAction SilentlyContinue
                            }
                        }
                    }
                    else {
                        $SSLOptions = New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck
                        $Session = New-PSSession -ComputerName $($ConnectionResult.FQDN) -UseSSL -SessionOption $SSLOptions -ErrorVariable remoteerror -ErrorAction SilentlyContinue
                        if ($remoteerror) {
                            #Write-Output "    HTTPS connection failed.  Attempting HTTP connection."
                            Write-Log $Remote_Log "HTTPS connection failed.  Attempting HTTP connection." $LogComponent "Warning" -OSPlatform $OSPlatform
                            #Write-Output " - Creating Windows PS Session via HTTP"
                            Write-Log $Remote_Log "Creating Windows PS Session via HTTP" $LogComponent "Info" -OSPlatform $OSPlatform
                            $Session = New-PSSession -ComputerName $($ConnectionResult.FQDN) -ErrorVariable remoteerror -ErrorAction SilentlyContinue
                        }
                    }

                    switch -WildCard ($remoteerror) {
                        "*Access is denied*" {
                            #Write-Output "-ComputerName requires admin rights on $($ConnectionResult.Hostname)"
                            Write-Log $Remote_Log "-ComputerName requires admin rights on $($ConnectionResult.FQDN)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }
                        "*WinRM*" {
                            #Write-Output "-ComputerName requires WinRM on $($ConnectionResult.Hostname)"
                            Write-Log $Remote_Log "-ComputerName requires WinRM on $($ConnectionResult.FQDN)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }
                        "*The user name or password is incorrect.*" {
                            #Write-Output "-ComputerName requires a valid username and password to connect to $($ConnectionResult.Hostname)"
                            Write-Log $Remote_Log "-ComputerName requires a valid username and password to connect to $($ConnectionResult.FQDN)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }
                        default {
                            #Write-Output "-ComputerName got an error"
                            Write-Log $Remote_Log "-ComputerName got an error" $LogComponent "Error" -OSPlatform $OSPlatform
                        }
                    }

                    if (!($Session)) {
                        Write-Log $Remote_Log $remoteerror $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $Remote_Log "==========[End Remote Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform

                        Add-Content -Path $STIGLog_Remote -Value $(Get-Content $Remote_Log)
                        Remove-Item $Remote_Log
                        $RemoteFailCount["RemoteFail"]++
                        Continue
                    }

                    Write-Log $Remote_Log "Credential: '$(Invoke-Command -ScriptBlock { return whoami } -Session $Session)' used for remote session(s)." $LogComponent "Info" -OSPlatform $OSPlatform

                    if ((Invoke-Command -ScriptBlock { (($PsVersionTable.PSVersion).ToString()) -lt 5.1 } -Session $Session)) {
                        Write-Log $Remote_Log "$($ConnectionResult.FQDN) does not meet minimum PowerShell version (5.1)" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $Remote_Log $remoteerror $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $Remote_Log "==========[End Remote Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform

                        Add-Content -Path $STIGLog_Remote -Value $(Get-Content $Remote_Log)
                        Remove-Item $Remote_Log
                        Continue
                    }

                    If (Invoke-Command -ScriptBlock { Test-Path $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer } -Session $Session) {
                        #Write-Output " - Removing previous content found in $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer"
                        Write-Log $Remote_Log "Removing previous content found in $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer" $LogComponent "Info" -OSPlatform $OSPlatform
                        Invoke-Command -ScriptBlock { Remove-Item $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer -Recurse -Force } -Session $Session
                    }
                    Invoke-Command -ScriptBlock { $null = New-Item -ItemType Directory -Path $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer } -Session $Session
                    Invoke-Command -ScriptBlock { $null = New-Item -ItemType Directory -Path $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer\STIG_Compliance } -Session $Session

                    If ($SelectSTIG) {
                        $ESArgs = "-SelectSTIG $($SelectSTIG -join ',') -ScanType $ScanType -AnswerKey $AnswerKey"
                    }
                    ElseIf ($ExcludeSTIG) {
                        $ESArgs = "-ExcludeSTIG $($ExcludeSTIG -join ',') -ScanType $ScanType -AnswerKey $AnswerKey"
                    }
                    Else {
                        $ESArgs = "-ScanType $ScanType -AnswerKey $AnswerKey"
                    }

                    If ($GenerateOQE) {
                        $ESArgs = "-GenerateOQE " + $ESArgs
                    }

                    If ($ApplyTattoo) {
                        $ESArgs = "-ApplyTattoo " + $ESArgs
                    }

                    # Clean up orphaned previous scan archives
                    If (Test-Path $RemoteWorkingDir\PREVIOUS_$($($ConnectionResult.NETBIOS)).ZIP) {
                        Remove-Item -Path $RemoteWorkingDir\PREVIOUS_$($($ConnectionResult.NETBIOS)).ZIP -Force
                    }
                    If (Test-Path "$RemoteWorkingDir\$($($ConnectionResult.NETBIOS)).ZIP") {
                        Remove-Item -Path "$RemoteWorkingDir\$($($ConnectionResult.NETBIOS)).ZIP" -Force
                    }

                    $ProgressPreference = "SilentlyContinue"

                    Initialize-FileXferToRemote -NETBIOS $($ConnectionResult.NETBIOS) -RemoteTemp "$env:WINDIR\Temp\Evaluate-STIG_RemoteComputer" -OutputPath $OutputPath -AFPath $AFPath -Remote_Log $Remote_Log -LogComponent $LogComponent -OSPlatform $OSPlatform -RemoteWorkingDir $RemoteWorkingDir -ScriptRoot $ScriptRoot -Session $Session

                    #Write-Output " - Invoking Evaluate-STIG on $($ConnectionResult.Hostname). This may take several minutes."
                    Write-Log $Remote_Log "Invoking Evaluate-STIG on $($ConnectionResult.FQDN)" $LogComponent "Info" -OSPlatform $OSPlatform
                    #Write-Output "    Local logging of scan is stored at $env:WINDIR\Temp\Evaluate-STIG on $($ConnectionResult.Hostname)"
                    Write-Log $Remote_Log "Local logging of scan is stored at $env:WINDIR\Temp\Evaluate-STIG on $($ConnectionResult.FQDN)" $LogComponent "Info" -OSPlatform $OSPlatform

                    $RemoteES = Invoke-Command -Session $Session {
                        param(
                            [string]
                            $ESArgs,

                            [string]
                            $OutputPath
                        )

                        if (([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
                            If ((Get-AuthenticodeSignature -FilePath $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer\Evaluate-STIG.ps1).Status -eq "Valid") {
                                $CodeSign = $true
                            }
                            else {
                                $CodeSign = $False
                                Write-Output "Code signing certificate is not installed on $env:COMPUTERNAME"
                            }
                            $ESPath = "$env:WINDIR\Temp\Evaluate-STIG_RemoteComputer\Evaluate-STIG.ps1"
                            $Command = "-Command $($ESPath) $($ESArgs) -OutputPath $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer\STIG_Compliance"
                            $Bypass_Command = " -ExecutionPolicy Bypass -Command $($ESPath) $($ESArgs) -OutputPath $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer\STIG_Compliance"

                            Switch (Get-ExecutionPolicy) {
                                "AllSigned" {
                                    If ($CodeSign) {
                                        Start-Process powershell -ArgumentList $Command -Wait
                                    }
                                    else {
                                        Write-Output "Bypassing '$_' ExecutionPolicy on $env:COMPUTERNAME"
                                        Start-Process powershell -ArgumentList $Bypass_Command -Wait
                                    }
                                }
                                "Default" {
                                    Write-Output "Bypassing '$_' ExecutionPolicy on $env:COMPUTERNAME"
                                    Start-Process powershell -ArgumentList $Bypass_Command -Wait
                                }
                                "RemoteSigned" {
                                    If ($CodeSign) {
                                        Start-Process powershell -ArgumentList $Command -Wait
                                    }
                                    else {
                                        Write-Output "Bypassing '$_' ExecutionPolicy on $env:COMPUTERNAME"
                                        Start-Process powershell -ArgumentList $Bypass_Command -Wait
                                    }
                                }
                                "Restricted" {
                                    Write-Output "Bypassing '$_' ExecutionPolicy on $env:COMPUTERNAME"
                                    Start-Process powershell -ArgumentList $Bypass_Command -Wait
                                }
                                "Undefined" {
                                    Write-Output "Bypassing '$_' ExecutionPolicy on $env:COMPUTERNAME"
                                    Start-Process powershell -ArgumentList $Bypass_Command -Wait
                                }
                                default {
                                    Start-Process powershell -ArgumentList $Command -Wait
                                }
                            }

                            Write-Output " - Remote scan completed."
                        }
                        else {
                            Write-Output "Error: You must run this from an elevated PowerShell session on the Remote computer."
                            Write-Output  "==========[End Remote Logging]=========="
                            Continue
                        }
                    } -ArgumentList ($ESArgs, $OutputPath) -ErrorAction SilentlyContinue -InformationAction Ignore

                    $RemoteES | ForEach-Object { Write-Log $Remote_Log $_ $LogComponent "Info" -OSPlatform $OSPlatform }

                    $TotalCKLS = 0
                    $TotalCKLs = Invoke-Command -ScriptBlock { Return (Get-ChildItem -Path "$($env:WINDIR)\Temp\Evaluate-STIG_RemoteComputer\STIG_Compliance\$($env:ComputerName)\Checklist" -ErrorAction SilentlyContinue | Where-Object Extension -EQ '.ckl' | Measure-Object).Count } -Session $Session

                    If ($TotalCKLS -gt 0) {
                        Initialize-FileXferFromRemote -NETBIOS $($ConnectionResult.NETBIOS) -RemoteTemp "$env:WINDIR\Temp\Evaluate-STIG_RemoteComputer" -OutputPath $OutputPath -Remote_Log $Remote_Log -LogComponent $LogComponent -OSPlatform $OSPlatform -RemoteWorkingDir $RemoteWorkingDir -ScriptRoot $ScriptRoot -Session $Session
                    }
                    Else {
                        #Write-Output " - No Evaluate-STIG supported STIGs are applicable to $($ConnectionResult.Hostname)."
                        Write-Log $Remote_Log "No Evaluate-STIG supported STIGs are applicable to $($ConnectionResult.FQDN)." $LogComponent "Info" -OSPlatform $OSPlatform
                    }

                    If (Invoke-Command -ScriptBlock { Test-Path $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer } -Session $Session) {
                        Invoke-Command -ScriptBlock { Remove-Item $env:WINDIR\Temp\Evaluate-STIG_RemoteComputer -Recurse -Force } -Session $Session
                    }

                    #Write-Output " - Closing PS Session"
                    $Session | Remove-PSSession

                    $TimeToComplete = New-TimeSpan -Start $RemoteStartTime -End (Get-Date)
                    $FormatedTime = "{0:c}" -f $TimeToComplete
                    Write-Log $Remote_Log "Total CKLs - $($TotalCKLs)" $LogComponent "Info" -OSPlatform $OSPlatform
                    #Write-Output "Total CKLs - $($TotalCKLs)"
                    Write-Log $Remote_Log "Total Time - $($FormatedTime)" $LogComponent "Info" -OSPlatform $OSPlatform
                    #Write-Output "Total Time - $($FormatedTime)"
                    Write-Log $Remote_Log "==========[End Remote Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform

                    Add-Content -Path $STIGLog_Remote -Value $(Get-Content $Remote_Log)
                    Remove-Item $Remote_Log

                    $ProgressPreference = "Continue"

                    Continue
                }
                Catch {
                    #Write-Output "Error: $($_.Exception.Message)"
                    Write-Log $Remote_Log "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Log $Remote_Log "Total Time - $($FormatedTime)" $LogComponent "Info" -OSPlatform $OSPlatform
                    Write-Log $Remote_Log "==========[End Remote Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform

                    Add-Content -Path $STIGLog_Remote -Value $(Get-Content $Remote_Log)
                    Remove-Item $Remote_Log

                    If ($Session) {
                        #Write-Output "   - Closing PS Session"
                        $Session | Remove-PSSession
                    }
                    $ProgressPreference = "Continue"

                    Continue
                }
            }

            $RemoteFailCount = [hashtable]::Synchronized(@{})

            $Params = @{
                STIGLog_Remote   = $STIGLog_Remote
                LogComponent     = $LogComponent
                OSPlatform       = $OSPlatform
                RemoteWorkingDir = $RemoteWorkingDir
                ScanType         = $ScanType
                AnswerKey        = $AnswerKey
                OutputPath       = $OutputPath
                ScriptRoot       = $PsScriptRoot
            }

            if ($AltCredential) {
                $Params.AltCredential = $True
                $Params.CredentialCreds = $Credentialcreds
            }
            else {
                $Params.AltCredential = $False
            }

            if ($SelectSTIG) {
                $Params.SelectSTIG = $SelectSTIG
            }
            else {
                $Params.SelectSTIG = $False
            }

            if ($ExcludeSTIG) {
                $Params.ExcludeSTIG = $ExcludeSTIG
            }
            else {
                $Params.ExcludeSTIG = $False
            }

            if ($GenerateOQE) {
                $Params.GenerateOQE = $GenerateOQE
            }
            else {
                $Params.GenerateOQE = $False
            }

            if ($ApplyTattoo){
                $Params.ApplyTattoo = $ApplyTattoo
            }
            else{
                $Params.ApplyTattoo = $False
            }

            if ($AFPath) {
                $Params.AFPath = $AFPath
            }
            else {
                $Params.AFPath = $False
            }

            if ($PSBoundParameters.ThrottleLimit) {
                $MaxThreads = $PSBoundParameters.ThrottleLimit
            }
            else {
                $MaxThreads = 10
            }

            #https://learn-powershell.net/2013/04/19/sharing-variables-and-live-objects-between-powershell-runspaces/

            $runspaces = New-Object System.Collections.ArrayList
            $sessionstate = [system.management.automation.runspaces.initialsessionstate]::CreateDefault()
            $sessionstate.variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList 'RemoteFailCount', $RemoteFailCount, ''))

            Get-ChildItem function:/ | ForEach-Object {
                $definition = Get-Content "Function:\$($_.Name)"
                $SessionStateFunction = New-Object System.Management.Automation.Runspaces.SessionStateFunctionEntry -ArgumentList $_.Name, $definition
                $sessionstate.Commands.Add($SessionStateFunction)
            }

            $runspacepool = [runspacefactory]::CreateRunspacePool(1, $MaxThreads, $sessionstate, $Host)
            $runspacepool.ApartmentState = "STA"
            $runspacepool.Open()

            Foreach ($ConnectionResult in $($ConnectionResults | Where-Object { ($_.Connected -ne "22") -and ($_.FQDN -notin $OfflineList) })) {
                $Job = [powershell]::Create().AddScript($RemoteScriptBlock).AddArgument($ConnectionResult).AddParameters($Params)
                $Job.Streams.ClearStreams()
                $Job.RunspacePool = $RunspacePool

                #Create a temporary collection for each runspace
                $temp = "" | Select-Object Job, Runspace, FQDN
                $Temp.FQDN = $ConnectionResult.FQDN
                $temp.Job = $Job

                #Save the handle output when calling BeginInvoke() that will be used later to end the runspace
                $temp.Runspace = $Job.BeginInvoke()
                $null = $runspaces.Add($temp)
            }

            if ($runspaces.count -gt 0) {
                Get-RunspaceData -Runspaces $Runspaces -Wait
            }

            $RunspacePool.Close()
            $RunspacePool.Dispose()

            $RemoteLinuxFail = 0

            Foreach ($LinuxHost in $LinuxList) {
                $Remote_Log = Join-Path -Path $RemoteWorkingDir -ChildPath "Remote_Evaluate-STIG_$($LinuxHost.NETBIOS).log"
                Write-Host ""
                #Write-Host "Processing : $Hostname..."

                If ($PowerShellVersion -ge [Version]"7.1") {
                    Try {
                        $RemoteStartTime = Get-Date

                        Write-Log $Remote_Log "Connection successful on port 22. Determined Linux OS." $LogComponent "Info" -OSPlatform $OSPlatform
                        #Write-Host " - Connection successful on port 22. Determined Linux OS."

                        Write-Log $Remote_Log "Scanning : $($LinuxHost.FQDN)" $LogComponent "Info" -OSPlatform $OSPlatform

                        #Write-Host " - Remote Scan log stored on $env:WINDIR\Temp\Evaluate-STIG on $env:COMPUTERNAME"
                        #Write-Host " - Creating Linux PS Session"
                        $SSHUsername = Read-Host "Enter username for SSH to $($LinuxHost.FQDN)"
                        $Session = New-PSSession -HostName $LinuxHost.FQDN -UserName $SSHUsername -SSHTransport -ErrorAction Stop

                        If (Invoke-Command -ScriptBlock { Test-Path /tmp/Evaluate-STIG_RemoteComputer } -Session $Session) {
                            #Write-Host " - Removing previous content found in /tmp/Evaluate-STIG_RemoteComputer"
                            Write-Log $Remote_Log "Removing previous content found in /tmp/Evaluate-STIG_RemoteComputer" $LogComponent "Info" -OSPlatform $OSPlatform
                            Invoke-Command -ScriptBlock { Remove-Item /tmp/Evaluate-STIG_RemoteComputer -Recurse -Force } -Session $Session
                        }
                        Invoke-Command -ScriptBlock { $null = New-Item -ItemType Directory -Path /tmp/Evaluate-STIG_RemoteComputer } -Session $Session
                        Invoke-Command -ScriptBlock { $null = New-Item -ItemType Directory -Path /tmp/Evaluate-STIG_RemoteComputer/STIG_Compliance } -Session $Session

                        $DefaultOutputPath = "/tmp/Evaluate-STIG_RemoteComputer/STIG_Compliance"

                        if ($SelectSTIG) {
                            $ESArgs = "-SelectSTIG $($SelectSTIG -join ',') -ScanType $ScanType -AnswerKey $AnswerKey -OutputPath $DefaultOutputPath"
                        }
                        elseif ($ExcludeSTIG) {
                            $ESArgs = "-ExcludeSTIG $($ExcludeSTIG -join ',') -ScanType $ScanType -AnswerKey $AnswerKey -OutputPath $DefaultOutputPath"
                        }
                        else {
                            $ESArgs = "-ScanType $ScanType -AnswerKey $AnswerKey -OutputPath $DefaultOutputPath"
                        }

                        if ($GenerateOQE) {
                            $ESArgs = "-GenerateOQE " + $ESArgs
                        }

                        # Clean up orphaned previous scan archives
                        If (Test-Path "$RemoteWorkingDir\PREVIOUS_$($LinuxHost.NETBIOS).ZIP") {
                            Remove-Item -Path "$RemoteWorkingDir\PREVIOUS_$($LinuxHost.NETBIOS).ZIP" -Force
                        }
                        If (Test-Path "$RemoteWorkingDir\$($LinuxHost.NETBIOS).ZIP") {
                            Remove-Item -Path "$RemoteWorkingDir\$($LinuxHost.NETBIOS).ZIP" -Force
                        }

                        $ProgressPreference = "SilentlyContinue"

                        Initialize-FileXferToRemote -NETBIOS $($LinuxHost.NETBIOS) -RemoteTemp "/tmp/Evaluate-STIG_RemoteComputer" -OutputPath $OutputPath -AFPath $AFPath -Remote_Log $Remote_Log -LogComponent $LogComponent -OSPlatform $OSPlatform -RemoteWorkingDir $RemoteWorkingDir -ScriptRoot $PSScriptRoot -Session $Session

                        Write-Host " - Invoking Evaluate-STIG on $($LinuxHost.FQDN). This may take several minutes."
                        Write-Log $Remote_Log "Invoking Evaluate-STIG on $($LinuxHost.FQDN)." $LogComponent "Info" -OSPlatform $OSPlatform

                        Write-Host "    Local logging of scan is stored at /tmp/Evaluate-STIG on $($LinuxHost.FQDN)e"
                        Write-Log $Remote_Log "Local logging of scan is stored at /tmp/Evaluate-STIG on $($LinuxHost.FQDN)" $LogComponent "Info" -OSPlatform $OSPlatform

                        $sudoPass = Read-Host "[sudo] password for $SSHUsername" -AsSecureString
                        $creds = New-Object System.Management.Automation.PSCredential($SSHUsername, $sudoPass)
                        $sudoPass = $creds.GetNetworkCredential().Password

                        $RemoteES = Invoke-Command -Session $session {
                            param(
                                [String]
                                $SudoPass,

                                [String]
                                $ESArgs,

                                [string]
                                $DefaultOutputPath,

                                [string]
                                $SSHUsername,

                                [string]
                                $OutputPath
                            )

                            if (($sudoPass | sudo -S whoami) -ne "root") {
                                Write-Host "Error: sudo: incorrect password attempt" -ForegroundColor Red
                                Return 2
                            }

                            if (!(Test-Path $DefaultOutputPath)) {
                                $SudoPass | sudo -S mkdir $DefaultOutputPath
                            }

                            # Now you have cached your sudo password you should be able to call it normally (up to whatever timeout you have configured)
                            $SudoPass | sudo -S pwsh -command "Start-Process pwsh -ArgumentList '-command /tmp/Evaluate-STIG_RemoteComputer/Evaluate-STIG.ps1 $ESArgs' -Wait; chown -R $SSHUsername`: /tmp/Evaluate-STIG_RemoteComputer"
                            Write-Host " - Remote scan completed."
                        } -ArgumentList ($sudoPass, $ESArgs, $DefaultOutputPath, $SSHUsername, $OutputPath) -ErrorAction SilentlyContinue -InformationAction Ignore

                        $Hostname = $LinuxHost.NETBIOS
                        $TotalCKLS = Invoke-Command -ScriptBlock { param ($DefaultOutputPath, $Hostname)
                            $Path = "$DefaultOutputPath/$Hostname/Checklist"
                            Return (pwsh -command "ls $Path/*.ckl 2>/dev/null | wc -l" )
                        } -Session $Session -ArgumentList ($DefaultOutputPath, $Hostname)

                        if ($TotalCKLS -gt 0) {
                            Initialize-FileXferFromRemote -NETBIOS $($LinuxHost.NETBIOS) -RemoteTemp "/tmp/Evaluate-STIG_RemoteComputer" -OutputPath $OutputPath -Remote_Log $Remote_Log -LogComponent $LogComponent -OSPlatform $OSPlatform -RemoteWorkingDir $RemoteWorkingDir -ScriptRoot $ScriptRoot -Session $Session
                        }
                        elseif ($RemoteES -eq 2) {
                            $RemoteLinuxFail++
                        }
                        else{
                            Write-Host " - No Evaluate-STIG supported STIGs are applicable to $($LinuxHost.FQDN)."
                            Write-Log $Remote_Log "No Evaluate-STIG supported STIGs are applicable to $($LinuxHost.FQDN)." $LogComponent "Info" -OSPlatform $OSPlatform
                            $RemoteLinuxFail++
                        }

                        If (Invoke-Command -ScriptBlock { Test-Path /tmp/Evaluate-STIG_RemoteComputer } -Session $Session) {
                            Invoke-Command -ScriptBlock { Remove-Item /tmp/Evaluate-STIG_RemoteComputer -Recurse -Force } -Session $Session
                        }

                        #Write-Host " - Closing PS Session"
                        $Session | Remove-PSSession

                        $TimeToComplete = New-TimeSpan -Start $RemoteStartTime -End (Get-Date)
                        $FormatedTime = "{0:c}" -f $TimeToComplete
                        Write-Host "Total CKLs - $($TotalCKLs)"
                        Write-Host "Total Time - $($FormatedTime)"
                        Write-Log $Remote_Log "Total CKLs - $($TotalCKLs)" $LogComponent "Info" -OSPlatform $OSPlatform
                        Write-Log $Remote_Log "Total Time - $($FormatedTime)" $LogComponent "Info" -OSPlatform $OSPlatform
                        Write-Log $Remote_Log "==========[End Remote Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform

                        Add-Content -Path $STIGLog_Remote -Value $(Get-Content $Remote_Log)
                        Remove-Item $Remote_Log

                        $ProgressPreference = "Continue"
                    }
                    Catch {
                        Write-Host "Error: $($_.Exception.Message)"
                        Write-Log $Remote_Log "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $Remote_Log "==========[End Remote Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform

                        Add-Content -Path $STIGLog_Remote -Value $(Get-Content $Remote_Log)
                        Remove-Item $Remote_Log

                        If ($Session) {
                            #Write-Host " - Closing PS Session"
                            $Session | Remove-PSSession
                        }
                        $ProgressPreference = "Continue"
                        Continue
                    }
                }
                Else {
                    Write-Host "$($LinuxHost.FQDN) is running a Linux Operating System. PowerShell $($PowerShellVersion -join '.') detected.  Evaluate-STIG requires PowerShell 7.1."
                    $RemoteLinuxFail++
                    Write-Log $Remote_Log "$($LinuxHost.FQDN) is running a Linux Operating System. PowerShell $($PowerShellVersion -join '.') detected.  Evaluate-STIG requires PowerShell 7.1." $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Log $Remote_Log "==========[End Remote Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform

                    Add-Content -Path $STIGLog_Remote -Value $(Get-Content $Remote_Log)
                    Remove-Item $Remote_Log

                    Continue
                }
            }

            $RemoteTimeToComplete = New-TimeSpan -Start $StartTime -End (Get-Date)
            $FormatedTime = "{0:c}" -f $RemoteTimeToComplete
            Write-Log $STIGLog_Remote "We're done!" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Log $STIGLog_Remote "Total Time - $($FormatedTime)" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Log $STIGLog_Remote "Total Hosts - $($ComputerList.count)" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Log $STIGLog_Remote "Total Hosts with Error - $($RemoteLinuxFail + $(if ($RemoteFailCount.Values -ge 1){$($RemoteFailCount.Values)}else{"0"}))" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Log $STIGLog_Remote "Total Hosts Not Resolved - $RemoteUnresolveCount" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Log $STIGLog_Remote "Total Hosts Offline - $($OfflineList.Count)" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Host ""
            Write-Host ""
            Write-Host "Done!" -ForegroundColor Green
            Write-Host "Total Time - $($FormatedTime)" -ForegroundColor Green
            Write-Host "Total Hosts - $($ComputerList.count)" -ForegroundColor Green
            if ($($RemoteLinuxFail + $(if ($RemoteFailCount.Values -ge 1) { $($RemoteFailCount.Values) }else { "0" })) -gt 0) {
                Write-Host "Total Hosts with Error - $($RemoteLinuxFail + $(if ($RemoteFailCount.Values -ge 1){$($RemoteFailCount.Values)}else{"0"}))" -ForegroundColor Red
            }
            Write-Host "Total Hosts Not Resolved - $RemoteUnresolveCount" -ForegroundColor Yellow
            Write-Host "Total Hosts Offline - $($OfflineList.Count)" -ForegroundColor Yellow
            Write-Host ""
            Write-Host "Results saved to " -ForegroundColor Green -NoNewline; Write-Host "$($OutputPath)" -ForegroundColor Cyan
            Write-Host "Local logging of remote scan(s) stored at " -ForegroundColor Green -NoNewline; Write-Host "$($WorkingDir)" -ForegroundColor DarkCyan
            Write-Host ""

            If (Test-Path $RemoteWorkingDir\ESCONTENT.ZIP) {
                Remove-Item -Path $RemoteWorkingDir\ESCONTENT.ZIP -Force
            }
            If (Test-Path $RemoteWorkingDir\AFILES.ZIP) {
                Remove-Item -Path $RemoteWorkingDir\AFILES.ZIP -Force
            }
            Exit
        }
        Catch {
            Write-Host "Error: $($_.Exception.Message)"
            Write-Log $STIGLog_Remote "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Exit 1
        }
    }

    # ++++++++++++++++++++++ Begin processing ++++++++++++++++++++++
    Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Initializing and generating list of required STIGs"

    # Check if $ExcludeSTIG or $SelectSTIG contain a comma and if so, split them.  Needs to be in an array.  Can happen when calling Evaluate-STIG from Powershell.exe -File
    If ($ExcludeSTIG -and $ExcludeSTIG -match ","){
        $ExcludeSTIG = $ExcludeSTIG -Split ","
    }
    If ($SelectSTIG -and $SelectSTIG -match ",") {
        $SelectSTIG = $SelectSTIG -Split ","
    }

    If (Test-Path $STIGLog) {
        Remove-Item $STIGLog -Force
    }

    Write-Log $STIGLog "==========[Begin Local Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "Executing: $($MyInvocation.Line)" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform

    # Verify Evaluate-STIG files integrity
    $Verified = $true
    Write-Log $STIGLog "Verifying Evaluate-STIG file integrity..." $LogComponent "Info" -OSPlatform $OSPlatform
    If (Test-Path (Join-Path $PSScriptRoot -ChildPath "XmlSchema" | Join-Path -ChildPath "FileList.xml")) {
        [XML]$FileListXML = Get-Content -Path (Join-Path $PSScriptRoot -ChildPath "XmlSchema" | Join-Path -ChildPath "FileList.xml")
        If ((Test-XmlSignature -checkxml $FileListXML -Force) -ne $true) {
            Write-Log $STIGLog "'FileList.xml' failed authenticity check.  Unable to verify content integrity." $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: 'FileList.xml' failed authenticity check.  Unable to verify content integrity." -ForegroundColor Red
        }
        Else {
            ForEach ($File in $FileListXML.FileList.File) {
                $Path = (Join-Path -Path $PsScriptRoot -ChildPath $File.Path | Join-Path -Childpath $File.Name)
                If ((Get-FileHash -Path $Path -Algorithm SHA256).Hash -ne $File.SHA256Hash) {
                    $Verified = $false
                    Write-Log $STIGLog "'$($Path)' failed integrity check." $LogComponent "Warning" -OSPlatform $OSPlatform
                }
            }
            If ($Verified -eq $true) {
                Write-Log $STIGLog "Evaluate-STIG file integrity check passed." $LogComponent "Info" -OSPlatform $OSPlatform
            }
            Else {
                Write-Host "WARNING: One or more Evaluate-STIG files failed integrity check." -ForegroundColor Yellow
            }
        }
    }
    Else {
        Write-Log $STIGLog "'FileList.xml' not found.  Unable to verify content integrity." $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "ERROR: 'FileList.xml' not found.  Unable to verify content integrity." -ForegroundColor Red
    }

    # Validate STIGList.xml and answer file for proper schema usage.
    $STIGList_xsd = Join-Path -Path $PsScriptRoot -ChildPath "XmlSchema" | Join-Path -ChildPath "Schema_STIGList.xsd"
    $AnswerFile_xsd = Join-Path -Path $PsScriptRoot -ChildPath "XmlSchema" | Join-Path -ChildPath "Schema_AnswerFile.xsd"

    # STIGList.xml validation
    $XmlFile = Join-Path $PsScriptRoot -ChildPath "STIGList.xml"
    If (-Not(Test-Path $XmlFile)) {
        Write-Log $STIGLog "Error: '$XmlFile' - file not found.  Cannot continue." $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "Error: '$XmlFile' - file not found.  Cannot continue." -ForegroundColor Red
        Exit 10010001
    }
    ElseIf (-Not(Test-Path $STIGList_xsd)) {
        Write-Log $STIGLog "Error: '$STIGList_xsd' - file not found.  Cannot continue." $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "Error: '$STIGList_xsd' - file not found.  Cannot continue." -ForegroundColor Red
        Exit 10010001
    }
    ElseIf (-Not(Test-Path $AnswerFile_xsd)) {
        Write-Log $STIGLog "Error: '$AnswerFile_xsd' - file not found.  Cannot continue." $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "Error: '$AnswerFile_xsd' - file not found.  Cannot continue." -ForegroundColor Red
        Exit 10010001
    }

    $Result = Test-XmlValidation -XmlFile $XmlFile -SchemaFile $STIGList_xsd
    If ($Result -ne $true) {
        Write-Log $STIGLog "Error: '$($XmlFile)' failed XML validation:" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "Error: '$($XmlFile)' failed XML validation:" -ForegroundColor Red
        ForEach ($Item in $Result.Message) {
            Write-Log $STIGLog $Item $LogComponent "Warning" -OSPlatform $OSPlatform
            Write-Host $Item -ForegroundColor Yellow
        }
        Exit 10010001
    }

    Write-Log $STIGLog "Evaluate-STIG Version: $ESVersion" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "Launching User: $([Environment]::Username)" $LogComponent "Info" -OSPlatform $OSPlatform

    # Pre-checks passed.  Begin processing.
    $EvalStart = Get-Date

    # Test connectivity to OutputPath and create folder for computer
    Try {
        If (-Not(Test-Path $ResultsPath)) {
            $null = New-Item $ResultsPath -ItemType Directory -ErrorAction Stop
            Start-Sleep 5
        }
    }
    Catch {
        Write-Log $STIGLog "Failed to create output path $ResultsPath)" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        Exit 10010001
    }

    # Write configuration data to log
    Write-Log $STIGLog "Hostname: $env:COMPUTERNAME" $LogComponent "Info" -OSPlatform $OSPlatform
    Switch ($DomainRole) {
        0 {
            Write-Log $STIGLog "Domain Role: Standalone Workstation" $LogComponent "Info" -OSPlatform $OSPlatform
        } # Standalone Workstation (0)
        1 {
            Write-Log $STIGLog "Domain Role: Member Workstation" $LogComponent "Info" -OSPlatform $OSPlatform
        } # Member Workstation (1)
        2 {
            Write-Log $STIGLog "Domain Role: Standalone Server" $LogComponent "Info" -OSPlatform $OSPlatform
        } # Standalone Server (2)
        3 {
            Write-Log $STIGLog "Domain Role: Member Server" $LogComponent "Info" -OSPlatform $OSPlatform
        } # Member Server (3)
        4 {
            Write-Log $STIGLog "Domain Role: Domain Controller" $LogComponent "Info" -OSPlatform $OSPlatform
        } # Backup DC (4)
        5 {
            Write-Log $STIGLog "Domain Role: Domain Controller" $LogComponent "Info" -OSPlatform $OSPlatform
        } # Primary DC (4)
        Default {
            Write-Log $STIGLog "Domain Role: Unknown" $LogComponent "Info" -OSPlatform $OSPlatform
        }
    }
    Write-Log $STIGLog "OS Platform: $OSPlatform" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "PS Version: $PowerShellVersion" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "Scan Type: $ScanType" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "Answer Key: $AnswerKey" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "Answer File Path: $AFPath" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "Results Path: $ResultsPath" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform

    # --- Begin Answer File validation
    Write-Log $STIGLog "Validating answer files..." $LogComponent "Info" -OSPlatform $OSPlatform
    $AnswerFileList = New-Object System.Collections.Generic.List[System.Object]
    $XmlFiles = Get-ChildItem -Path $AFPath | Where-Object Extension -eq ".xml"

    # Create temporary old schema file to look for answer files formatted for pre Evaluate-STIG 1.2107.0
    $OldSchemaFile = (Join-Path -Path $WorkingDir -ChildPath "ES_OldSchema.xsd")
    $OldSchema = '<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">' | Out-String
    $OldSchema += '  <xs:element name="STIGComments">' | Out-String
    $OldSchema += '    <xs:complexType>' | Out-String
    $OldSchema += '      <xs:sequence>' | Out-String
    $OldSchema += '        <xs:element name="Vuln" maxOccurs="unbounded" minOccurs="0">' | Out-String
    $OldSchema += '          <xs:complexType>' | Out-String
    $OldSchema += '            <xs:sequence>' | Out-String
    $OldSchema += '              <xs:element name="AnswerKey"  maxOccurs="unbounded" minOccurs="1">' | Out-String
    $OldSchema += '                <xs:complexType>' | Out-String
    $OldSchema += '                  <xs:sequence>' | Out-String
    $OldSchema += '                    <xs:element type="xs:string" name="ApprovedComment" maxOccurs="1" minOccurs="1"/>' | Out-String
    $OldSchema += '                    <xs:element name="ExpectedStatus">' | Out-String
    $OldSchema += '                      <xs:simpleType>' | Out-String
    $OldSchema += '                        <xs:restriction base="xs:string">' | Out-String
    $OldSchema += '                          <xs:enumeration value="Not_Reviewed"/>' | Out-String
    $OldSchema += '                          <xs:enumeration value="Open"/>' | Out-String
    $OldSchema += '                          <xs:enumeration value="NotAFinding"/>' | Out-String
    $OldSchema += '                          <xs:enumeration value="Not_Applicable"/>' | Out-String
    $OldSchema += '                        </xs:restriction>' | Out-String
    $OldSchema += '                      </xs:simpleType>' | Out-String
    $OldSchema += '                    </xs:element>' | Out-String
    $OldSchema += '                    <xs:element name="FinalStatus">' | Out-String
    $OldSchema += '                      <xs:simpleType>' | Out-String
    $OldSchema += '                        <xs:restriction base="xs:string">' | Out-String
    $OldSchema += '                          <xs:enumeration value="Not_Reviewed"/>' | Out-String
    $OldSchema += '                          <xs:enumeration value="Open"/>' | Out-String
    $OldSchema += '                          <xs:enumeration value="NotAFinding"/>' | Out-String
    $OldSchema += '                          <xs:enumeration value="Not_Applicable"/>' | Out-String
    $OldSchema += '                        </xs:restriction>' | Out-String
    $OldSchema += '                      </xs:simpleType>' | Out-String
    $OldSchema += '                    </xs:element>' | Out-String
    $OldSchema += '                    <xs:element type="xs:string" name="ValidationCode"/>' | Out-String
    $OldSchema += '                  </xs:sequence>' | Out-String
    $OldSchema += '                  <xs:attribute type="xs:string" name="Name" use="required"/>' | Out-String
    $OldSchema += '                </xs:complexType>' | Out-String
    $OldSchema += '              </xs:element>' | Out-String
    $OldSchema += '            </xs:sequence>' | Out-String
    $OldSchema += '            <xs:attribute type="xs:string" name="ID" use="required"/>' | Out-String
    $OldSchema += '          </xs:complexType>' | Out-String
    $OldSchema += '          <xs:unique name="AnswerKeyUniqueKey">' | Out-String
    $OldSchema += '            <xs:selector xpath="AnswerKey"/>' | Out-String
    $OldSchema += '            <xs:field xpath="@Name"/>' | Out-String
    $OldSchema += '          </xs:unique>' | Out-String
    $OldSchema += '        </xs:element>' | Out-String
    $OldSchema += '      </xs:sequence>' | Out-String
    $OldSchema += '      <xs:attribute type="xs:string" name="Name" use="required"/>' | Out-String
    $OldSchema += '    </xs:complexType>' | Out-String
    $OldSchema += '    <xs:unique name="VulnIdUniqueKey">' | Out-String
    $OldSchema += '      <xs:selector xpath="Vuln"/>' | Out-String
    $OldSchema += '      <xs:field xpath="@ID"/>' | Out-String
    $OldSchema += '    </xs:unique>' | Out-String
    $OldSchema += '  </xs:element>' | Out-String
    $OldSchema += '</xs:schema>' | Out-String
    $OldSchema | Out-File $OldSchemaFile -Force

    # Verify answer files for proper format...
    ForEach ($Item in $XmlFiles) {
        $Validation = (Test-XmlValidation -XmlFile $Item.FullName -SchemaFile $AnswerFile_xsd)
        If ($Validation -eq $true) {
            Write-Log $STIGLog "$($Item.Name) : Passed" $LogComponent "Info" -OSPlatform $OSPlatform
            [XML]$Content = Get-Content $Item.FullName
            If ($Content.STIGComments.Name) {
                $NewObj = [PSCustomObject]@{
                    STIG       = $Content.STIGComments.Name
                    AnswerFile = $Item.Name
                    LastWriteTime  = $Item.LastWriteTime
                }
                $AnswerFileList.Add($NewObj)
            }
        }
        ElseIf ((Test-XmlValidation -XmlFile $Item.FullName -SchemaFile $OldSchemaFile) -eq $true) {
            Write-Log $STIGLog "$($Item.Name) : Warning - Answer file is for an older version of Evaluate-STIG and will be ignored.  Please update to new schema." $LogComponent "Warning" -OSPlatform $OSPlatform
            Write-Host "Warning: $($Item.FullName) is for an older version of Evaluate-STIG and will be ignored.  Please update to new schema." -ForegroundColor Yellow
        }
        Else {
            Write-Log $STIGLog "$($Item.Name) : Error - Answer file failed schema validation and will be ignored.  Please correct or remove." $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "$($Validation.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "Error: '$($Item.FullName) failed schema validation and will be ignored.  Please correct or remove." -ForegroundColor Red
            Write-Host "$($Validation.Message)" -ForegroundColor Red
            Write-Host ""
        }
   }

   $AnswerFileList = $AnswerFileList | Sort-Object LastWriteTime -Descending
   Remove-Item $OldSchemaFile -Force
   Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
   # --- End Answer File validation

    # Build list of required STIGs
    Write-Log $STIGLog "Gathing list of STIGs applicable to this sytem..." $LogComponent "Info" -OSPlatform $OSPlatform
    Try {
        [XML]$STIGList = Get-Content (Join-Path -Path $PsScriptRoot -ChildPath "STIGList.xml")
        $STIGsToProcess = New-Object System.Collections.Generic.List[System.Object]
        If ($SelectSTIG) {
            ForEach ($Node in $STIGList.List.ChildNodes) {
                If ($Node.Shortname -in $SelectSTIG) {
                    If ($Node.DetectionCode -and (Invoke-Expression $Node.DetectionCode) -eq $true) {
                        If ($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)}) {
                            $AFtoUse = (($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)})[0]).AnswerFile
                        }
                        Else {
                            $AFtoUse = ""
                        }
                        $NewObj = [PSCustomObject]@{
                            Name       = $Node.Name
                            Shortname  = $Node.ShortName
                            Template   = $Node.Template
                            AnswerFile = $AFtoUse
                            PsModule   = $Node.PsModule
                        }
                        $STIGsToProcess.Add($NewObj)
                    }
                    Else {
                        Write-Log $STIGLog "Scan for '$($Node.Name)' requested with -SelectSTIG but is not applicable to this system so will be ignored." $LogComponent "Warning" -OSPlatform $OSPlatform
                        Write-Host "Warning: Scan for '$($Node.Name)' requested with -SelectSTIG but is not applicable to this system so will be ignored." -ForegroundColor Yellow
                    }
                }
            }
        }
        Else {
            ForEach ($Node in $STIGList.List.ChildNodes) {
                If ($Node.DetectionCode -and (Invoke-Expression $Node.DetectionCode) -eq $true) {
                    If ($Node.Shortname -in $ExcludeSTIG) {
                        Write-Log $STIGLog "'$($Node.Name)' is applicable to this system but has been excluded from scan with the -ExcludeSTIG option." $LogComponent "Warning" -OSPlatform $OSPlatform
                    }
                    Else {
                        If ($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)}) {
                            $AFtoUse = (($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)})[0]).AnswerFile
                        }
                        Else {
                            $AFtoUse = ""
                        }
                        $NewObj = [PSCustomObject]@{
                            Name       = $Node.Name
                            Shortname  = $Node.ShortName
                            Template   = $Node.Template
                            AnswerFile = $AFtoUse
                            PsModule   = $Node.PsModule
                        }
                        $STIGsToProcess.Add($NewObj)
                    }
                }
            }
        }
        [int]$TotalMainSteps = $TotalMainSteps + $STIGsToProcess.Count
    }
    Catch {
        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        Exit 10010001
    }

    # Write list of STIGs that will be evaluated to log
    Write-Log $STIGLog "The following STIGs will be evaluated:" $LogComponent "Info" -OSPlatform $OSPlatform
    ForEach ($STIG in $STIGsToProcess) {
        Write-Log $STIGLog "STIG: $($STIG.Name)  |  AnswerFile: $($STIG.AnswerFile)" $LogComponent "Info" -OSPlatform $OSPlatform
    }
    Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform

    # Confirm STIG specific prerequisites are met
    If (($STIGsToProcess.Name -like "Microsoft SQL Server*") -or ($STIGsToProcess.Name -like "IIS *")) {
        $AvailModules = (Get-Module -ListAvailable -All).Name
        # IIS
        If ($STIGsToProcess.Name -like "IIS *") {
            If ("WebAdministration" -notin $AvailModules) {
                Write-Log $STIGLog "'WebAdministration' module is not available to PowerShell." $LogComponent "Warning" -OSPlatform $OSPlatform
                Write-Log $STIGLog "IIS checklists will not be generated." $LogComponent "Warning" -OSPlatform $OSPlatform
                Write-Host "Error: 'WebAdministration' module is not available to PowerShell. IIS checklists will not be generated." -ForegroundColor Yellow
                $STIGsToIgnore = $STIGsToProcess | Where-Object Name -like "IIS *"
                ForEach ($Obj in $STIGsToIgnore) {
                    [Void]$STIGsToProcess.Remove($Obj)
                }
            }
        }

        # SQL Server
        If ($STIGsToProcess.Name -like "Microsoft SQL Server*") {
            If ("SqlServer" -notin $AvailModules) {
                Write-Log $STIGLog "'SqlServer' module is not available to PowerShell." $LogComponent "Warning" -OSPlatform $OSPlatform
                Write-Log $STIGLog "SQL checklists will not be generated." $LogComponent "Warning" -OSPlatform $OSPlatform
                Write-Host "Error: 'SqlServer' module is not available to PowerShell. SQL checklists will not be generated." -ForegroundColor Yellow
                $STIGsToIgnore = $STIGsToProcess | Where-Object Name -like "Microsoft SQL Server*"
                ForEach ($Obj in $STIGsToIgnore) {
                    [Void]$STIGsToProcess.Remove($Obj)
                }
            }
        }
        Remove-Variable AvailModules
    }

    # If no supported STIGs are applicable, just exit
    If ($STIGsToProcess.count -eq 0) {
        Write-Log $STIGLog "No Evaluate-STIG supported STIGs are applicable to this system.  Exiting." $LogComponent "Warning" -OSPlatform $OSPlatform
        Write-Host "No Evaluate-STIG supported STIGs are applicable to this system.  Exiting." -ForegroundColor Yellow
    }
    else{
        Write-Log $STIGLog "Applicable STIGs to process - $($STIGsToProcess.count)" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Host "Applicable STIGs to process - $($STIGsToProcess.count)" -ForegroundColor Magenta
    }

    # Remove orphaned objects
    Write-Log $STIGLog "Checking for and removing orphaned objects from a previous scan..." $LogComponent "Info" -OSPlatform $OSPlatform
    Try {
        $TempFiles = Get-Item -Path $WorkingDir\* -Exclude Evaluate-STIG.log,Evaluate-STIG_Remote.log,RemoteScanTemp
        If ($TempFiles) {
            ForEach ($Item in $TempFiles) {
                Write-Log $STIGLog "Removed orphaned object: $($Item.FullName)" $LogComponent "Info" -OSPlatform $OSPlatform
                $null = Remove-Item -Path $Item.FullName -Recurse -ErrorAction Stop
            }
        }
        Switch ($OSPlatform) {
            "Windows" {
                # Remove existing Evaluate-STIG_UserHive in case it exists
                If (Test-Path -Path Registry::HKLM\SOFTWARE\Evaluate-STIG_UserHive) {
                    $null = Remove-Item -Path Registry::HKLM\SOFTWARE\Evaluate-STIG_UserHive -Recurse -Force -ErrorAction Stop
                    Write-Log $STIGLog "Removed orphaned object: HKLM:SOFTWARE\Evaluate-STIG_UserHive" $LogComponent "Info" -OSPlatform $OSPlatform
                }
            }
            "Linux" {
                # TBD
            }
        }
    }
    Catch {
        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        Exit 10010001
    }

    if ($STIGsToProcess.count -gt 0) {
        If ($GenerateOQE) {
            $TotalMainSteps = $TotalMainSteps + 1
        }

        # OS dependent steps
        If ($OSPlatform -eq "Windows") {
            $TotalMainSteps = $TotalMainSteps + 1
            $ExtFilesRequired = $false
            ForEach ($Item in $STIGsToProcess.ShortName) {
                If ($Item -in @("DotNET4", "Win10", "WinServer2012DC", "WinServer2012MS", "WinServer2016", "WinServer2019")) {
                    $ExtFilesRequired = $true
                }
            }
            If ($ExtFilesRequired -eq $true) {
                $TotalMainSteps = $TotalMainSteps + 1
            }

            # =========== Determine User to Evaluate ===========
            Write-Log $STIGLog "Determining which user to evaluate for HKCU items" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Determining user to evaluate and importing registry hive" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
            $CurrentMainStep++

            # Get all profile paths and find which ntuser.pol was most recently updated.
            $UserToProcess = Get-UsersToEval -ProvideSingleUser
            If ($UserToProcess) {
                Write-Log $STIGLog "Will evaluate $($UserToProcess.Username) for user-based settings..." $LogComponent "Info" -OSPlatform $OSPlatform
                Write-Log $STIGLog "    SID: $($UserToProcess.SID)" $LogComponent "Info" -OSPlatform $OSPlatform
                If ($UserToProcess.LastPolicyUpdate -eq "Never") {
                    Write-Log $STIGLog "    Policy Updated: $($UserToProcess.LastPolicyUpdate)" $LogComponent "Info" -OSPlatform $OSPlatform
                }
                Else {
                    Write-Log $STIGLog "    Policy Updated: $($UserToProcess.LastPolicyUpdate) ($((New-TimeSpan -Start $UserToProcess.LastPolicyUpdate -End (Get-Date)).Days) days ago)" $LogComponent "Info" -OSPlatform $OSPlatform
                }
                Write-Log $STIGLog "    Last Used: $($UserToProcess.LastUseTime)" $LogComponent "Info" -OSPlatform $OSPlatform
                Write-Log $STIGLog "    Profile Path: $($UserToProcess.LocalPath)" $LogComponent "Info" -OSPlatform $OSPlatform
            }
            Else {
                Write-Log $STIGLog "No scannable user profile found.  Will evaluate .DEFAULT profile for user-based settings" $LogComponent "Warning" -OSPlatform $OSPlatform
                $UserToProcess = @{ }
                $UserToProcess.UserName = ".DEFAULT"
                $UserToProcess.SID = ".DEFAULT"
            }

            # =========== Export and Load User Registry Hive ===========
            # If SID is not listed in HKEY_USERS, user is not currently logged on and we must load the hive from NTUSER.dat
            $RegLoadRequired = $false
            If (-Not(Test-Path -Path Registry::HKU\$($UserToProcess.SID))) {
                $RegLoadRequired = $true
                Write-Log $STIGLog "User is not currently logged on.  Loading NTUSER.dat to HKU:\$($UserToProcess.SID)" $LogComponent "Info" -OSPlatform $OSPlatform
                $NTUSER_DAT = [Char]34 + "$($UserToProcess.LocalPath)\NTUSER.DAT" + [Char]34
                Start-Process -FilePath REG.exe -ArgumentList "LOAD HKU\$($UserToProcess.SID) $($NTUSER_DAT)" -Wait -WindowStyle Hidden
            }

            # Export the user's hive and then temporarily import it to HKLM\SOFTWARE\Evaluate-STIG_UserHive.  In the event that the user logs off while the script is executing, we still have access to the user's registry data for checks.
            $UserHive_UnmodifiedName = "Evaluate-STIG_UserHive_Original.reg"
            $StreamWriter = [IO.File]::CreateText("$WorkingDir\Evaluate-STIG_UserHive.reg")
            Write-Log $STIGLog "Creating temporary copy of user's registry hive to HKLM:\SOFTWARE\Evaluate-STIG_UserHive" $LogComponent "Info" -OSPlatform $OSPlatform
            Start-Process -FilePath REG.exe -ArgumentList "EXPORT HKU\$($UserToProcess.SID) $($WorkingDir)\$($UserHive_UnmodifiedName) /y" -Wait -WindowStyle Hidden
            Switch -File "$WorkingDir\$UserHive_UnmodifiedName" {
                Default {
                    # In effort to properly import "defaultformat" registry value for MS Word, replace line "defaultformat"=" with "defaultformat"="" and remove the follow on whitespace line
                    $StreamWriter.Write($_.Replace("[HKEY_USERS", "[HKEY_LOCAL_MACHINE\SOFTWARE\Evaluate-STIG_UserHive").Replace('"defaultformat"="', '"defaultformat"=""').Replace('              "', '') + "`r`n")
                }
            }
            $StreamWriter.Close()
            Start-Process -FilePath REG.exe -ArgumentList "IMPORT $($WorkingDir)\Evaluate-STIG_UserHive.reg" -Wait -WindowStyle Hidden

            # If we had to load the NTUSER.dat into the registry, we unload it here.
            If ($RegLoadRequired -eq $true) {
                [System.GC]::Collect() # garbage collection to help unload the hive
                Write-Log $STIGLog "Unloading hive HKU:\$($UserToProcess.SID)" $LogComponent "Info" -OSPlatform $OSPlatform
                Start-Process -FilePath REG.exe -ArgumentList "UNLOAD HKU\$($UserToProcess.SID)" -Wait -WindowStyle Hidden
            }

            # =========== Create External Reference Files ===========
            If ($ExtFilesRequired -eq $true) {
                Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Creating temporary export files for enumeration" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
                $CurrentMainStep++

                # AppLocker
                ForEach ($Item in $STIGsToProcess.ShortName) {
                    If ($Item -in @("Win10", "WinServer2012DC", "WinServer2012MS", "WinServer2016", "WinServer2019")) {
                        $AppLockerRequired = $true
                    }
                }
                If ($AppLockerRequired -eq $true) {
                    Try {
                        Write-Log $STIGLog "Collecting AppLocker effective policy and saving to $($WorkingDir)\$($AppLockerPolFile)" $LogComponent "Info" -OSPlatform $OSPlatform
                        $AppLockerPolFile = "AppLockerPol_$(${env:computername})_$($Date).xml"
                        If (($PsVersionTable.PSVersion -join ".") -lt [Version]"7.0") {
                            Import-Module AppLocker
                        }
                        Else {
                            Import-Module AppLocker -SkipEditionCheck
                        }
                        Get-AppLockerPolicy -Effective -Xml -ErrorAction Stop | Out-File $WorkingDir\$($AppLockerPolFile) -Force
                    }
                    Catch {
                        $AppLockerRequired = $false
                        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    }
                }

                # Security Policy
                ForEach ($Item in $STIGsToProcess.ShortName) {
                    If ($Item -in @("Win10", "WinServer2012DC", "WinServer2012MS", "WinServer2016", "WinServer2019")) {
                        $SecPolRequired = $true
                    }
                }
                If ($SecPolRequired -eq $true) {
                    Try {
                        Write-Log $STIGLog "Exporting security policy" $LogComponent "Info" -OSPlatform $OSPlatform
                        $SecPolFileName = "Evaluate-STIG_SecPol.ini"
                        Start-Process -FilePath secedit.exe -ArgumentList "/export /cfg $($WorkingDir)\$($SecPolFileName)" -Wait -WindowStyle Hidden
                    }
                    Catch {
                        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
                        Exit 10010001
                    }
                }

                # List of .exe.config files
                $ConfigFileListRequired = $false
                ForEach ($Item in $STIGsToProcess.ShortName) {
                    If ($Item -in @("DotNET4")) {
                        $ConfigFileListRequired = $true
                    }
                }
                If ($ConfigFileListRequired -eq $true) {
                    Try {
                        Write-Log $STIGLog "Collecting list of machine.config and *.exe.config files for .NET Framework 4 STIG to $($WorkingDir)\Evaluate-STIG_Net4FileList.txt" $LogComponent "Info" -OSPlatform $OSPlatform

                        # Get .Net 4 Framework machine.config files
                        $frameworkMachineConfig = "$env:SYSTEMROOT\Microsoft.NET\Framework\v4.0.30319\Config\machine.config"
                        $framework64MachineConfig = "$env:SYSTEMROOT\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config"

                        # Get hard disk drive letters
                        $driveLetters = (Get-CimInstance Win32_LogicalDisk | Where-Object DriveType -eq 3)

                        # Get configuration files
                        $allConfigFiles = @()
                        $allConfigFiles += Get-ChildItem $frameworkMachineConfig
                        $allConfigFiles += Get-ChildItem $framework64MachineConfig
                        $allConfigFiles += (ForEach-Object -InputObject $driveLetters { Get-ChildItem ($_.DeviceID + "\") -Recurse -Filter *.exe.config -ErrorAction SilentlyContinue | Where-Object { ($_.FullName -NotLike "*Windows\CSC\*") -and ($_.FullName -NotLike "*Windows\WinSxS\*") } })
                        $allConfigFiles.FullName | Out-File $WorkingDir\Evaluate-STIG_Net4FileList.txt -Force
                    }
                    Catch {
                        $ConfigFileListRequired = $false
                        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    }
                }
            }
        }
        Else {
            # Set UserName and SID to "NA"
            $UserToProcess = @{
                UserName = whoami
                SID      = "NA"
            }
        }

        # =========== Build Checklists ===========
        ForEach ($Item in $STIGsToProcess) {
            If ($Item.ShortName -like "IIS*") {
                Remove-Module WebAdministration -ErrorAction SilentlyContinue
                Import-Module WebAdministration -WarningAction SilentlyContinue
            }
            [System.GC]::Collect()
            [XML]$CKLData = Get-Content -Path (Join-Path -Path "$PsScriptRoot\CKLTemplates" -ChildPath $($Item.Template))
            [int]$TotalSubSteps = ($CKLData.CHECKLIST.STIGS.iSTIG.vuln).Count
            [int]$CurrentSubStep = 1
            Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Evaluating STIG: $($Item.Name)" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
            Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
            $CurrentMainStep++
            Try {
                # Generate Checklist
                Write-Log $STIGLog "Generating checklist for $($Item.Name) and saving to $ResultsPath" $LogComponent "Info" -OSPlatform $OSPlatform
                If (-Not(Test-Path -Path (Join-Path -Path $ResultsPath -ChildPath "Checklist"))) {
                    $null = New-Item -Path $ResultsPath -Name "Checklist" -ItemType Directory
                }

                $PsModule = $null
                If ($Item.PsModule) {
                    Try {
                        Write-Log $STIGLog "Importing scan module: $($Item.PsModule)" $LogComponent "Info" -OSPlatform $OSPlatform
                        If ($PowerShellVersion -lt [Version]"7.0") {
                            Import-Module (Join-Path -Path "$PsScriptRoot\Modules" -ChildPath $($Item.PsModule)) -ErrorAction Stop
                        }
                        Else {
                            Import-Module (Join-Path -Path "$PsScriptRoot\Modules" -ChildPath $($Item.PsModule)) -SkipEditionCheck -ErrorAction Stop
                        }
                        $PsModule = (Get-Module $Item.PsModule)
                        Write-Log $STIGLog "Module Version: $($PsModule.Version)" $LogComponent "Info" -OSPlatform $OSPlatform
                    }
                    Catch {
                        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
                        Exit 10010001
                    }
                }

                $HashArguments = @{
                    TemplateName       = $($Item.Template)
                    CklSourcePath      = (Join-Path -Path $PsScriptRoot -ChildPath "CKLTemplates")
                    CklDestinationPath = (Join-Path -Path $ResultsPath -ChildPath "Checklist")
                    ScanType           = $($ScanType)
                    AnswerKey          = $($AnswerKey)
                    WorkingDir         = $($WorkingDir)
                    Username           = $($UserToProcess.Username)
                    UserSID            = $($UserToProcess.SID)
                    OSPlatform         = $($OSPlatform)
                    ProgressId         = $($ProgressId)
                    TotalSubSteps      = $($TotalSubSteps)
                    CurrentSubStep     = $($CurrentSubStep)
                }
                If ($PsModule) {
                    $HashArguments.Add("PsModule", $($PsModule))
                }
                If (($Item.AnswerFile) -and (Test-Path -Path (Join-Path -Path $AFPath -ChildPath $($Item.AnswerFile)))) {
                    $AnswerFileToPass = (Join-Path -Path $AFPath -ChildPath $($Item.AnswerFile))
                    $HashArguments.Add("AnswerFile", $($AnswerFileToPass))
                }

                # Create ckl file(s)
                Switch ($Item.Name) {
                    "Apache 2.4 Site Windows" {
                        # Get all the instances of apache running and their relevant information.

                        $ApacheInstances = @(Get-ApacheSites)
                        $HashArguments.Add("ApacheInstance", $null)
                        $HashArguments.Add("VirtualHost", $null)

                        foreach ($instance in $ApacheInstances) {
                            $HashArguments.ApacheInstance = $instance
                            foreach ($vhost in $instance.VirtualHosts) {
                                $HashArguments.VirtualHost = $vhost
                                Write-Log $STIGLog "----------------Writing CKL------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                Write-Ckl @HashArguments
                            }
                        }
                    }
                    "Apache 2.4 Server Windows" {
                        # Get all the instances of apache running and their relevant information.

                        $ApacheInstances = @(Get-ApacheSites)
                        $HashArguments.Add("ApacheInstance", $null)
                        $HashArguments.Add("VirtualHost", $null)

                        foreach ($instance in $ApacheInstances) {
                            $HashArguments.ApacheInstance = $instance
                            $HashArguments.VirtualHost = $null
                            Write-Log $STIGLog "----------------Writing CKL------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                            Write-Ckl @HashArguments
                        }
                    }
                    "IIS 8.5 Site" {
                        $HashArguments.Add("WebOrDB", "Web")
                        $HashArguments.Add("Site", "")
                        # Run IIS Site STIG for each website
                        If (($PsVersionTable.PSVersion -join ".") -lt [Version]"6.0") {
                            $AllSites = Get-WebSite
                        }
                        Else {
                            $PSCommand = "PowerShell.exe -Command {Get-WebSite}"
                            $AllSites = Invoke-Expression $PSCommand
                        }
                        $i = 0
                        ForEach ($Site in $Allsites) {
                            $HashArguments.Site = "$($Site.Name)"
                            If ($i -gt 0) {
                                Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                            }
                            Write-Ckl @HashArguments
                            $i++
                        }
                    }
                    "IIS 10.0 Site" {
                        $HashArguments.Add("WebOrDB", "Web")
                        $HashArguments.Add("Site", "")
                        # Run IIS Site STIG for each website
                        If (($PsVersionTable.PSVersion -join ".") -lt [Version]"6.0") {
                            $AllSites = Get-WebSite
                        }
                        Else {
                            $PSCommand = "PowerShell.exe -Command {Get-WebSite}"
                            $AllSites = Invoke-Expression $PSCommand
                        }
                        $i = 0
                        ForEach ($Site in $Allsites) {
                            $HashArguments.Site = "$($Site.Name)"
                            If ($i -gt 0) {
                                Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                            }
                            Write-Ckl @HashArguments
                            $i++
                        }
                    }

                    "Microsoft SQL Server 2016 Instance" {
                        $HashArguments.Add("WebOrDB", "DB")
                        $HashArguments.Add("Instance", "Instance")
                        $HashArguments.Add("Database", "master")
                        Import-Module -Name SQLServer -WarningAction SilentlyContinue
                        $allInstances = Get-AllInstances
                        $i = 0
                        ForEach ($Instance in $allInstances) {
                            If ((Get-InstanceVersion $Instance) -ge 2016) {
                                $HashArguments.Instance = "$($Instance)"
                                If ($i -gt 0) {
                                    Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                }
                                Write-Ckl @HashArguments
                                $i++
                            }
                        }
                    }

                    "Microsoft SQL Server 2016 Database" {
                        $HashArguments.Add("WebOrDB", "DB")
                        $HashArguments.Add("Instance", "")
                        $HashArguments.Add("Database", "")
                        Import-Module -Name SQLServer -WarningAction SilentlyContinue
                        $allInstances = Get-AllInstances
                        ForEach ($Instance in $allInstances) {
                            If ((Get-InstanceVersion $Instance) -ge 2016) {
                                $HashArguments.Instance = "$Instance"
                                $allDatabases = (invoke-sqlcmd "select name from sys.databases where state = 0" -ServerInstance $Instance).Name
                                $i = 0
                                ForEach ($Database in $allDatabases) {
                                    $HashArguments.Database = "$Database"
                                    If ($i -gt 0) {
                                        Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                    }
                                    Write-Ckl @HashArguments
                                    $i++
                                }
                            }
                        }
                    }

                    "Microsoft SQL Server 2014 Instance" {
                        $HashArguments.Add("WebOrDB", "DB")
                        $HashArguments.Add("Instance", "Instance")
                        $HashArguments.Add("Database", "master")
                        Import-Module -Name SQLServer -WarningAction SilentlyContinue
                        $allInstances = Get-AllInstances
                        $i = 0
                        ForEach ($Instance in $allInstances) {
                            If ((Get-InstanceVersion $Instance) -eq 2014) {
                                $HashArguments.Instance = "$($Instance)"
                                If ($i -gt 0) {
                                    Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                }
                                Write-Ckl @HashArguments
                                $i++
                            }
                        }
                    }

                    "Microsoft SQL Server 2014 Database" {
                        $HashArguments.Add("WebOrDB", "DB")
                        $HashArguments.Add("Instance", "")
                        $HashArguments.Add("Database", "")
                        Import-Module -Name SQLServer -WarningAction SilentlyContinue
                        $allInstances = Get-AllInstances
                        ForEach ($Instance in $allInstances) {
                            If ((Get-InstanceVersion $Instance) -eq 2014) {
                                $HashArguments.Instance = "$Instance"
                                $allDatabases = (invoke-sqlcmd "select name from sys.databases where state = 0" -ServerInstance $Instance).Name
                                $i = 0
                                ForEach ($Database in $allDatabases) {
                                    $HashArguments.Database = "$Database"
                                    If ($i -gt 0) {
                                        Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                    }
                                    Write-Ckl @HashArguments
                                    $i++
                                }
                            }
                        }
                    }

                    Default {
                        Write-Ckl @HashArguments
                    }
                }

                If ($Item.PsModule) {
                    Write-Log $STIGLog "Removing scan module from memory" $LogComponent "Info" -OSPlatform $OSPlatform
                    Remove-Module $PsModule -Force
                }
            }
            Catch {
                Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Log $STIGLog "Continuing Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            }
        }

        Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
        If ($GenerateOQE) {
            Switch ($OSPlatform) {
                "Windows" {
                    Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Generating Objective Quality Evidence (OQE) output" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
                    $CurrentMainStep++
                    Write-Log $STIGLog "Generating Objective Quality Evidence (OQE) output..." $LogComponent "Info" -OSPlatform $OSPlatform
                    Try {
                        If (-Not(Test-Path "$ResultsPath\OQE")) {
                            $null = New-Item -Path $ResultsPath -Name "OQE" -ItemType Directory
                        }

                        # Group Policy Report
                        Try {
                            Write-Log $STIGLog "Pulling Group Policy Report" $LogComponent "Info" -OSPlatform $OSPlatform
                            $GPResultFile = "GPResult_$(${env:computername})_$($Date).html"
                            If ($UserToProcess.SID -ne ".DEFAULT") {
                                Start-Process -FilePath GPResult.exe -ArgumentList "/USER $($UserToProcess.Username) /H $WorkingDir\$($GPResultFile)" -Wait -WindowStyle Hidden
                            }
                            Else {
                                Write-Log $STIGLog "    .DEFAULT selected as user to evaluate.  Group Policy results will not include user policies." $LogComponent "Warning" -OSPlatform $OSPlatform
                                Start-Process -FilePath GPResult.exe -ArgumentList "/SCOPE COMPUTER /H $WorkingDir\$($GPResultFile)" -Wait -WindowStyle Hidden
                            }
                            Get-ChildItem "$ResultsPath\OQE" -ErrorAction SilentlyContinue | Where-Object Name -like "GPResult*" | Remove-Item -Force -ErrorAction Stop # Clean previous GPResult files from output path
                            Copy-Item $WorkingDir\$($GPResultFile) -Destination "$ResultsPath\OQE"
                        }
                        Catch {
                            Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }

                        # AppLocker Report
                        Try {
                            If ($AppLockerRequired -ne $true) {
                                Write-Log $STIGLog "Collecting AppLocker effective policy" $LogComponent "Info" -OSPlatform $OSPlatform
                                $AppLockerPolFile = "AppLockerPol_$(${env:computername})_$($Date).xml"
                                If (($PsVersionTable.PSVersion -join ".") -lt [Version]"7.0") {
                                    Import-Module AppLocker
                                }
                                Else {
                                    Import-Module AppLocker -SkipEditionCheck
                                }
                                Get-AppLockerPolicy -Effective -Xml -ErrorAction Stop | Out-File $WorkingDir\$($AppLockerPolFile) -Force -Encoding UTF8
                            }
                            Get-ChildItem "$ResultsPath\OQE" | Where-Object Name -like "AppLocker*" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction Stop # Clean previous AppLocker result files from output path
                            Copy-Item $WorkingDir\$($AppLockerPolFile) -Destination "$ResultsPath\OQE"
                        }
                        Catch {
                            Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }

                        # Security Policy
                        Try {
                            If ($SecPolRequired -ne $true) {
                                Write-Log $STIGLog "Exporting security policy" $LogComponent "Info" -OSPlatform $OSPlatform
                                $SecPolFileName = "Evaluate-STIG_SecPol.ini"
                                Start-Process -FilePath secedit.exe -ArgumentList "/export /cfg $($WorkingDir)\$($SecPolFileName)" -Wait -WindowStyle Hidden
                            }
                            Get-ChildItem "$ResultsPath\OQE" -ErrorAction SilentlyContinue | Where-Object Name -like "SecPol*" | Remove-Item -Force -ErrorAction Stop # Clean previous Security Policy export files from output path
                            Copy-Item $WorkingDir\$($SecPolFileName) -Destination "$ResultsPath\OQE\SecPol_$(${env:computername})_$($Date).ini" -Force
                        }
                        Catch {
                            Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }
                    }
                    Catch {
                        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    }
                }
            }
        }

        # Cleanup
        If ($OSPlatform -eq "Windows") {
            # Remove deprecated BenchmarkScan folder
            If (Test-Path $ResultsPath\BenchmarkScan) {
                Write-Log $STIGLog "Removing deprecated BenchmarkScan folder" $LogComponent "Info" -OSPlatform $OSPlatform
                Remove-Item $ResultsPath\BenchmarkScan -Recurse -Force -ErrorAction SilentlyContinue
            }

            # Remove deprecated GPResult folder
            If (Test-Path "$ResultsPath\GPResult") {
                Write-Log $STIGLog "Removing deprecated GPResult folder" $LogComponent "Info" -OSPlatform $OSPlatform
                Remove-Item "$ResultsPath\GPResult" -Recurse -Force -ErrorAction SilentlyContinue
            }

            # Remove deprecated AppLocker folder
            If (Test-Path "$ResultsPath\AppLocker") {
                Write-Log $STIGLog "Removing deprecated AppLocker folder" $LogComponent "Info" -OSPlatform $OSPlatform
                Remove-Item "$ResultsPath\AppLocker" -Recurse -Force
            }

            # Clean up temporary user hive
            Write-Log $STIGLog "Remove temporary copy of user's registry hive HKLM:\SOFTWARE\Evaluate-STIG_UserHive" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Finalizing and cleaning up" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)

            Try {
                If (Test-Path -Path Registry::HKLM\SOFTWARE\Evaluate-STIG_UserHive) {
                    Remove-Item -Path Registry::HKLM\SOFTWARE\Evaluate-STIG_UserHive -Recurse -Force
                }
            }
            Catch {
                Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
                Exit 10010001
            }
        }

        # Clean up extraneous previous checklists to preserve disk space
        Write-Log $STIGLog "Clean up extraneous checklist history" $LogComponent "Info" -OSPlatform $OSPlatform
        Try {
            $CklHistory = Get-ChildItem -Path (Join-Path -Path "$ResultsPath\Checklist" -ChildPath "Previous") -ErrorAction SilentlyContinue | Where-Object PSIsContainer -EQ $true | Select-Object Name, FullName | Sort-Object Name -Descending
            If ($CklHistory) {
                $RecentPrevious = $CklHistory[0]
                ForEach ($Folder in $CklHistory) {
                    If ($Folder.Name -ne $RecentPrevious.Name) {
                        Write-Log $STIGLog "Removing $($Folder.Name)" $LogComponent "Info" -OSPlatform $OSPlatform
                        Remove-Item $Folder.FullName -Recurse -Force -Confirm:$false
                    }
                }
            }
        }
        Catch {
            Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
            Exit 10010001
        }

        # Move non-applicable files to Previous folder
        Write-Log $STIGLog "Moving non-applicable files to Previous folder" $LogComponent "Info" -OSPlatform $OSPlatform
        Try {
            $PreviousFolder = Get-Date -Format yyyy-MM-dd
            $PreviousPath = Join-Path -Path $ResultsPath -ChildPath "Checklist" | Join-Path -ChildPath "Previous" | Join-Path -ChildPath $PreviousFolder
            $AllItems = Get-ChildItem -Path $resultsPath -Recurse | Where-Object {(($_.Name -eq "Evaluate-STIG.log" -or $_.Name -like "SummaryReport.*" -or $_.Extension -eq ".ckl") -and $_.FullName -notlike "*Previous*")}
            ForEach ($Item in $AllItems) {
                If ($Item.LastWriteTime -lt $EvalStart) {
                    If ($SelectSTIG -and $Item.Extension -eq ".ckl") {
                        # Do nothing.  With -SelectSTIG, we leave existing CKLs where they are.
                    }
                    Else {
                        If (-Not(Test-Path -Path $PreviousPath)) {
                            $null = New-Item -Path (Join-Path $ResultsPath -ChildPath "Checklist") -Name (Join-Path -Path "Previous" -ChildPath $PreviousFolder) -ItemType Directory
                        }
                        Write-Log $STIGLog "Moving $($Item.Name) to $PreviousPath" $LogComponent "Info" -OSPlatform $OSPlatform
                        Move-Item -Path $Item.FullName -Destination $PreviousPath -Force
                    }
                }
            }
        }
        Catch {
            Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
            Exit 10010001
        }
    }
    Else {
        Write-Log $STIGLog "We're done!" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "==========[End Local Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform
        Exit
    }

    # Create summary report
    Write-Log $STIGLog "Generating summary report" $LogComponent "Info" -OSPlatform $OSPlatform
    Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Generating summary report" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
    $CurrentMainStep++
    Write-SummaryReport -CklPath (Join-Path -Path $ResultsPath -ChildPath "Checklist") -OutputPath $ResultsPath -ProcessedUser $UserToProcess.Username -Detail -OSPlatform $OSPlatform

    #Create Summary HTML
    $SummaryFile = Join-Path -Path $ResultsPath -ChildPath SummaryReport.xml
    [xml]$TempSR = New-Object xml

    $null = $TempSR.AppendChild($TempSR.CreateElement('Summaries'))
    $summary = New-Object xml
    $Summary.Load($SummaryFile)
    $ImportedSummary = $TempSR.ImportNode($Summary.DocumentElement, $true)
    $null = $TempSR.DocumentElement.AppendChild($ImportedSummary)

    $TempSR.Summaries.Summary.Checklists.Checklist | ForEach-Object {
        $CurrentScoreNode = $_.AppendChild($TempSR.CreateElement('CurrentScore'))
        $Currentnode = $_.SelectSingleNode("//Summary/Checklists/Checklist[STIG='$($_.STIG)']")
        $CurrentScore = ([int]$Currentnode.CAT_I.NotAFinding + [int]$Currentnode.CAT_II.NotAFinding + [int]$Currentnode.CAT_III.NotAFinding + [int]$Currentnode.CAT_I.Not_Applicable + [int]$Currentnode.CAT_II.Not_Applicable + [int]$Currentnode.CAT_III.Not_Applicable) / ([int]$Currentnode.CAT_I.Total + [int]$Currentnode.CAT_II.Total + [int]$Currentnode.CAT_III.Total)
        $CurrentScoreNode.SetAttribute("Score", $CurrentScore)
    }

    if (Test-Path $PreviousPath) {
        $PreviousSummaryFile = Join-Path -Path $PreviousPath -ChildPath SummaryReport.xml
        $PreviousSummary = New-Object xml
        $PreviousSummary.Load($PreviousSummaryFile)

        $TempSR.Summaries.Summary.Checklists.Checklist | ForEach-Object {
            $Previousnode = $PreviousSummary.SelectSingleNode("//Summary/Checklists/Checklist[STIG='$($_.STIG)']")
            if ($Previousnode){
                $PreviousScoreNode = $_.AppendChild($TempSR.CreateElement('PreviousScore'))
                $PreviousScore = ([int]$Previousnode.CAT_I.NotAFinding + [int]$Previousnode.CAT_II.NotAFinding + [int]$Previousnode.CAT_III.NotAFinding + [int]$Previousnode.CAT_I.Not_Applicable + [int]$Previousnode.CAT_II.Not_Applicable + [int]$Previousnode.CAT_III.Not_Applicable) / ([int]$Previousnode.CAT_I.Total + [int]$Previousnode.CAT_II.Total + [int]$Previousnode.CAT_III.Total)
                $PreviousScoreNode.SetAttribute("Delta", ((([float]($_.CurrentScore.Score) * 100) - ([float]($PreviousScore) * 100)))/100)
            }
        }
    }

    $TempSR.Save($(Join-Path -Path $WorkingDir -ChildPath TempSR.xml))

    $SummaryReportXLST = New-Object System.XML.Xsl.XslCompiledTransform
    $SummaryReportXLST.Load($(Join-Path "$PsScriptRoot\XmlSchema" -ChildPath SummaryReport.xslt))
    $SummaryReportXLST.Transform($(Join-Path -Path $WorkingDir -ChildPath TempSR.xml), $(Join-Path -Path $ResultsPath -ChildPath SummaryReport.html))

    # Apply tattoo
    If ($ApplyTattoo) {
        Write-Log $STIGLog "Applying Evaluate-STIG tattoo" $LogComponent "Info" -OSPlatform $OSPlatform
        Switch ($OSPlatform) {
            "Windows" {
                # Mark registry with EvaluateStigVersion.  This can be used for SCCM detection method.
                Try {
                    $RegistryPath = "HKLM:\SOFTWARE\Evaluate-STIG"
                    If (-Not(Test-Path -Path $RegistryPath)) {
                        $null = New-Item -Path $RegistryPath -Force
                    }
                    Write-Log $STIGLog "Creating 'Version' value under HKLM:\SOFTWARE\Evaluate-STIG" $LogComponent "Info" -OSPlatform $OSPlatform
                    $null = New-ItemProperty -Path $RegistryPath -Name Version -Value $ESVersion -PropertyType String -Force

                    Write-Log $STIGLog "Creating 'LastRun' value under HKLM:\SOFTWARE\Evaluate-STIG" $LogComponent "Info" -OSPlatform $OSPlatform
                    $null = New-ItemProperty -Path $RegistryPath -Name LastRun -Value $((Get-Date -Format FileDateTime).Replace('T', '')) -PropertyType String -Force
                }
                Catch {
                    Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
                    Exit 10010001
                }
            }
            "Linux" {
                Try {
                    Write-Log $STIGLog "Creating 'Version' value in /etc/Evaluate-STIG" $LogComponent "Info" -OSPlatform $OSPlatform
                    "Version: $ESVersion" | Out-File /etc/Evaluate-STIG

                    Write-Log $STIGLog "Creating 'LastRun' value in /etc/Evaluate-STIG" $LogComponent "Info" -OSPlatform $OSPlatform
                    "LastRun: $((Get-Date -Format FileDateTime).Replace('T', ''))" | Out-File /etc/Evaluate-STIG -Append
                }
                Catch {
                    Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
                    Exit 10010001
                }
            }
        }
    }

    # Remove temporary files
    Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Finalizing and cleaning up" -Completed
    Try {
        Write-Log $STIGLog "Removing temporary files" $LogComponent "Info" -OSPlatform $OSPlatform
        $TempFiles = Get-Item -Path $WorkingDir\* -Exclude Evaluate-STIG.log,Evaluate-STIG_Remote.log,RemoteScanTemp
        If ($TempFiles) {
            ForEach ($Item in $TempFiles) {
                $null = Remove-Item -Path $Item.FullName -Recurse -ErrorAction Stop
            }
        }
    }
    Catch {
        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
    }

    if ($STIGsToProcess.count -gt 0){
        $TotalCKLs = (Get-ChildItem -Path "$ResultsPath\Checklist" | Where-Object Extension -EQ '.ckl' | Measure-Object).Count
        $TimeToComplete = New-TimeSpan -Start $StartTime -End (Get-Date)
        $FormatedTime = "{0:c}" -f $TimeToComplete

        Write-Log $STIGLog "We're done!" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Total Time : $($FormatedTime)" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Total CKLs in Results Directory : $($TotalCKLs)" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "==========[End Local Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Host "Done!" -ForegroundColor Green
        Write-Host "Total Time : $($FormatedTime)" -ForegroundColor Green
        Write-Host "Total CKLs in Results Directory : $($TotalCKLs)" -ForegroundColor Green
        Write-Host ""
        Write-Host "Results saved to " -ForegroundColor Green -NoNewline; Write-Host "$($ResultsPath)" -ForegroundColor Cyan
        Write-Host ""
    }
    else{
        Write-Log $STIGLog "We're done!" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "==========[End Local Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Host "Done!" -ForegroundColor Green
        Write-Host ""
    }

    # Remove any remaining Evaluate-STIG modules from memory
    Get-Module | Where-Object Path -Like "*Evaluate-STIG*" | ForEach-Object { Remove-Module $_.Name -Force -ErrorAction SilentlyContinue }
    If ($STIGsToProcess.Name -like "Microsoft SQL Server*") {
        Remove-Module "SqlServer" -Force -ErrorAction SilentlyContinue
    }

    # Copy Evaluate-STIG.log to results path
    Try {
        Copy-Item $STIGLog -Destination $ResultsPath
    }
    Catch {
        Write-Log $STIGLog "Error: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
        Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
        Exit 10010001
    }
}

# SIG # Begin signature block
# MIIL1AYJKoZIhvcNAQcCoIILxTCCC8ECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUKIDHbbBQuZ3a0cnpU/WsBqgV
# XYugggk7MIIEejCCA2KgAwIBAgIEAwIE1zANBgkqhkiG9w0BAQsFADBaMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MB4XDTIwMDcxNTAw
# MDAwMFoXDTI1MDQwMjEzMzgzMlowaTELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxDDAKBgNV
# BAsTA1VTTjEWMBQGA1UEAxMNQ1MuTlNXQ0NELjAwMTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANv2fdTmx2dNPQ47F8kmvU+g20/sFoF+DS3k2GcMduuI
# XxYFJyMMPAvTJuobeJlX6P6sr5jAKhXXsoV4lT2boWw583Snl6cuSfqMbVowIJ1s
# CffN7N0VXsLVdOt1u5GCKs4/jXH7MeEOE0oJsgEjjE1IZc5tEqj++s1N1EUY+jf/
# zc8QHDjy5X88XBTzKVhwvczZVbRahrcmYv0k4we3ndwTl5nXYizSwi96CZuqzrIn
# WbLSsRLNyNZZVo7J5bZ+30dv/hZvq6FqxfAeM3pEDrvbfFkWXzaISqF1bVbsMlAC
# UBf/JFbSGtmMsU1ABfXKPalTWYJKP58dICHcUocZhL0CAwEAAaOCATcwggEzMB8G
# A1UdIwQYMBaAFHUJphUTroc8+nOUAPLw9Xm5snIUMEEGA1UdHwQ6MDgwNqA0oDKG
# MGh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNTlfTkNPREVTSUdOLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyowHQYDVR0O
# BBYEFFbrF3OpzfdsZkN1zTfv++oaLCRRMGUGCCsGAQUFBwEBBFkwVzAzBggrBgEF
# BQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNTkuY2VyMCAG
# CCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAWBgorBgEE
# AYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAQknaIAXDnyqshmyh
# uOZS4nBtSydnZrdB8Je0JCq2TTRA4dkNvrswe0kZgA7UjlY1X/9PtQeIwaMrcvdF
# i+dqzD1bbW/LX5tH/1oMOp4s+VkGfl4xUUxUGjO6QTVOeLyN2x+DBQU11DhKEq9B
# RCxUGgclFn1iqxi5xKmLaQ3XuRWRGCkb+rXejWR+5uSTognxCuoLp95bqu3JL8ec
# yF46+VSoafktAGot2Uf3qmwWdMHFBdwzmJalbC4j09I1qJqcJH0p8Wt34zRw/hSr
# 3f+xDEDP8GNL2ciDm7aN0GKy67ugjgMmPXAv7A4/keCuN/dsNS1naNyqzc5AhTAF
# +o/21jCCBLkwggOhoAMCAQICAgMFMA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTE5MDQwMjEzMzgz
# MloXDTI1MDQwMjEzMzgzMlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4g
# R292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMT
# DERPRCBJRCBDQS01OTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMwX
# hJ8twQpXrRFNNVc/JEcvHA9jlr27cDE8rpxWkobvpCJOoOVUbJ724Stx6OtTAZpR
# iXNaS0jjRgYaW6cq9pdnjjQM5ovHPPde1ewaZyWb2I+uqhkZmOBV1+lGUOhnQCyi
# nnSSqzEH1PC5nASfyxnCdBeOt+UKHBrPVKBUuYS4Fcn5Q0wv+sfBD24vyV5Ojeoq
# HeSSAMTaeqlv+WQb4YrjKNfaGF+S7lMvQelu3ANHEcoL2HMCimCvnCHQaMQI9+Ms
# NhySPEULePdEDxgpWYc9FmBbjUp1CYEx7HYdlTRJ9gBHts2ITxTZQrt4Epjkqeb8
# aWVmzCEPHE7+KUVhuO8CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyKlKJ3sYBy
# HYF6Fqry3M5m7kXAMB0GA1UdDgQWBBR1CaYVE66HPPpzlADy8PV5ubJyFDAOBgNV
# HQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsn
# MAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgB
# ZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQE
# BTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3Js
# L0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0
# cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3YzAgBggr
# BgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQELBQADggEB
# ADkFG9IOpz71qHNXCeYJIcUshgN20CrvB5ym4Pr7zKTBRMKNqd9EXWBxrwP9xhra
# 5YcQagHDqnmBeU3F2ePhWvQmyhPwIJaArk4xGLdv9Imkr3cO8vVapO48k/R9ZRSA
# EBxzd0xMDdZ6+xxFlZJIONRlxcVNNVB30e74Kk08/t82S9ogqgA1Q7KZ2tFuaRes
# jJWuoJ+LtE5lrtknqgaXLb3XH0hV5M0AWRk9Wg/1thb9NCsKEIAdpdnolZOephIz
# fzHiOSqeJ+e5qURLB7rT+F5y0NNWTdqoJ/vOOCUa8z0NKWsz2IkpeD3iNhVCLRKw
# Ojm/wzxdG2tst5OHRZFEwKcxggIDMIIB/wIBATBiMFoxCzAJBgNVBAYTAlVTMRgw
# FgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMD
# UEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNTkCBAMCBNcwCQYFKw4DAhoFAKB4MBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYE
# FFOT5HaIqv1ywIJQBsx93QwPiuBRMA0GCSqGSIb3DQEBAQUABIIBAKc2+FOe1GhC
# 2ZPVFGIlbGUMh8GBjE4dDHUCh1+Ks6iuaxgjkBb5I1kJWNG3CO9c3qqG3T6C8gIi
# arqo+7rIqw355iCZ150C1/IaYLU1YCnuWdwfYUKYlDW9yLu0aRLC2KLWBt1b6TEX
# nf1WeIC3QyM+b6KBhinuF+b/tTZGIzHGz4h8TZLUVGu7z4USoYnpMcbYVauceOl1
# uI9V0yxI5cZk8LfBP5lWZ/0hs1jGf54+JZp+H+19w98DxhGrvhyGzUb39VZd14Aj
# pEf/UA5+npvmcRD3AL2LPAV37A0TlDB774/8p2VjK/vTS1WmwLTXAetK7ofy9Q6U
# 4S9WcxHsv+w=
# SIG # End signature block
